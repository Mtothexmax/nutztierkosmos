/* =========================================================
   Nutztierkosmos · soundscape
   Wind, birds and interface sounds are synthesized live.
   Music (audio/musik.m4a) and the animal recordings
   (audio/tiere.js) are fetched only after the game has started.
   ========================================================= */
(function () {
  'use strict';

  var NTK = window.NTK = window.NTK || {};

  function AudioEngine() {
    this.ctx = null;
    this.master = null;
    this.ambientBus = null;
    this.sfxBus = null;
    this.started = false;
    this.muted = false;
    this.suspended = false;
    this.fanOn = false;
    this.fanGain = null;
    this.fanOsc = null;
    this.ambient = {};
    this.nextBird = 2.3;
    this.nextMoo = 14;
    this.nextNote = 4.8;
    this.noteIndex = 0;
    this.reducedMotion = false;
    this.stress = 1;            // 1 = herd under heat stress, 0 = relaxed
    this.samples = {};
    this.music = null;
    this.musicPlaying = false;
    this.musicEnabled = true;
    this.musicLevel = 0.15;     // slider position 0..1
    this.musicReady = false;    // true once the deferred load may happen
    this.deferredRequested = false;
    this.nextBell = 6;
    this.nextGust = 3;
  }

  AudioEngine.prototype.init = function () {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(function () {});
      }
      this.requestDeferred();
      return;
    }
    var AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;

    try {
      var ctx = new AudioCtx();
      this.ctx = ctx;
      this.master = ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.62;
      this.master.connect(ctx.destination);

      this.ambientBus = ctx.createGain();
      this.ambientBus.gain.value = 0.62;
      this.ambientBus.connect(this.master);

      this.sfxBus = ctx.createGain();
      this.sfxBus.gain.value = 0.82;
      this.sfxBus.connect(this.master);

      this.makeAir();
      this.makePad();
      this.started = true;
      this.requestDeferred();
    } catch (err) {
      this.ctx = null;
    }
  };

  AudioEngine.prototype.makeNoise = function (seconds, smooth) {
    smooth = smooth == null ? 0.985 : smooth;
    var ctx = this.ctx;
    var len = Math.max(1, Math.floor(ctx.sampleRate * seconds));
    var buffer = ctx.createBuffer(2, len, ctx.sampleRate);
    for (var ch = 0; ch < 2; ch += 1) {
      var data = buffer.getChannelData(ch);
      var last = 0;
      for (var i = 0; i < len; i += 1) {
        var white = Math.random() * 2 - 1;
        last = last * smooth + white * (1 - smooth);
        data[i] = last * (smooth > 0.9 ? 2.2 : 0.9);
      }
    }
    return buffer;
  };

  /* Wind is generated, never sampled: a low steady bed plus a brighter
     layer whose loudness and colour are driven by randomly timed gusts. */
  AudioEngine.prototype.makeAir = function () {
    var ctx = this.ctx;
    var bed = ctx.createBufferSource();
    bed.buffer = this.makeNoise(5);
    bed.loop = true;
    var bedLp = ctx.createBiquadFilter();
    bedLp.type = 'lowpass';
    bedLp.frequency.value = 480;
    bedLp.Q.value = 0.4;
    var bedHp = ctx.createBiquadFilter();
    bedHp.type = 'highpass';
    bedHp.frequency.value = 70;
    var bedGain = ctx.createGain();
    bedGain.gain.value = 0.085;
    bed.connect(bedHp);
    bedHp.connect(bedLp);
    bedLp.connect(bedGain);
    bedGain.connect(this.ambientBus);
    bed.start();

    var gust = ctx.createBufferSource();
    gust.buffer = this.makeNoise(7, 0.55);
    gust.loop = true;
    var band = ctx.createBiquadFilter();
    band.type = 'bandpass';
    band.frequency.value = 420;
    band.Q.value = 0.7;
    var gustLp = ctx.createBiquadFilter();
    gustLp.type = 'lowpass';
    gustLp.frequency.value = 2400;
    var gustGain = ctx.createGain();
    gustGain.gain.value = 0.012;
    var pan = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    gust.connect(band);
    band.connect(gustLp);
    gustLp.connect(gustGain);
    if (pan) {
      gustGain.connect(pan);
      pan.connect(this.ambientBus);
    } else {
      gustGain.connect(this.ambientBus);
    }
    gust.start();

    this.ambient.wind = { source: bed, gain: bedGain, gustGain: gustGain, band: band, pan: pan };
  };

  AudioEngine.prototype.blowGust = function () {
    var w = this.ambient.wind;
    if (!w || !this.ctx) return 0;
    var t = this.ctx.currentTime;
    var strength = (0.035 + Math.random() * 0.06) * (this.reducedMotion ? 0.5 : 1);
    var rise = 1.2 + Math.random() * 2.2;
    var hold = 0.6 + Math.random() * 1.8;
    var fall = 2.2 + Math.random() * 3.0;
    var peak = 520 + Math.random() * 520;
    w.gustGain.gain.cancelScheduledValues(t);
    w.gustGain.gain.setTargetAtTime(strength, t, rise / 3);
    w.gustGain.gain.setTargetAtTime(0.012, t + rise + hold, fall / 3);
    w.band.frequency.cancelScheduledValues(t);
    w.band.frequency.setTargetAtTime(peak, t, rise / 2.5);
    w.band.frequency.setTargetAtTime(380 + Math.random() * 80, t + rise + hold, fall / 2.5);
    if (w.pan) {
      w.pan.pan.cancelScheduledValues(t);
      w.pan.pan.setTargetAtTime(Math.random() * 1.2 - 0.6, t, rise);
    }
    this.lastGust = { strength: strength, seconds: rise + hold + fall };
    return rise + hold + fall;
  };

  AudioEngine.prototype.makePad = function () {
    var ctx = this.ctx;
    var bus = ctx.createGain();
    bus.gain.value = 0.018;
    var filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 760;
    filter.Q.value = 0.5;
    bus.connect(filter);
    filter.connect(this.ambientBus);

    var freqs = [73.42, 110, 146.83];
    var self = this;
    var oscs = [];
    freqs.forEach(function (f, i) {
      var osc = ctx.createOscillator();
      osc.type = i === 0 ? 'sine' : 'triangle';
      osc.frequency.value = f;
      osc.detune.value = (i - 1) * 4;
      var g = ctx.createGain();
      g.gain.value = i === 0 ? 0.42 : 0.14;
      osc.connect(g);
      g.connect(bus);
      osc.start();
      oscs.push(osc);
    });

    var lfo = ctx.createOscillator();
    var lfoGain = ctx.createGain();
    lfo.frequency.value = 0.025;
    lfoGain.gain.value = 0.008;
    lfo.connect(lfoGain);
    lfoGain.connect(bus.gain);
    lfo.start();

    this.ambient.pad = { bus: bus, oscs: oscs, lfo: lfo, filter: filter, gain: bus.gain.value };
  };

  AudioEngine.prototype.chirp = function (when, base, pan) {
    var ctx = this.ctx;
    if (!ctx || this.muted) return;
    var count = 2 + Math.floor(Math.random() * 3);
    var panner = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    var out = ctx.createGain();
    out.gain.value = 0.045;
    if (panner) {
      panner.pan.value = pan;
      out.connect(panner);
      panner.connect(this.ambientBus);
    } else {
      out.connect(this.ambientBus);
    }

    for (var i = 0; i < count; i += 1) {
      var t = when + i * 0.105;
      var osc = ctx.createOscillator();
      var gain = ctx.createGain();
      osc.type = 'sine';
      var f = base * (1 + i * 0.16 + Math.random() * 0.08);
      osc.frequency.setValueAtTime(f, t);
      osc.frequency.exponentialRampToValueAtTime(f * 1.45, t + 0.035);
      osc.frequency.exponentialRampToValueAtTime(f * 0.92, t + 0.09);
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(0.16, t + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.11);
      osc.connect(gain);
      gain.connect(out);
      osc.start(t);
      osc.stop(t + 0.14);
    }
  };

  AudioEngine.prototype.pluck = function (when, freq, level) {
    var ctx = this.ctx;
    if (!ctx || this.muted) return;
    var osc = ctx.createOscillator();
    var gain = ctx.createGain();
    var filter = ctx.createBiquadFilter();
    var delay = ctx.createDelay(1.2);
    var feedback = ctx.createGain();
    var wet = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.value = freq;
    filter.type = 'lowpass';
    filter.frequency.value = 1200;
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(level || 0.032, when + 0.04);
    gain.gain.exponentialRampToValueAtTime(0.0001, when + 1.8);

    delay.delayTime.value = 0.26;
    feedback.gain.value = 0.26;
    wet.gain.value = 0.2;

    osc.connect(gain);
    gain.connect(filter);
    filter.connect(this.ambientBus);
    filter.connect(delay);
    delay.connect(feedback);
    feedback.connect(delay);
    delay.connect(wet);
    wet.connect(this.ambientBus);

    osc.start(when);
    osc.stop(when + 1.9);
  };

  AudioEngine.prototype.synthMoo = function (volume) {
    var ctx = this.ctx;
    if (!ctx || this.muted || this.suspended) return;
    var t = ctx.currentTime;
    var osc = ctx.createOscillator();
    var osc2 = ctx.createOscillator();
    var gain = ctx.createGain();
    var filter = ctx.createBiquadFilter();
    var panner = ctx.createStereoPanner ? ctx.createStereoPanner() : null;

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(155, t);
    osc.frequency.linearRampToValueAtTime(118, t + 0.7);
    osc.frequency.linearRampToValueAtTime(96, t + 1.25);
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(78, t);
    osc2.frequency.linearRampToValueAtTime(62, t + 1.25);

    filter.type = 'lowpass';
    filter.Q.value = 3.2;
    filter.frequency.setValueAtTime(620, t);
    filter.frequency.linearRampToValueAtTime(380, t + 1.2);

    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(volume || 0.032, t + 0.16);
    gain.gain.setValueAtTime(volume || 0.032, t + 0.6);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 1.35);

    osc.connect(filter);
    osc2.connect(filter);
    filter.connect(gain);
    if (panner) {
      panner.pan.value = Math.random() * 1.2 - 0.6;
      gain.connect(panner);
      panner.connect(this.ambientBus);
    } else {
      gain.connect(this.ambientBus);
    }
    osc.start(t);
    osc2.start(t);
    osc.stop(t + 1.4);
    osc2.stop(t + 1.4);
  };

  AudioEngine.prototype.update = function (dt) {
    if (!this.started || !this.ctx || this.muted || this.suspended) return;
    this.nextBird -= dt;
    if (this.nextBird <= 0) {
      this.nextBird = 3.2 + Math.random() * 8.5;
      this.chirp(this.ctx.currentTime + 0.04, 1700 + Math.random() * 1500, Math.random() * 1.6 - 0.8);
    }
    var stress = this.stress;
    this.nextGust -= dt;
    if (this.nextGust <= 0) {
      this.nextGust = (this.blowGust() || 4) * (0.55 + Math.random() * 0.9) + Math.random() * 3;
    }
    this.nextMoo -= dt;
    if (this.nextMoo <= 0) {
      // A stressed herd calls more often.
      this.nextMoo = (22 + Math.random() * 18) * (1 - stress) + (9 + Math.random() * 9) * stress;
      this.moo(0.5);
    }
    this.nextBell -= dt;
    if (this.nextBell <= 0) {
      this.nextBell = (9 + Math.random() * 9) * (1 - stress) + (4 + Math.random() * 5) * stress;
      this.cowbell();
    }
    if (this.musicPlaying) return;
    this.nextNote -= dt;
    if (this.nextNote <= 0) {
      this.nextNote = 7.5 + Math.random() * 6;
      var notes = [293.66, 369.99, 440, 554.37, 440, 369.99];
      this.pluck(this.ctx.currentTime + 0.05, notes[this.noteIndex % notes.length], 0.021);
      this.noteIndex += 1;
    }
  };

  AudioEngine.prototype.sfx = function (name) {
    var ctx = this.ctx;
    if (!ctx || this.muted || this.suspended) return;
    var t = ctx.currentTime + 0.01;

    if (name === 'click') {
      this.tone(660, 0.05, 0.032, 'sine', t);
    } else if (name === 'open') {
      this.tone(392, 0.12, 0.035, 'sine', t);
      this.tone(587.33, 0.18, 0.026, 'sine', t + 0.08);
    } else if (name === 'observe') {
      this.tone(523.25, 0.16, 0.032, 'sine', t);
      this.tone(783.99, 0.22, 0.026, 'sine', t + 0.1);
    } else if (name === 'measure') {
      this.tone(880, 0.07, 0.025, 'square', t);
      this.tone(1174.66, 0.1, 0.018, 'square', t + 0.08);
    } else if (name === 'success') {
      [523.25, 659.25, 783.99].forEach(function (f, i) {
        this.tone(f, 0.28, 0.037, 'sine', t + i * 0.08);
      }, this);
    } else if (name === 'build') {
      this.thud(t);
      this.tone(523.25, 0.2, 0.03, 'sine', t + 0.22);
      this.tone(659.25, 0.28, 0.026, 'sine', t + 0.29);
    } else if (name === 'complete') {
      [392, 523.25, 659.25, 783.99, 1046.5].forEach(function (f, i) {
        this.tone(f, 0.55, 0.035, 'sine', t + i * 0.1);
      }, this);
    } else if (name === 'error') {
      this.tone(196, 0.18, 0.028, 'triangle', t);
      this.tone(146.83, 0.22, 0.02, 'triangle', t + 0.1);
    } else if (name === 'tab') {
      this.tone(440, 0.05, 0.02, 'sine', t);
    }
  };

  AudioEngine.prototype.tone = function (freq, duration, level, type, when) {
    var ctx = this.ctx;
    if (!ctx) return;
    var osc = ctx.createOscillator();
    var gain = ctx.createGain();
    osc.type = type || 'sine';
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(level || 0.03, when + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, when + duration);
    osc.connect(gain);
    gain.connect(this.sfxBus);
    osc.start(when);
    osc.stop(when + duration + 0.03);
  };

  AudioEngine.prototype.thud = function (when) {
    var ctx = this.ctx;
    if (!ctx) return;
    var osc = ctx.createOscillator();
    var gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(120, when);
    osc.frequency.exponentialRampToValueAtTime(52, when + 0.15);
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(0.12, when + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, when + 0.22);
    osc.connect(gain);
    gain.connect(this.sfxBus);
    osc.start(when);
    osc.stop(when + 0.25);
  };

  AudioEngine.prototype.setFan = function (on) {
    this.fanOn = on;
    if (!this.ctx) return;
    var ctx = this.ctx;
    if (on) {
      if (!this.fanGain) {
        var noise = ctx.createBufferSource();
        noise.buffer = this.makeNoise(4);
        noise.loop = true;
        var hp = ctx.createBiquadFilter();
        hp.type = 'bandpass';
        hp.frequency.value = 440;
        hp.Q.value = 0.55;
        this.fanGain = ctx.createGain();
        this.fanGain.gain.value = 0;
        noise.connect(hp);
        hp.connect(this.fanGain);
        this.fanGain.connect(this.sfxBus);
        noise.start();
        this.fanNoise = noise;
      }
      this.fanGain.gain.cancelScheduledValues(ctx.currentTime);
      this.fanGain.gain.setTargetAtTime(0.055, ctx.currentTime, 0.6);
    } else if (this.fanGain) {
      this.fanGain.gain.cancelScheduledValues(ctx.currentTime);
      this.fanGain.gain.setTargetAtTime(0, ctx.currentTime, 0.35);
    }
  };

  AudioEngine.prototype.setMuted = function (muted) {
    this.muted = !!muted;
    if (this.music) {
      this.music.muted = this.muted;
      if (!this.muted) this.playMusic();
    }
    if (!this.ctx || !this.master) return;
    var t = this.ctx.currentTime;
    this.master.gain.cancelScheduledValues(t);
    this.master.gain.setTargetAtTime(this.muted ? 0 : 0.62, t, 0.08);
  };


  AudioEngine.prototype.pause = function () {
    this.suspended = true;
    if (this.music) this.music.pause();
    if (this.ctx && this.ctx.state === 'running') {
      this.ctx.suspend().catch(function () {});
    }
  };

  AudioEngine.prototype.resume = function () {
    this.suspended = false;
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(function () {});
    }
    this.playMusic();
  };

  AudioEngine.prototype.setReduced = function (reduced) {
    this.reducedMotion = reduced;
    if (this.ambient && this.ambient.wind) {
      this.ambient.wind.gain.gain.setTargetAtTime(reduced ? 0.05 : 0.085, this.ctx.currentTime, 0.4);
    }
  };

  /* ---------------------------------------------------------
     Deferred assets: nothing below is requested before the
     player is already in the world and able to walk.
     --------------------------------------------------------- */

  AudioEngine.prototype.requestDeferred = function () {
    if (this.deferredRequested) return;
    this.deferredRequested = true;
    var self = this;
    window.setTimeout(function () {
      self.loadSamples();
      self.musicReady = true;
      self.loadMusic();
    }, 1800);
  };

  AudioEngine.prototype.loadMusic = function () {
    if (this.music || !this.musicEnabled || !this.musicReady || typeof Audio === 'undefined') return;
    var self = this;
    try {
      var el = new Audio();
      el.preload = 'auto';
      el.loop = true;
      el.volume = 0;
      el.muted = this.muted;
      el.addEventListener('canplay', function () { self.playMusic(); });
      el.src = 'audio/musik.m4a';
      this.music = el;
      // If the browser refuses to start playback outside a click, retry on the next input.
      var retry = function () { self.playMusic(); };
      window.addEventListener('pointerdown', retry);
      window.addEventListener('keydown', retry);
    } catch (err) {
      this.music = null;
    }
  };

  AudioEngine.prototype.playMusic = function () {
    var el = this.music;
    if (!el || !this.musicEnabled || this.suspended || this.muted || el.readyState < 2 || !el.paused) return;
    var self = this;
    var started = function () {
      if (!self.musicPlaying) {
        self.musicPlaying = true;
        // The recorded music replaces the synthesized pad.
        if (self.ambient.pad && self.ctx) {
          self.ambient.pad.lfo.disconnect();
          self.ambient.pad.bus.gain.cancelScheduledValues(self.ctx.currentTime);
          self.ambient.pad.bus.gain.setTargetAtTime(0, self.ctx.currentTime, 1.2);
        }
      }
      self.fadeMusic(self.musicVolume());
    };
    try {
      var result = el.play();
      if (result && result.then) result.then(started).catch(function () {});
      else started();
    } catch (err) { /* stays silent until the next input */ }
  };

  // Slider position to element volume; the default (15 %) is deliberately quiet.
  AudioEngine.prototype.musicVolume = function () {
    return this.musicLevel * 0.6;
  };

  AudioEngine.prototype.setMusicLevel = function (level) {
    this.musicLevel = Math.max(0, Math.min(1, level));
    if (this.music && !this.music.paused) this.fadeMusic(this.musicVolume());
  };

  AudioEngine.prototype.setMusicEnabled = function (enabled) {
    this.musicEnabled = !!enabled;
    if (!this.musicEnabled) {
      window.clearInterval(this.musicFade);
      if (this.music) this.music.pause();
      return;
    }
    if (!this.music) this.loadMusic();
    else this.playMusic();
  };

  AudioEngine.prototype.fadeMusic = function (target) {
    var el = this.music;
    if (!el) return;
    var self = this;
    window.clearInterval(this.musicFade);
    this.musicFade = window.setInterval(function () {
      var next = el.volume + (target - el.volume) * 0.08;
      if (Math.abs(target - next) < 0.005) {
        next = target;
        window.clearInterval(self.musicFade);
      }
      try { el.volume = Math.max(0, Math.min(1, next)); } catch (err) { window.clearInterval(self.musicFade); }
    }, 60);
  };

  AudioEngine.prototype.loadSamples = function () {
    var self = this;
    var decode = function (data) {
      if (!data || !self.ctx) return;
      Object.keys(data).forEach(function (name) {
        try {
          var binary = window.atob(data[name]);
          var bytes = new Uint8Array(binary.length);
          for (var i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
          self.ctx.decodeAudioData(bytes.buffer, function (buffer) {
            self.samples[name] = buffer;
          }, function () {});
        } catch (err) { /* the synthesized fallback stays in place */ }
      });
    };
    if (NTK.SFX_DATA) {
      decode(NTK.SFX_DATA);
      return;
    }
    NTK.onSfxData = decode;
    var script = document.createElement('script');
    script.src = 'audio/tiere.js';
    script.async = true;
    document.head.appendChild(script);
  };

  /* ---------------------------------------------------------
     Animal voices
     --------------------------------------------------------- */

  function between(a, b) { return a + Math.random() * (b - a); }

  AudioEngine.prototype.setStress = function (level) {
    this.stress = Math.max(0, Math.min(1, level));
  };

  /* One recording, many cows: every call picks its own pitch, speed,
     timbre and length. Under heat stress the voice is higher, wavers,
     trembles and gets a rough edge; relaxed cows call low and steady. */
  AudioEngine.prototype.moo = function (volume, stressOverride) {
    var ctx = this.ctx;
    if (!ctx || this.muted || this.suspended) return;
    var buffer = this.samples.moo;
    if (!buffer) {
      if (!this.reducedMotion) this.synthMoo(0.018);
      return;
    }
    var stress = stressOverride == null ? this.stress : stressOverride;
    var t = ctx.currentTime + 0.02;

    // Pitch: relaxed around the original, stressed +2 to +4 semitones.
    var semis = between(-2.2, 0.6) * (1 - stress) + between(2, 4) * stress;
    // Extra speed spread acts as a time stretch between individual cows.
    var stretch = between(0.9, 1.12);
    var rate = Math.pow(2, semis / 12) * stretch;
    var src = ctx.createBufferSource();
    src.buffer = buffer;
    src.playbackRate.value = rate;
    var offset = between(0, 0.07);
    var length = (buffer.duration - offset) * between(0.82, 1);
    var playTime = length / rate;

    // Nervous pitch drift (up to +-1 semitone when stressed) plus a natural fall.
    if (src.detune && src.detune.setValueCurveAtTime) {
      var points = 9;
      var curve = new Float32Array(points);
      var drift = 0;
      var glide = between(-90, 20);
      for (var i = 0; i < points; i += 1) {
        drift = drift * 0.5 + between(-100, 100) * stress * 0.8;
        curve[i] = drift + glide * (i / (points - 1));
      }
      try { src.detune.setValueCurveAtTime(curve, t, playTime); } catch (err) { /* keep steady pitch */ }
    }

    // Timbre: a random resonance makes it sound like a different animal.
    var tone = ctx.createBiquadFilter();
    tone.type = 'peaking';
    tone.frequency.value = between(420, 1500);
    tone.Q.value = between(0.8, 2.2);
    tone.gain.value = between(-5, 6);

    // Saturation 5-10 % when stressed.
    var shaper = ctx.createWaveShaper();
    var drive = 1 + between(0.05, 0.10) * stress * 22;
    var shape = new Float32Array(257);
    var norm = Math.tanh(drive);
    for (var k = 0; k < 257; k += 1) {
      shape[k] = Math.tanh(drive * (k / 128 - 1)) / norm;
    }
    shaper.curve = shape;

    // Tremolo 5-7 Hz, 15-25 % depth when stressed.
    var trem = ctx.createGain();
    var depth = between(0.15, 0.25) * stress;
    trem.gain.value = 1 - depth * 0.5;
    var lfo = ctx.createOscillator();
    var lfoGain = ctx.createGain();
    lfo.frequency.value = between(5, 7);
    lfoGain.gain.value = depth * 0.5;
    lfo.connect(lfoGain);
    lfoGain.connect(trem.gain);

    var comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -20;
    comp.ratio.value = 3;
    comp.attack.value = 0.01;
    comp.release.value = 0.2;

    var out = ctx.createGain();
    var level = (volume || 0.5) * between(0.7, 1);
    out.gain.setValueAtTime(0.0001, t);
    out.gain.exponentialRampToValueAtTime(level, t + 0.05);
    out.gain.setValueAtTime(level, t + Math.max(0.06, playTime - 0.18));
    out.gain.exponentialRampToValueAtTime(0.0001, t + playTime);

    src.connect(tone);
    tone.connect(shaper);
    shaper.connect(trem);
    trem.connect(comp);
    comp.connect(out);
    var panner = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    if (panner) {
      panner.pan.value = between(-0.7, 0.7);
      out.connect(panner);
      panner.connect(this.ambientBus);
    } else {
      out.connect(this.ambientBus);
    }
    src.start(t, offset, length);
    lfo.start(t);
    lfo.stop(t + playTime + 0.1);
    this.lastMoo = { semitones: semis, rate: rate, tremolo: depth, drive: drive, seconds: playTime };
  };

  AudioEngine.prototype.cowbell = function (volume) {
    var ctx = this.ctx;
    var buffer = this.samples.cowbell;
    if (!ctx || !buffer || this.muted || this.suspended) return;
    var t = ctx.currentTime + 0.02;
    var rate = between(0.86, 1.18);
    var length = between(1.1, 2.6);
    var offset = between(0, Math.max(0, buffer.duration - length - 0.1));
    var playTime = length / rate;
    var src = ctx.createBufferSource();
    src.buffer = buffer;
    src.playbackRate.value = rate;
    var out = ctx.createGain();
    var level = (volume || 0.3) * between(0.6, 1);
    out.gain.setValueAtTime(0.0001, t);
    out.gain.exponentialRampToValueAtTime(level, t + 0.12);
    out.gain.setValueAtTime(level, t + playTime * 0.55);
    out.gain.exponentialRampToValueAtTime(0.0001, t + playTime);
    src.connect(out);
    var panner = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    if (panner) {
      panner.pan.value = between(-0.8, 0.8);
      out.connect(panner);
      panner.connect(this.ambientBus);
    } else {
      out.connect(this.ambientBus);
    }
    src.start(t, offset, length);
    this.lastBell = { rate: rate, seconds: playTime };
  };

  NTK.AudioEngine = AudioEngine;
})();
