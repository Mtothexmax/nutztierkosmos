/* =========================================================
   Nutztierkosmos · Mission content
   All texts are original, scientifically cautious learning copy.
   ========================================================= */
(function () {
  'use strict';

  var DATA = {};

  DATA.meta = {
    gameId: 'ntk-heisser-tag',
    title: 'Ein heißer Tag auf der Weide',
    subtitle: 'Hitzestress bei Milchkühen',
    maxPoints: 1000,
    estimatedMinutes: '8–12',
    season: 'Hochsommer',
    defaultPlayer: 'Forscher:in'
  };

  DATA.measurement = {
    temperature: 33.2,
    humidity: 61,
    thi: 84.5,
    classification: 'Starke Hitzebelastung',
    classificationShort: 'stark',
    note: 'Der THI kombiniert Lufttemperatur und Luftfeuchte. Bei hoher Feuchte kann der Körper weniger Wärme über Verdunstung abgeben – die Belastung steigt.',
    thresholds: [
      { max: 67.99, label: 'entspannt' },
      { max: 71.99, label: 'mild' },
      { max: 79.99, label: 'belastend' },
      { max: 100, label: 'stark' }
    ]
  };

  DATA.score = {
    observation: 80,
    measurement: 80,
    measure: 100,
    followUp: 60,
    analysis: 120,
    maxPoints: 1000,
    breakdown: [
      { id: 'observe', label: 'Drei Kühe beobachtet', value: 240 },
      { id: 'measure', label: 'Temperatur und Luftfeuchte gemessen', value: 160 },
      { id: 'act', label: 'Drei passende Maßnahmen umgesetzt', value: 300 },
      { id: 'followup', label: 'Wirkung bei drei Kühen überprüft', value: 180 },
      { id: 'analysis', label: 'Forschung ausgewertet', value: 120 }
    ]
  };

  /* Individual cows. Sensitivity is a game value, not a veterinary score. */
  DATA.cows = [
    {
      id: 'lotte',
      name: 'Lotte',
      breed: 'Schwarzbunte Holstein',
      age: '6 Jahre',
      lactation: '3. Laktation',
      sensitivity: 3,
      sensitivityLabel: 'mittel',
      tags: ['Erfahrene Kuh', 'dunkles Fell', 'ruhig'],
      short: 'steht im Schatten und atmet schnell',
      color: '#f6f1e6',
      pattern: '#282925',
      patternSeed: 11,
      bodyScale: 1.0,
      start: { x: 10.5, z: -6.4 },
      need: 'Schatten',
      before: 'Lotte steht dicht am Stamm der alten Eiche. Ihr Flankenatmen ist deutlich sichtbar, der Kopf hängt tief. Sie frisst kaum und weicht nicht aus dem Schatten.',
      after: 'Lotte steht entspannter unter dem Schattensegel. Die Atemzüge sind ruhiger, sie senkt den Kopf zum Gras und bleibt nicht mehr starr stehen.',
      signs: ['schnelle Atmung', 'verkrampftes Stehen', 'wenig Futteraufnahme'],
      science: 'Dunkles Fell nimmt mehr Sonnenstrahlung auf. Bei Hitze verlagern Rinder die Wärmeabgabe auf die Atmung – sichtbar an schnellerem, tieferem Atmen.',
      metric: { label: 'Atemzüge', before: '52 / min', after: '28 / min' }
    },
    {
      id: 'mira',
      name: 'Mira',
      breed: 'Rotbunte Holstein',
      age: '3 Jahre',
      lactation: '1. Laktation',
      sensitivity: 4,
      sensitivityLabel: 'hoch',
      tags: ['jung', 'erstlaktierend', 'wärmesensibel'],
      short: 'sucht auffällig Schatten und steht viel',
      color: '#f5e8da',
      pattern: '#9c5236',
      patternSeed: 27,
      bodyScale: 0.93,
      start: { x: 16.2, z: 1.5 },
      need: 'Schatten',
      before: 'Mira pendelt zwischen dem kleinen Schattenplatz und der offenen Weide. Sie steht viel, wirkt unruhig und leckt sich häufiger über das Maul. Fressen interessiert sie gerade wenig.',
      after: 'Mira nutzt den neuen Schatten ruhig und verteilt sich wieder besser auf die Weide. Sie bleibt länger an einem Ort, ohne ständig den Platz zu wechseln.',
      signs: ['Unruhe', 'ständiger Platzwechsel', 'vermindertes Fressen'],
      science: 'Junge, erstlaktierende Kühe reagieren nicht automatisch gleich wie ältere Tiere. Gewöhnung, Stoffwechsel und Leistung beeinflussen die individuelle Wärmebelastung.',
      metric: { label: 'Platzwechsel', before: 'sehr häufig', after: 'selten' }
    },
    {
      id: 'paula',
      name: 'Paula',
      breed: 'Schwarzbunte Holstein',
      age: '5 Jahre',
      lactation: '2. Laktation',
      sensitivity: 4,
      sensitivityLabel: 'hoch',
      tags: ['hohe Milchleistung', 'viel Durst', 'sozial'],
      short: 'steht an der Tränke und trinkt viel',
      color: '#f8f3e9',
      pattern: '#34332e',
      patternSeed: 39,
      bodyScale: 1.04,
      start: { x: 22.4, z: 4.0 },
      need: 'Wasser',
      before: 'Paula steht fast ununterbrochen an der kleinen Tränke. Sie trinkt in kurzen Abständen, atmet angestrengt und wirkt beim Wiederkäuen weniger entspannt als sonst.',
      after: 'Paula wechselt zwischen Futterplatz und der neuen, größeren Tränke. Sie trinkt ruhiger und beginnt wieder mit dem Wiederkäuen – ein Zeichen für Entspannung.',
      signs: ['ständig an der Tränke', 'angestrengte Atmung', 'wenig Wiederkäuen'],
      science: 'Leistungsstarke Milchkühe setzen viel Wasser über Milch und Stoffwechsel um. Bei Hitze steigt der Wasserbedarf zusätzlich. Kurze Wege zu sauberem Wasser sind wichtig.',
      metric: { label: 'Wasseraufnahme', before: 'gehemmt', after: 'regelmäßig' }
    },
    {
      id: 'edda',
      name: 'Edda',
      breed: 'Rotbunte Holstein',
      age: '8 Jahre',
      lactation: '4. Laktation',
      sensitivity: 2,
      sensitivityLabel: 'niedrig',
      tags: ['gelassen', 'hitzetoleranter', 'Leitkuh'],
      short: 'wirkt trotz Hitze vergleichsweise gelassen',
      color: '#f3e7d8',
      pattern: '#b76b49',
      patternSeed: 53,
      bodyScale: 1.02,
      start: { x: 13.0, z: -1.2 },
      need: 'Ruhe',
      before: 'Edda steht im Halbschatten und wirkt vergleichsweise gelassen. Sie atmet etwas schneller als an kühlen Tagen, frisst aber noch. Ein gutes Beispiel dafür, dass nicht jedes Tier gleich reagiert.',
      after: 'Edda bewegt sich entspannt über die Weide. Sie sucht weiterhin Schatten, zeigt aber keine deutlich angestrengte Atmung mehr.',
      signs: ['leicht erhöhte Atmung', 'sucht Halbschatten'],
      science: 'Individuelle Unterschiede sind normal: Rasse, Fell, Alter, Gesundheitszustand, Leistung und bisherige Klima-Erfahrung prägen die Reaktion.',
      metric: { label: 'Atemzüge', before: '34 / min', after: '24 / min' }
    }
  ];

  DATA.phases = [
    {
      id: 'observe',
      number: 1,
      kicker: 'Beobachten',
      title: 'Wer leidet unter der Hitze?',
      text: 'Gehe auf die Weide und schaue dir drei Kühe genau an. Achte auf Atmung, Bewegung und Rückzug.',
      tasks: [
        { id: 'observe', label: 'Drei Kühe beobachten', detail: 'Gehe nah heran und drücke E oder tippe auf Interagieren.', target: 3 }
      ]
    },
    {
      id: 'measure',
      number: 2,
      kicker: 'Untersuchen',
      title: 'Wie belastend ist das Klima?',
      text: 'Die Wetterstation steht an der Weide. Drücke E am Terminal, um in die Anzeige zu wechseln – erst Temperatur und Luftfeuchte zusammen ergeben ein vollständiges Bild.',
      tasks: [
        { id: 'temp', label: 'Lufttemperatur messen', detail: 'Drücke E am Terminal und klicke auf „TEMP. MESSEN“.', target: 1 },
        { id: 'humidity', label: 'Luftfeuchte messen', detail: 'Klicke im Terminal auf „FEUCHTE MESSEN“. Verlassen mit E.', target: 1 }
      ]
    },
    {
      id: 'act',
      number: 3,
      kicker: 'Handeln',
      title: 'Was hilft der Herde wirklich?',
      text: 'Setze drei passende Maßnahmen um: Schatten, Wasser und Luftbewegung. Jede wirkt über einen anderen Weg.',
      tasks: [
        { id: 'shade', label: 'Schattensegel aufstellen', detail: 'Ein schattiger Rückzugsort senkt die direkte Wärmelast.', target: 1 },
        { id: 'water', label: 'Zusätzliche Tränke aufstellen', detail: 'Mehr Wasser und kürzere Wege entlasten die Tiere.', target: 1 },
        { id: 'ventilation', label: 'Ventilatoren einschalten', detail: 'Luftbewegung unterstützt die Wärmeabgabe.', target: 1 }
      ]
    },
    {
      id: 'followup',
      number: 4,
      kicker: 'Überprüfen',
      title: 'Verändert sich das Verhalten?',
      text: 'Beobachte drei Kühe erneut. Vergleiche Atmung, Aufenthaltsort und Aktivität mit deiner ersten Beobachtung.',
      tasks: [
        { id: 'followup', label: 'Drei Kühe erneut beobachten', detail: 'Kehre zu den Tieren zurück und prüfe die Wirkung.', target: 3 }
      ]
    },
    {
      id: 'evaluate',
      number: 5,
      kicker: 'Auswerten',
      title: 'Zurück zur Forschungsstation',
      text: 'Du hast genug Daten gesammelt. Gehe zur Forschungsstation und schließe die Auswertung ab.',
      tasks: [
        { id: 'analysis', label: 'Forschung auswerten', detail: 'Gehe von Süden vor die Forschungsstation – die Kamera bleibt fest von vorne.', target: 1 }
      ]
    }
  ];

  DATA.measures = {
    shade: {
      id: 'shade',
      title: 'Schattensegel',
      short: 'Schattensegel aufstellen',
      icon: 'shade',
      score: 100,
      journalId: 'shade',
      science: 'Direkte Sonnenstrahlung erhöht die Wärmelast. Ein Schattenplatz senkt die Strahlungswärme und gibt den Tieren einen kühleren Rückzugsort.',
      toast: 'Schatten senkt die direkte Sonnenstrahlung – ein wichtiger erster Schritt.'
    },
    water: {
      id: 'water',
      title: 'Zusätzliche Tränke',
      short: 'Zusätzliche Tränke aufstellen',
      icon: 'droplet',
      score: 100,
      journalId: 'water',
      science: 'Bei Hitze steigt der Wasserbedarf. Kurze Wege zu sauberem Wasser helfen, die Körpertemperatur zu regulieren und den Flüssigkeitshaushalt zu stabilisieren.',
      toast: 'Mehr Wasser und kürzere Wege – wichtig für die Regulation der Körpertemperatur.'
    },
    ventilation: {
      id: 'ventilation',
      title: 'Luftbewegung',
      short: 'Ventilatoren einschalten',
      icon: 'wind',
      score: 100,
      journalId: 'air',
      science: 'Luftbewegung verbessert die Wärmeabgabe über die Haut und unterstützt die Atmung. Sie wirkt besonders gut zusammen mit Schatten.',
      toast: 'Luftbewegung unterstützt die Wärmeabgabe – zusammen mit Schatten besonders wirksam.'
    }
  };

  DATA.journal = [
    {
      id: 'mission',
      icon: 'leaf',
      kicker: 'Auftrag',
      title: 'Ein heißer Sommertag',
      summary: 'Beobachte die Milchkühe auf der Weide, miss das Mikroklima und verbessere die Bedingungen. Am Ende zählt nicht der Ertrag, sondern das Tierwohl.',
      points: ['Hitze verändert Verhalten.', 'Nicht jedes Tier reagiert gleich.', 'Gute Maßnahmen setzen an der Ursache an.'],
      source: 'Forschungsauftrag'
    },
    {
      id: 'heat-signs',
      icon: 'eye',
      kicker: 'Tierbeobachtung',
      title: 'Hitzestress erkennen',
      summary: 'Rinder können Wärme nur begrenzt abgeben. Typische Hinweise sind schnelleres oder tieferes Atmen, vermehrtes Stehen, Schatten suchen, weniger Fressen und ein verändertes Trinkverhalten.',
      points: ['Mehrere Signale zusammen betrachten.', 'Ein einzelnes Anzeichen ist noch keine Diagnose.', 'Vergleiche das Tier mit seinem Normalverhalten.'],
      source: 'Verhaltensbeobachtung'
    },
    {
      id: 'individual',
      icon: 'cow',
      kicker: 'Herdenwissen',
      title: 'Jede Kuh ist anders',
      summary: 'Die Wärmebelastung hängt nicht nur vom Wetter ab. Fellfarbe, Alter, Laktationsphase, Milchleistung, Gesundheit und Gewöhnung machen den Unterschied.',
      points: ['Dunkles Fell nimmt mehr Strahlung auf.', 'Hohe Leistung bedeutet oft mehr Stoffwechselwärme und Wasserbedarf.', 'Beobachte individuell statt nur im Durchschnitt.'],
      source: 'Tierindividuum'
    },
    {
      id: 'thi',
      icon: 'thermometer',
      kicker: 'Klimamessung',
      title: 'Temperatur allein reicht nicht',
      summary: 'Der Temperatur-Hitze-Index (THI) verbindet Lufttemperatur und relative Luftfeuchte. Bei hoher Feuchte verdunstet weniger Schweiß – die Wärmelast steigt.',
      points: ['THI 84,5 an der sonnigen Weide: starke Belastung im Lernmodell.', 'Gängige Orientierung: ab etwa 68 beginnt bei laktierenden Milchkühen eine relevante Belastung.', 'Schwellenwerte sind keine feste Grenze für jedes Tier.'],
      source: 'THI · Lernmodell'
    },
    {
      id: 'shade',
      icon: 'shade',
      kicker: 'Maßnahme',
      title: 'Schatten wirkt sofort',
      summary: 'Schatten senkt die direkte Sonnenstrahlung. Bäume, Segel oder ein offener Unterstand bieten Rückzugsorte – besonders in der Mittagszeit.',
      points: ['Schatten allein löst nicht jedes Hitzeproblem.', 'Ausreichend große, gut erreichbare Flächen anbieten.', 'Luftbewegung und Wasser ergänzen den Effekt.'],
      source: 'Haltungsmanagement'
    },
    {
      id: 'water',
      icon: 'droplet',
      kicker: 'Maßnahme',
      title: 'Wasser ist kein Nebenprodukt',
      summary: 'Milchkühe brauchen viel Wasser. Bei Hitze steigt der Bedarf, während die Tiere gleichzeitig weniger fressen. Kurze Wege zur Tränke sind entscheidend.',
      points: ['Sauberes Wasser regelmäßig kontrollieren.', 'Mehrere Tränken entzerren den Andrang.', 'Trinkverhalten kann ein Frühwarnzeichen sein.'],
      source: 'Wasserversorgung'
    },
    {
      id: 'air',
      icon: 'wind',
      kicker: 'Maßnahme',
      title: 'Luftbewegung unterstützt',
      summary: 'Ventilatoren erhöhen die Luftbewegung und helfen bei der Wärmeabgabe. Sie sind kein Ersatz für Schatten, aber eine wirksame Ergänzung.',
      points: ['Luftbewegung bis auf Tierhöhe bringen.', 'Nicht nur die Lufttemperatur, auch die Feuchte beachten.', 'Zugluft und unnötigen Stress vermeiden.'],
      source: 'Stallklima'
    },
    {
      id: 'debrief',
      icon: 'spark',
      kicker: 'Abschluss',
      title: 'Hitze-Detektiv:in',
      summary: 'Du hast beobachtet, gemessen, gehandelt und überprüft. Genau so entsteht aus einer Beobachtung eine belastbare Erkenntnis – im Spiel und in der Forschung.',
      points: ['Beobachtung ist eine Datenquelle.', 'Messwerte brauchen Kontext.', 'Maßnahmen müssen auf ihre Wirkung geprüft werden.'],
      source: 'FBN · Nutztierkosmos'
    }
  ];

  DATA.tips = [
    'Tipp: Achte auf die Atmung und den Aufenthaltsort – nicht nur auf das Fressen.',
    'Tipp: Die Wetterstation steht am Zugang zur Weide.',
    'Tipp: Mit J öffnest du jederzeit dein Forschungsjournal.',
    'Tipp: Maßnahmen wirken nicht isoliert. Schatten, Wasser und Luftbewegung ergänzen sich.',
    'Tipp: Nach einer Veränderung lohnt sich der zweite Blick auf die Tiere.'
  ];

  DATA.coats = {
    lotte: { base: '#f7f2e8', spots: '#252824' },
    mira: { base: '#f6eadb', spots: '#9d5338' },
    paula: { base: '#faf5eb', spots: '#34342f' },
    edda: { base: '#f2e5d4', spots: '#b66d4d' }
  };

  window.NTK_DATA = DATA;
})();
