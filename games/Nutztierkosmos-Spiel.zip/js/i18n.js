/* =========================================================
   Nutztierkosmos · Sprachen (Deutsch / English)

   Deutsch ist die Quellsprache: Der gesamte Spielcode schreibt
   weiterhin deutsche Texte. Diese Datei übersetzt sie beim
   Anzeigen ins Englische und merkt sich zu jedem Textknoten und
   Attribut das deutsche Original, damit jederzeit hin- und
   hergeschaltet werden kann – ohne den Spielstand anzufassen.

   NTK.TEXTS.en      deutscher Quelltext -> englischer Text
   NTK.t(text)       Text in der aktuellen Sprache (auch für Canvas)
   NTK.locale        'de' oder 'en'
   NTK.setLocale(l)  Sprache umschalten, alle Texte sofort neu
   NTK.onLocaleChange(fn)  Module melden sich für Umschaltungen an

   Classic script, kein Speicher, keine Netzwerkzugriffe.
   ========================================================= */
(function () {
  'use strict';

  var NTK = window.NTK = window.NTK || {};

  /* ---------------------------------------------------------
     Wörterbuch: deutscher Quelltext -> Englisch
     --------------------------------------------------------- */
  var EN = {
    /* ---- Dokument ---- */
    'Nutztierkosmos · Ein heißer Tag auf der Weide': 'Nutztierkosmos · A hot day in the pasture',
    'Ein interaktives Lernspiel des FBN zu Hitzestress bei Milchkühen.': 'An interactive FBN learning game about heat stress in dairy cows.',
    'Ein heißer Tag auf der Weide': 'A hot day in the pasture',
    'Hitzestress bei Milchkühen': 'Heat stress in dairy cows',
    'Hochsommer': 'Midsummer',
    'Der Forschungsbauernhof wird aufgebaut …': 'Setting up the research farm …',
    'Der Hof konnte nicht geladen werden.': 'The farm could not be loaded.',
    'Bitte lade die Seite neu. Das Spiel benötigt WebGL und JavaScript.': 'Please reload the page. The game requires WebGL and JavaScript.',
    'Unerwarteter Fehler im Spiel.': 'Unexpected error in the game.',
    '3D-Szene konnte nicht initialisiert werden.': 'The 3D scene could not be initialised.',
    '3D-Spielwelt: Forschungsbauernhof mit Kuhweide': '3D game world: research farm with cow pasture',

    /* ---- HUD ---- */
    'Spieler:in': 'Player',
    'Forscher:in': 'Researcher',
    'Ton ausschalten': 'Mute sound',
    'Ton einschalten': 'Unmute sound',
    'Forschungsjournal öffnen': 'Open research journal',
    'Pause und Einstellungen': 'Pause and settings',
    'Aktueller Forschungsauftrag': 'Current research task',
    'Dein Auftrag': 'Your task',
    'Forschungsjournal': 'Research journal',
    'Interagieren': 'Interact',
    'drücken': 'Press',
    'bewegen': 'move',
    'rennen': 'run',
    'Mausrad': 'Mouse wheel',
    'interagieren': 'interact',
    'schließen': 'close',
    'Bewegungssteuerung': 'Movement control',
    'Rennen umschalten': 'Toggle running',
    'Rennen einschalten': 'Start running',
    'Rennen ausschalten': 'Stop running',
    'Rennen': 'Run',
    'Verlassen': 'Leave',
    'Auswertung öffnen': 'Open results',

    /* ---- Positions-Log (Diagnose) ---- */
    'Positions-Log': 'Position log',
    'Log schließen': 'Close log',
    '5 s aufzeichnen': 'Record 5 s',
    'In Zwischenablage': 'Copy to clipboard',
    'Bereit.': 'Ready.',
    'Positionsprotokoll': 'Position log',
    'Zeichne 5 s auf – bewege dich jetzt.': 'Recording 5 s – move now.',
    'Noch keine Aufzeichnung.': 'No recording yet.',
    'In die Zwischenablage kopiert.': 'Copied to clipboard.',
    'Kopieren blockiert – Text ist markiert (Strg+C).': 'Copy blocked – text is selected (Ctrl+C).',

    /* ---- Intro ---- */
    'FBN · Forschungsbauernhof': 'FBN · Research farm',
    'Sommer · 11:20 Uhr': 'Summer · 11:20 a.m.',
    'Mission 1 · Tierwohl': 'Mission 1 · Animal welfare',
    'Ein heißer Tag': 'A hot day',
    'auf der Weide': 'in the pasture',
    'Die Sonne brennt. Auf der Kuhweide verhalten sich die Tiere anders als sonst. Finde heraus, was ihnen zu schaffen macht – und was wirklich hilft.': 'The sun is blazing. On the cow pasture the animals are behaving differently than usual. Find out what is troubling them – and what really helps.',
    'Willkommen im Forschungsteam': 'Welcome to the research team',
    'Beobachten': 'Observe',
    'Verhalten lesen': 'Read behaviour',
    'Messen': 'Measure',
    'Klima verstehen': 'Understand the climate',
    'Handeln': 'Act',
    'Tierwohl verbessern': 'Improve welfare',
    'Forschung starten': 'Start research',
    'ca. 8–12 Minuten': 'approx. 8–12 minutes',
    'Tastatur & Touch': 'Keyboard & touch',
    'ohne Speicherung': 'no data stored',
    'Steuerung ansehen': 'Show controls',
    'Bewegen': 'Move',
    'Feste Kamera': 'Fixed camera',
    'immer von vorne': 'always from the front',
    'von vorne': 'from the front',
    'Ein Lernspiel des FBN – Leibniz-Institut für Nutztierbiologie · Wissenschaftlich eingeordnet, spielerisch vereinfacht.': 'A learning game by the FBN – Leibniz Institute for Farm Animal Biology · Scientifically grounded, playfully simplified.',

    /* ---- Journal ---- */
    'Deine Entdeckungen': 'Your discoveries',
    'Journal schließen': 'Close journal',
    'Deine Forschung beginnt': 'Your research begins',
    'Erste Spuren': 'First clues',
    'Zusammenhänge erkennen': 'Spotting connections',
    'Fast vollständig': 'Almost complete',
    'Forschung komplett': 'Research complete',
    'Beobachte die Herde, miss das Klima und dokumentiere, was du herausfindest.': 'Observe the herd, measure the climate and record what you find out.',
    'Alle Einträge entdeckt. Du kannst deine Erkenntnisse jederzeit nachlesen.': 'All entries discovered. You can reread your findings at any time.',
    'Noch nicht entdeckt': 'Not yet discovered',
    'Beobachte, miss und handle, um diese Seite freizuschalten.': 'Observe, measure and act to unlock this page.',
    'Einordnung:': 'Please note:',
    'Das Spiel ist ein Lernmodell. Am FBN werden unter anderem Haltung, Klima und Tierwohl von Nutztieren untersucht. Reale Schwellenwerte hängen von Rasse, Leistung, Gesundheit, Klima und Management ab. Das Spiel ersetzt keine konkrete Forschungsstudie.': 'This game is a learning model. Research at the FBN includes the husbandry, climate and welfare of farm animals. Real thresholds depend on breed, performance, health, climate and management. The game is no substitute for an actual research study.',
    'Zurück zur Weide': 'Back to the pasture',

    /* ---- Messung (Fenster und Terminal) ---- */
    'Messstation · Weide': 'Measuring station · Pasture',
    'Das Mikroklima messen': 'Measure the microclimate',
    'Messung schließen': 'Close measurement',
    'Nimm Thermometer und Hygrometer aus dem Forschungskoffer. Miss direkt in der Sonne – dort, wo die Kühe stehen.': 'Take the thermometer and hygrometer from the research kit. Measure right in the sun – where the cows are standing.',
    'Lufttemperatur': 'Air temperature',
    'Luftfeuchte': 'Humidity',
    'Gemessen': 'Measured',
    'Temperatur-Hitze-Index': 'Temperature-humidity index',
    'noch keine Messung': 'no measurement yet',
    'entspannt': 'relaxed',
    'belastend': 'stressful',
    'stark': 'severe',
    'Starke Hitzebelastung': 'Severe heat stress',
    'Miss Temperatur und Luftfeuchte, um die kombinierte Wärmebelastung einzuschätzen.': 'Measure temperature and humidity to assess the combined heat load.',
    'Warum zählt die Luftfeuchte?': 'Why does humidity matter?',
    'Bei hoher Luftfeuchte verdunstet weniger Schweiß. Rinder können dann weniger Wärme über die Atmung und die Haut abgeben. Deshalb ist der THI aussagekräftiger als die Temperatur allein.': 'When humidity is high, less sweat evaporates. Cattle can then give off less heat through breathing and the skin. That is why the THI tells you more than temperature alone.',
    'Der THI kombiniert Lufttemperatur und Luftfeuchte. Bei hoher Feuchte kann der Körper weniger Wärme über Verdunstung abgeben – die Belastung steigt.': 'The THI combines air temperature and humidity. When humidity is high, the body can give off less heat through evaporation – the load increases.',
    'THI 84,5 auf der sonnigen Weide: starke Hitzebelastung. Ab etwa 68 beginnt bei laktierenden Milchkühen eine relevante Belastung. Individuelle Unterschiede bleiben wichtig.': 'THI 84.5 on the sunny pasture: severe heat stress. From about 68, lactating dairy cows start to experience relevant stress. Individual differences still matter.',
    'Messung abschließen': 'Finish measurement',
    'Klima gemessen': 'Climate measured',
    'Starke Wärmebelastung. Jetzt helfen Schatten, Wasser und Luftbewegung.': 'Severe heat load. Shade, water and air movement will help now.',

    'FBN // WETTERSTATION': 'FBN // WEATHER STATION',
    'WEIDE-01 · SONNE': 'PASTURE-01 · SUN',
    'WEIDE-01 · MIKROKLIMA · THI': 'PASTURE-01 · MICROCLIMATE · THI',
    'MIKROKLIMA / 11:20 UHR': 'MICROCLIMATE / 11:20 AM',
    'Klima erfassen': 'Record climate',
    'Miss direkt in der Sonne – dort, wo die Kühe stehen.': 'Measure right in the sun – where the cows are standing.',
    'LUFTTEMPERATUR': 'AIR TEMP.',
    'LUFTFEUCHTE': 'HUMIDITY',
    '[ TEMP. MESSEN ]': '[ READ TEMP. ]',
    '[ FEUCHTE MESSEN ]': '[ READ HUMIDITY ]',
    '[ GEMESSEN ]': '[ MEASURED ]',
    '[ GESPERRT ]': '[ LOCKED ]',
    'THI / WÄRMEBELASTUNG': 'THI / HEAT LOAD',
    'KEINE MESSUNG': 'NO READING',
    'MESSUNG AUSSTEHEND': 'READING PENDING',
    'STARKE HITZEBELASTUNG': 'SEVERE HEAT STRESS',
    'ENTSPANNT': 'RELAXED',
    'BELASTEND': 'STRESSFUL',
    'STARK': 'SEVERE',
    'Temperatur und Luftfeuchte ergeben zusammen ein vollständiges Bild.': 'Temperature and humidity together give the full picture.',
    'ORIENTIERUNG: AB THI ≈ 68 BEGINNT BEI LAKTIERENDEN MILCHKÜHEN EINE RELEVANTE BELASTUNG.': 'GUIDE: FROM THI ≈ 68, LACTATING DAIRY COWS START TO EXPERIENCE RELEVANT HEAT STRESS.',
    'SYSTEM BEREIT · KLICKEN ZUM MESSEN · E ZUM VERLASSEN': 'SYSTEM READY · CLICK TO MEASURE · E TO EXIT',
    'BEREIT · KLICKEN ZUM MESSEN · E ZUM VERLASSEN': 'READY · CLICK TO MEASURE · E TO EXIT',
    'MESSUNG VOLLSTÄNDIG · E ZUM VERLASSEN': 'MEASUREMENT COMPLETE · E TO EXIT',
    'TERMINAL GESPERRT · E ZUM VERLASSEN': 'TERMINAL LOCKED · E TO EXIT',
    'MESSUNG OK': 'READING OK',
    'GESPERRT': 'LOCKED',
    'LUFTFEUCHTE NOCH MESSEN': 'NOW MEASURE HUMIDITY',
    'LUFTTEMPERATUR NOCH MESSEN': 'NOW MEASURE AIR TEMPERATURE',
    '> KLICKEN / TIPPEN ZUM MESSEN': '> CLICK / TAP TO MEASURE',
    'SYSTEM BEREIT · FORSCHUNGSBAUERNHOF': 'SYSTEM READY · RESEARCH FARM',

    /* ---- Kuhfenster ---- */
    'Fenster verschieben': 'Move window',
    'Beobachtung · Kuhweide': 'Observation · Cow pasture',
    'Vergleich · nach den Maßnahmen': 'Comparison · after the measures',
    'Tierbeobachtung schließen': 'Close animal observation',
    'Bereiche der Tierbeobachtung': 'Sections of the animal observation',
    'Kamera': 'Camera',
    'Steckbrief': 'Profile',
    'Verhalten': 'Behaviour',
    'Klima': 'Climate',
    'Wissen': 'Science',
    'Hitzeempfindlichkeit': 'Heat sensitivity',
    'Beobachtung notieren': 'Note observation',
    'Vergleich abschließen': 'Finish comparison',
    'Rasse': 'Breed',
    'Alter': 'Age',
    'Laktation': 'Lactation',
    'Wichtiges Bedürfnis': 'Key need',
    'Dieselbe Hitze kann bei jeder Kuh anders ankommen. Beobachte das Tier, nicht nur den Stallwert.': 'The same heat can affect each cow differently. Watch the animal, not just the barn reading.',
    'Erste Beobachtung': 'First observation',
    'Vergleich nach den Maßnahmen': 'Comparison after the measures',
    'Vor den Maßnahmen': 'Before the measures',
    'Danach': 'Afterwards',
    'nach den Maßnahmen': 'after the measures',
    'Beobachtungsfokus: Achte auf Atmung, Aufenthaltsort und Futteraufnahme. Vergleiche die Kuh mit ihrem Normalverhalten.': 'What to watch: breathing, location and feed intake. Compare the cow with her normal behaviour.',
    'FBN-Bezug': 'FBN link',
    'Am FBN wird untersucht, wie Klima, Haltung und Fütterung das Wohlbefinden von Nutztieren beeinflussen.': 'The FBN studies how climate, husbandry and feeding affect the well-being of farm animals.',
    'Merksatz': 'Remember',
    'Jede Kuh reagiert individuell. Beobachte das Tier – nicht nur den Stallwert.': 'Every cow responds individually. Watch the animal – not just the barn reading.',
    'Erste Beobachtung notiert': 'First observation noted',
    'Vergleich notiert': 'Comparison noted',

    /* ---- Auswertung ---- */
    'Mission abgeschlossen': 'Mission complete',
    'Hitze verstehen. Tierwohl verbessern.': 'Understand heat. Improve welfare.',
    'Du hast die Zeichen der Herde gelesen und die Weide an einem heißen Tag sicherer gemacht.': 'You read the herd’s signals and made the pasture safer on a hot day.',
    'von': 'of',
    'Punkten': 'points',
    'Forschungsabzeichen': 'Research badge',
    'Hitze-Detektiv:in': 'Heat detective',
    'Deine Reise': 'Your journey',
    'Was du beobachtet hast': 'What you observed',
    'Die Wissenschaft dahinter': 'The science behind it',
    'Schatten': 'Shade',
    'Wasser': 'Water',
    'Ruhe': 'Rest',
    'Luftbewegung': 'Air movement',
    'Direkte Sonnenstrahlung erhöht die Wärmelast. Schatten und Unterstände senken sie spürbar – besonders in der Mittagszeit.': 'Direct sunlight increases the heat load. Shade and shelters reduce it noticeably – especially around midday.',
    'Rinder kühlen über Verdunstung und brauchen bei Hitze mehr Wasser. Eine erreichbare, saubere Tränke ist deshalb zentral.': 'Cattle cool down through evaporation and need more water in the heat. A clean drinking trough within easy reach is therefore essential.',
    'Ventilatoren verbessern die Wärmeabgabe über Haut und Atmung. Sie ersetzen keinen Schatten, ergänzen ihn aber wirksam.': 'Fans improve heat loss through the skin and breathing. They do not replace shade, but complement it effectively.',
    'Wichtig einzuordnen:': 'Important context:',
    'Der THI ist eine Orientierung. Ab wann ein Tier leidet, hängt unter anderem von Rasse, Fellfarbe, Laktationsphase, Leistung, Alter, Gesundheit und Gewöhnung ab. Das Spiel zeigt ein vereinfachtes Lernmodell, keine individuelle tierärztliche Diagnose.': 'The THI is a guide. When an animal starts to suffer depends on breed, coat colour, stage of lactation, performance, age, health and acclimatisation, among other things. The game shows a simplified learning model, not an individual veterinary diagnosis.',
    'Weiter auf dem Hof': 'Stay on the farm',
    'Noch einmal erforschen': 'Explore again',
    'Gesamt': 'Total',
    'reagiert': 'responds',
    'Drei Kühe beobachtet': 'Three cows observed',
    'Temperatur und Luftfeuchte gemessen': 'Temperature and humidity measured',
    'Drei passende Maßnahmen umgesetzt': 'Three suitable measures implemented',
    'Wirkung bei drei Kühen überprüft': 'Effect checked on three cows',
    'Forschung ausgewertet': 'Research evaluated',
    'Abgeschlossen': 'Completed',
    'Hitze verstanden.': 'Heat understood.',
    'Du hast beobachtet, gemessen, gehandelt und die Wirkung überprüft.': 'You observed, measured, acted and checked the effect.',
    'Deine Erkenntnisse stehen im Journal.': 'Your findings are in the journal.',

    /* ---- Pause ---- */
    'Unterbrochen': 'Paused',
    'Pause schließen': 'Close pause menu',
    'Die Weide wartet. Atme kurz durch.': 'The pasture can wait. Take a breather.',
    'Die Lernplattform hat das Spiel pausiert. Deine Forschung wartet.': 'The learning platform has paused the game. Your research is waiting.',
    'Ton': 'Sound',
    'Vogelstimmen, Wind und Rückmeldungen': 'Birdsong, wind and feedback sounds',
    'Musik': 'Music',
    'Hintergrundmusik an oder aus': 'Background music on or off',
    'Musiklautstärke': 'Music volume',
    'aus': 'off',
    'Bewegung reduzieren': 'Reduce motion',
    'Ruhigere Kamera und weniger Effekte': 'Calmer camera and fewer effects',
    'Neu starten': 'Restart',
    'Weiterforschen': 'Continue',
    'Dieses Spiel speichert keine Daten auf deinem Gerät. Dein Fortschritt bleibt nur in dieser Sitzung.': 'This game does not store any data on your device. Your progress is kept only for this session.',

    /* ---- Hinweise (Toasts) ---- */
    'Auftrag gestartet': 'Task started',
    'Beobachte drei Kühe auf der Weide. Achte auf Atmung, Unruhe und Rückzugsorte.': 'Observe three cows on the pasture. Watch their breathing, restlessness and where they retreat to.',
    'Erster Hinweis': 'First tip',
    'Touch-Steuerung': 'Touch controls',
    'Analog-Pad links bewegt dich. Rechts unten: Interagieren und Rennen. Die Kamera bleibt fest von vorne.': 'The pad on the left moves you. Bottom right: interact and run. The camera stays fixed at the front.',
    'Jetzt untersuchen': 'Now investigate',
    'Die Wetterstation steht am Weideeingang. Bediene das Display direkt am Terminal.': 'The weather station is at the pasture entrance. Use the display right at the terminal.',
    'Jetzt handeln': 'Now act',
    'Drei Maßnahmen stehen bereit: Schatten, Wasser und Luftbewegung.': 'Three measures are ready: shade, water and air movement.',
    'Wirkung prüfen': 'Check the effect',
    'Beobachte drei der Kühe erneut und vergleiche ihr Verhalten.': 'Observe three of the cows again and compare their behaviour.',
    'Daten auswerten': 'Evaluate the data',
    'Gehe zur Forschungsstation südlich der Weide und schließe die Auswertung ab.': 'Go to the research station south of the pasture and complete the evaluation.',
    'Weiter': 'Next',
    'Schattensegel umgesetzt': 'Shade sail put up',
    'Zusätzliche Tränke umgesetzt': 'Extra trough installed',
    'Luftbewegung umgesetzt': 'Fans switched on',

    /* ---- Interaktionen ---- */
    'beobachten': 'observe',
    'vergleichen': 'compare',
    'Wetterstation verlassen': 'Leave weather station',
    'Wetterstation verlassen (E)': 'Leave weather station (E)',
    'Wetterstation bedienen (E)': 'Use weather station (E)',
    'Schattensegel aufstellen': 'Put up shade sail',
    'Zusätzliche Tränke aufstellen': 'Add a drinking trough',
    'Ventilatoren einschalten': 'Switch on fans',
    'Forschung auswerten': 'Evaluate research',
    'Vergleichen': 'Compare',
    'Tränke': 'Trough',
    'Lüftung': 'Fans',
    'Auswerten': 'Evaluate',

    /* ---- 3D-Welt: Marker, Schilder, Orte ---- */
    'Bedienen': 'Use',
    'Schatten bauen': 'Build shade',
    'Tränke bauen': 'Add trough',
    'Lüftung starten': 'Start fans',
    'HITZE?': 'HEAT?',
    'LAUFSTALL': 'OPEN BARN',
    'LUFT · SCHATTEN · RÜCKZUG': 'AIR · SHADE · RETREAT',
    'FORSCHUNG': 'RESEARCH',
    'TIERWOHL · KLIMA · VERHALTEN': 'WELFARE · CLIMATE · BEHAVIOUR',
    'KUHWEIDE': 'COW PASTURE',
    'FORSCHUNGSHERDE': 'RESEARCH HERD',
    'SCHWEINE': 'PIGS',
    'WÜHLEN · ERKUNDEN': 'ROOTING · EXPLORING',
    'HÜHNERHOF': 'CHICKEN YARD',
    'SITZSTANGE · SAND': 'PERCH · SAND',
    'FUTTERGARTEN': 'FORAGE GARDEN',
    'PFLANZEN · KREISLAUF': 'PLANTS · CYCLE',
    'WETTERSTATION': 'WEATHER STATION',
    'MIKROKLIMA · THI': 'MICROCLIMATE · THI',
    'Offener Laufstall': 'Open barn',
    'Kuhweide': 'Cow pasture',
    'Forschungsstation': 'Research station',
    'Schweinegehege': 'Pig pen',
    'Hühnerhof': 'Chicken yard',
    'Futtergarten': 'Forage garden',
    'Hofweg': 'Farm track',
    'Forschungshof': 'Research farm',

    /* ---- Kühe ---- */
    'Schwarzbunte Holstein': 'Black-and-white Holstein',
    'Rotbunte Holstein': 'Red-and-white Holstein',
    '3 Jahre': '3 years',
    '5 Jahre': '5 years',
    '6 Jahre': '6 years',
    '8 Jahre': '8 years',
    '1. Laktation': '1st lactation',
    '2. Laktation': '2nd lactation',
    '3. Laktation': '3rd lactation',
    '4. Laktation': '4th lactation',
    'niedrig': 'low',
    'mittel': 'medium',
    'hoch': 'high',
    'Atemzüge': 'Breaths',
    'Platzwechsel': 'Changes of place',
    'Wasseraufnahme': 'Water intake',
    'sehr häufig': 'very often',
    'selten': 'rarely',
    'gehemmt': 'hindered',
    'regelmäßig': 'regular',

    'Erfahrene Kuh': 'Experienced cow',
    'dunkles Fell': 'dark coat',
    'ruhig': 'calm',
    'steht im Schatten und atmet schnell': 'is standing in the shade, breathing fast',
    'Lotte steht dicht am Stamm der alten Eiche. Ihr Flankenatmen ist deutlich sichtbar, der Kopf hängt tief. Sie frisst kaum und weicht nicht aus dem Schatten.': 'Lotte is standing close to the trunk of the old oak. Her flanks are heaving visibly and her head hangs low. She is barely eating and will not leave the shade.',
    'Lotte steht entspannter unter dem Schattensegel. Die Atemzüge sind ruhiger, sie senkt den Kopf zum Gras und bleibt nicht mehr starr stehen.': 'Lotte is standing more relaxed under the shade sail. Her breathing is calmer, she lowers her head to the grass and no longer stands rigidly.',
    'schnelle Atmung': 'rapid breathing',
    'verkrampftes Stehen': 'tense standing',
    'wenig Futteraufnahme': 'low feed intake',
    'Dunkles Fell nimmt mehr Sonnenstrahlung auf. Bei Hitze verlagern Rinder die Wärmeabgabe auf die Atmung – sichtbar an schnellerem, tieferem Atmen.': 'A dark coat absorbs more solar radiation. In the heat, cattle shift heat loss to breathing – visible as faster, deeper breaths.',

    'jung': 'young',
    'erstlaktierend': 'first lactation',
    'wärmesensibel': 'heat-sensitive',
    'sucht auffällig Schatten und steht viel': 'keeps seeking shade and stands a lot',
    'Mira pendelt zwischen dem kleinen Schattenplatz und der offenen Weide. Sie steht viel, wirkt unruhig und leckt sich häufiger über das Maul. Fressen interessiert sie gerade wenig.': 'Mira moves back and forth between the small shady spot and the open pasture. She stands a lot, seems restless and licks her muzzle more often. Right now she has little interest in eating.',
    'Mira nutzt den neuen Schatten ruhig und verteilt sich wieder besser auf die Weide. Sie bleibt länger an einem Ort, ohne ständig den Platz zu wechseln.': 'Mira calmly uses the new shade and ranges across the pasture again. She stays longer in one place without constantly moving on.',
    'Unruhe': 'restlessness',
    'ständiger Platzwechsel': 'constantly changing place',
    'vermindertes Fressen': 'reduced eating',
    'Junge, erstlaktierende Kühe reagieren nicht automatisch gleich wie ältere Tiere. Gewöhnung, Stoffwechsel und Leistung beeinflussen die individuelle Wärmebelastung.': 'Young cows in their first lactation do not automatically respond like older animals. Acclimatisation, metabolism and performance influence the individual heat load.',

    'hohe Milchleistung': 'high milk yield',
    'viel Durst': 'very thirsty',
    'sozial': 'sociable',
    'steht an der Tränke und trinkt viel': 'stands at the trough and drinks a lot',
    'Paula steht fast ununterbrochen an der kleinen Tränke. Sie trinkt in kurzen Abständen, atmet angestrengt und wirkt beim Wiederkäuen weniger entspannt als sonst.': 'Paula stands at the small trough almost non-stop. She drinks at short intervals, breathes heavily and seems less relaxed than usual while ruminating.',
    'Paula wechselt zwischen Futterplatz und der neuen, größeren Tränke. Sie trinkt ruhiger und beginnt wieder mit dem Wiederkäuen – ein Zeichen für Entspannung.': 'Paula moves between the feeding area and the new, larger trough. She drinks more calmly and starts ruminating again – a sign of relaxation.',
    'ständig an der Tränke': 'always at the trough',
    'angestrengte Atmung': 'laboured breathing',
    'wenig Wiederkäuen': 'little rumination',
    'Leistungsstarke Milchkühe setzen viel Wasser über Milch und Stoffwechsel um. Bei Hitze steigt der Wasserbedarf zusätzlich. Kurze Wege zu sauberem Wasser sind wichtig.': 'High-yielding dairy cows turn over a lot of water through milk and metabolism. In the heat their water requirement rises further. Short distances to clean water are important.',

    'gelassen': 'easy-going',
    'hitzetoleranter': 'more heat-tolerant',
    'Leitkuh': 'lead cow',
    'wirkt trotz Hitze vergleichsweise gelassen': 'seems fairly calm despite the heat',
    'Edda steht im Halbschatten und wirkt vergleichsweise gelassen. Sie atmet etwas schneller als an kühlen Tagen, frisst aber noch. Ein gutes Beispiel dafür, dass nicht jedes Tier gleich reagiert.': 'Edda is standing in partial shade and seems fairly calm. She is breathing a little faster than on cool days but is still eating. A good example that not every animal responds in the same way.',
    'Edda bewegt sich entspannt über die Weide. Sie sucht weiterhin Schatten, zeigt aber keine deutlich angestrengte Atmung mehr.': 'Edda moves across the pasture in a relaxed way. She still seeks shade but no longer shows clearly laboured breathing.',
    'leicht erhöhte Atmung': 'slightly faster breathing',
    'sucht Halbschatten': 'seeks partial shade',
    'Individuelle Unterschiede sind normal: Rasse, Fell, Alter, Gesundheitszustand, Leistung und bisherige Klima-Erfahrung prägen die Reaktion.': 'Individual differences are normal: breed, coat, age, health, performance and previous climate experience shape the response.',

    /* ---- Phasen ---- */
    'Wer leidet unter der Hitze?': 'Who is suffering in the heat?',
    'Gehe auf die Weide und schaue dir drei Kühe genau an.': 'Go to the pasture and take a close look at three cows.',
    'Gehe auf die Weide und schaue dir drei Kühe genau an. Achte auf Atmung, Bewegung und Rückzug.': 'Go to the pasture and take a close look at three cows. Watch their breathing, movement and retreat.',
    'Drei Kühe beobachten': 'Observe three cows',
    'Gehe nah heran und drücke E oder tippe auf Interagieren.': 'Move in close and press E or tap Interact.',
    'Untersuchen': 'Investigate',
    'Wie belastend ist das Klima?': 'How stressful is the climate?',
    'Die Wetterstation steht an der Weide. Drücke E am Terminal, um in die Anzeige zu wechseln – erst Temperatur und Luftfeuchte zusammen ergeben ein vollständiges Bild.': 'The weather station is by the pasture. Press E at the terminal to switch to the display – only temperature and humidity together give the full picture.',
    'Lufttemperatur messen': 'Measure air temperature',
    'Drücke E am Terminal und klicke auf „TEMP. MESSEN“.': 'Press E at the terminal and click “READ TEMP.”.',
    'Luftfeuchte messen': 'Measure humidity',
    'Klicke im Terminal auf „FEUCHTE MESSEN“. Verlassen mit E.': 'Click “READ HUMIDITY” in the terminal. Press E to leave.',
    'Was hilft der Herde wirklich?': 'What really helps the herd?',
    'Setze drei passende Maßnahmen um: Schatten, Wasser und Luftbewegung. Jede wirkt über einen anderen Weg.': 'Put three suitable measures in place: shade, water and air movement. Each works in a different way.',
    'Ein schattiger Rückzugsort senkt die direkte Wärmelast.': 'A shady retreat reduces the direct heat load.',
    'Mehr Wasser und kürzere Wege entlasten die Tiere.': 'More water and shorter distances ease the strain on the animals.',
    'Luftbewegung unterstützt die Wärmeabgabe.': 'Air movement helps the animals give off heat.',
    'Überprüfen': 'Check',
    'Verändert sich das Verhalten?': 'Does the behaviour change?',
    'Beobachte drei Kühe erneut. Vergleiche Atmung, Aufenthaltsort und Aktivität mit deiner ersten Beobachtung.': 'Observe three cows again. Compare breathing, location and activity with your first observation.',
    'Drei Kühe erneut beobachten': 'Observe three cows again',
    'Kehre zu den Tieren zurück und prüfe die Wirkung.': 'Return to the animals and check the effect.',
    'Zurück zur Forschungsstation': 'Back to the research station',
    'Du hast genug Daten gesammelt. Gehe zur Forschungsstation und schließe die Auswertung ab.': 'You have collected enough data. Go to the research station and complete the evaluation.',
    'Gehe von Süden vor die Forschungsstation – die Kamera bleibt fest von vorne.': 'Approach the research station from the south – the camera stays fixed at the front.',

    /* ---- Maßnahmen ---- */
    'Schattensegel': 'Shade sail',
    'Zusätzliche Tränke': 'Extra drinking trough',
    'Direkte Sonnenstrahlung erhöht die Wärmelast. Ein Schattenplatz senkt die Strahlungswärme und gibt den Tieren einen kühleren Rückzugsort.': 'Direct sunlight increases the heat load. A shaded area reduces radiant heat and gives the animals a cooler place to retreat to.',
    'Schatten senkt die direkte Sonnenstrahlung – ein wichtiger erster Schritt.': 'Shade reduces direct solar radiation – an important first step.',
    'Bei Hitze steigt der Wasserbedarf. Kurze Wege zu sauberem Wasser helfen, die Körpertemperatur zu regulieren und den Flüssigkeitshaushalt zu stabilisieren.': 'Water requirements rise in the heat. Short distances to clean water help regulate body temperature and keep the fluid balance stable.',
    'Mehr Wasser und kürzere Wege – wichtig für die Regulation der Körpertemperatur.': 'More water and shorter distances – important for regulating body temperature.',
    'Luftbewegung verbessert die Wärmeabgabe über die Haut und unterstützt die Atmung. Sie wirkt besonders gut zusammen mit Schatten.': 'Air movement improves heat loss through the skin and supports breathing. It works especially well together with shade.',
    'Luftbewegung unterstützt die Wärmeabgabe – zusammen mit Schatten besonders wirksam.': 'Air movement helps heat loss – especially effective together with shade.',

    /* ---- Journal-Einträge ---- */
    'Auftrag': 'Task',
    'Ein heißer Sommertag': 'A hot summer day',
    'Beobachte die Milchkühe auf der Weide, miss das Mikroklima und verbessere die Bedingungen. Am Ende zählt nicht der Ertrag, sondern das Tierwohl.': 'Observe the dairy cows on the pasture, measure the microclimate and improve the conditions. In the end it is not yield that counts, but animal welfare.',
    'Hitze verändert Verhalten.': 'Heat changes behaviour.',
    'Nicht jedes Tier reagiert gleich.': 'Not every animal responds in the same way.',
    'Gute Maßnahmen setzen an der Ursache an.': 'Good measures tackle the cause.',
    'Forschungsauftrag': 'Research task',

    'Tierbeobachtung': 'Animal observation',
    'Hitzestress erkennen': 'Recognising heat stress',
    'Rinder können Wärme nur begrenzt abgeben. Typische Hinweise sind schnelleres oder tieferes Atmen, vermehrtes Stehen, Schatten suchen, weniger Fressen und ein verändertes Trinkverhalten.': 'Cattle can only give off a limited amount of heat. Typical signs are faster or deeper breathing, standing more, seeking shade, eating less and a change in drinking behaviour.',
    'Mehrere Signale zusammen betrachten.': 'Look at several signals together.',
    'Ein einzelnes Anzeichen ist noch keine Diagnose.': 'A single sign is not yet a diagnosis.',
    'Vergleiche das Tier mit seinem Normalverhalten.': 'Compare the animal with its normal behaviour.',
    'Verhaltensbeobachtung': 'Behavioural observation',

    'Herdenwissen': 'Herd knowledge',
    'Jede Kuh ist anders': 'Every cow is different',
    'Die Wärmebelastung hängt nicht nur vom Wetter ab. Fellfarbe, Alter, Laktationsphase, Milchleistung, Gesundheit und Gewöhnung machen den Unterschied.': 'Heat load does not depend on the weather alone. Coat colour, age, stage of lactation, milk yield, health and acclimatisation make the difference.',
    'Dunkles Fell nimmt mehr Strahlung auf.': 'A dark coat absorbs more radiation.',
    'Hohe Leistung bedeutet oft mehr Stoffwechselwärme und Wasserbedarf.': 'High performance often means more metabolic heat and a greater need for water.',
    'Beobachte individuell statt nur im Durchschnitt.': 'Observe individuals, not just the average.',
    'Tierindividuum': 'Individual animal',

    'Klimamessung': 'Climate measurement',
    'Temperatur allein reicht nicht': 'Temperature alone is not enough',
    'Der Temperatur-Hitze-Index (THI) verbindet Lufttemperatur und relative Luftfeuchte. Bei hoher Feuchte verdunstet weniger Schweiß – die Wärmelast steigt.': 'The temperature-humidity index (THI) combines air temperature and relative humidity. When humidity is high, less sweat evaporates – the heat load rises.',
    'THI 84,5 an der sonnigen Weide: starke Belastung im Lernmodell.': 'THI 84.5 on the sunny pasture: severe stress in the learning model.',
    'Gängige Orientierung: ab etwa 68 beginnt bei laktierenden Milchkühen eine relevante Belastung.': 'Common rule of thumb: from about 68, lactating dairy cows start to experience relevant stress.',
    'Schwellenwerte sind keine feste Grenze für jedes Tier.': 'Thresholds are not a fixed limit for every animal.',
    'THI · Lernmodell': 'THI · Learning model',

    'Maßnahme': 'Measure',
    'Schatten wirkt sofort': 'Shade works straight away',
    'Schatten senkt die direkte Sonnenstrahlung. Bäume, Segel oder ein offener Unterstand bieten Rückzugsorte – besonders in der Mittagszeit.': 'Shade reduces direct solar radiation. Trees, sails or an open shelter offer places to retreat to – especially around midday.',
    'Schatten allein löst nicht jedes Hitzeproblem.': 'Shade alone does not solve every heat problem.',
    'Ausreichend große, gut erreichbare Flächen anbieten.': 'Provide areas that are large enough and easy to reach.',
    'Luftbewegung und Wasser ergänzen den Effekt.': 'Air movement and water add to the effect.',
    'Haltungsmanagement': 'Husbandry management',

    'Wasser ist kein Nebenprodukt': 'Water is no side issue',
    'Milchkühe brauchen viel Wasser. Bei Hitze steigt der Bedarf, während die Tiere gleichzeitig weniger fressen. Kurze Wege zur Tränke sind entscheidend.': 'Dairy cows need a lot of water. In the heat the requirement rises while the animals eat less. Short distances to the drinking trough are crucial.',
    'Sauberes Wasser regelmäßig kontrollieren.': 'Check regularly that the water is clean.',
    'Mehrere Tränken entzerren den Andrang.': 'Several troughs ease the crowding.',
    'Trinkverhalten kann ein Frühwarnzeichen sein.': 'Drinking behaviour can be an early warning sign.',
    'Wasserversorgung': 'Water supply',

    'Luftbewegung unterstützt': 'Air movement helps',
    'Ventilatoren erhöhen die Luftbewegung und helfen bei der Wärmeabgabe. Sie sind kein Ersatz für Schatten, aber eine wirksame Ergänzung.': 'Fans increase air movement and help the animals give off heat. They are no substitute for shade, but an effective addition.',
    'Luftbewegung bis auf Tierhöhe bringen.': 'Bring the air movement down to animal level.',
    'Nicht nur die Lufttemperatur, auch die Feuchte beachten.': 'Consider humidity as well as air temperature.',
    'Zugluft und unnötigen Stress vermeiden.': 'Avoid draughts and unnecessary stress.',
    'Stallklima': 'Barn climate',

    'Abschluss': 'Conclusion',
    'Du hast beobachtet, gemessen, gehandelt und überprüft. Genau so entsteht aus einer Beobachtung eine belastbare Erkenntnis – im Spiel und in der Forschung.': 'You observed, measured, acted and checked. That is exactly how an observation becomes a reliable finding – in the game and in research.',
    'Beobachtung ist eine Datenquelle.': 'Observation is a source of data.',
    'Messwerte brauchen Kontext.': 'Readings need context.',
    'Maßnahmen müssen auf ihre Wirkung geprüft werden.': 'Measures must be checked for their effect.',

    /* ---- Tipps ---- */
    'Tipp: Achte auf die Atmung und den Aufenthaltsort – nicht nur auf das Fressen.': 'Tip: Watch breathing and location – not just eating.',
    'Tipp: Die Wetterstation steht am Zugang zur Weide.': 'Tip: The weather station is at the entrance to the pasture.',
    'Tipp: Mit J öffnest du jederzeit dein Forschungsjournal.': 'Tip: Press J to open your research journal at any time.',
    'Tipp: Maßnahmen wirken nicht isoliert. Schatten, Wasser und Luftbewegung ergänzen sich.': 'Tip: Measures do not work in isolation. Shade, water and air movement complement each other.',
    'Tipp: Nach einer Veränderung lohnt sich der zweite Blick auf die Tiere.': 'Tip: After a change, it is worth taking a second look at the animals.',

    /* ---- Zahlen-Platzhalter ---- */
    '--,-°C': '--.-°C',
    '--,- °C': '--.- °C',
    '--,-': '--.-',
    '-- %': '--%'
  };

  /* Texte, die in beiden Sprachen gleich sind (Namen, Marken, Tasten). */
  var SAME = /^(?:FBN · NUTZTIERKOSMOS|FBN · Nutztierkosmos|FBN RESEARCH FARM|Nutztierkosmos|Lotte|Mira|Paula|Edda|Journal|Pause|Zoom|Shift|Esc|WASD|W A S D|LOG|LIVE|ONLINE|THI|N\/A|MILD|mild|Thermometer|Hygrometer|Mission 1|\d+ \/ min)$/;

  var COWS = '(Lotte|Mira|Paula|Edda)';

  /* Zusammengesetzte Texte: [Muster, Funktion(Treffer) -> Englisch]. */
  var RULES = [
    [/^(\d+),(\d+)(\s?°C)?$/, function (m) { return m[1] + '.' + m[2] + (m[3] || ''); }],
    [/^(\d+) %$/, function (m) { return m[1] + '%'; }],
    [/^(\d+) von (\d+) Punkten$/, function (m) { return m[1] + ' of ' + m[2] + ' points'; }],
    [/^von (\d+)$/, function (m) { return 'of ' + m[1]; }],
    [/^Dauer (.+)$/, function (m) { return 'Duration ' + m[1]; }],
    [/^(Erste Beobachtung notiert|Vergleich notiert) · \+(\d+) Punkte$/, function (m) { return tr(m[1]) + ' · +' + m[2] + ' points'; }],
    [new RegExp('^' + COWS + ' beobachten$'), function (m) { return 'Observe ' + m[1]; }],
    [new RegExp('^' + COWS + ' vergleichen$'), function (m) { return 'Compare ' + m[1]; }],
    [/^Porträt von (.+)$/, function (m) { return 'Portrait of ' + m[1]; }],
    [/^(.*), du hast die Zeichen der Herde gelesen und die Weide an einem heißen Tag sicherer gemacht\.$/, function (m) { return m[1] + ', you read the herd’s signals and made the pasture safer on a hot day.'; }],
    [/^(\d+) Werte aufgezeichnet · jetzt kopieren\.$/, function (m) { return m[1] + ' samples recorded · copy now.'; }],
    // "Atemzüge: 52 / min → 28 / min" and "52 / min → 28 / min"
    [/^([^:→]+): (.+) → (.+)$/, function (m) { return tr(m[1]) + ': ' + tr(m[2]) + ' → ' + tr(m[3]); }],
    [/^([^→]+) → ([^→]+)$/, function (m) { return tr(m[1]) + ' → ' + tr(m[2]); }],
    // "Lotte steht im Schatten und atmet schnell" (name + short description)
    [new RegExp('^' + COWS + ' (.+)$'), function (m) {
      return Object.prototype.hasOwnProperty.call(EN, m[2]) ? m[1] + ' ' + EN[m[2]] : null;
    }]
  ];

  var locale = 'de';
  var listeners = [];
  var missing = {};

  function hasWords(text) { return /[A-Za-zÄÖÜäöüß]{2}/.test(text); }

  /* German source text -> English. Unknown texts pass through unchanged. */
  function tr(source) {
    if (Object.prototype.hasOwnProperty.call(EN, source)) return EN[source];
    if (!hasWords(source) && source.indexOf(',') < 0 && source.indexOf('%') < 0) return source;
    if (SAME.test(source)) return source;
    for (var i = 0; i < RULES.length; i += 1) {
      var match = RULES[i][0].exec(source);
      if (match) {
        var result = RULES[i][1](match);
        if (result != null) return result;
      }
    }
    // Lists such as "schnelle Atmung · Unruhe" or "Drei Kühe beobachten · 1/3".
    if (source.indexOf(' · ') > 0) {
      var parts = source.split(' · ');
      var changed = false;
      var out = parts.map(function (part) {
        var translated = tr(part);
        if (translated !== part || !hasWords(part) || SAME.test(part)) changed = true;
        return translated;
      });
      if (changed) return out.join(' · ');
    }
    if (hasWords(source)) missing[source] = true;
    return source;
  }

  function translate(text) {
    if (locale === 'de' || text == null) return text;
    var raw = String(text);
    var key = raw.replace(/\s+/g, ' ').trim();
    if (!key) return raw;
    var out = tr(key);
    if (out === key) return raw;
    return /^\s*/.exec(raw)[0] + out + /\s*$/.exec(raw)[0];
  }

  /* ---------------------------------------------------------
     DOM: text nodes and attributes, with remembered originals
     --------------------------------------------------------- */
  var ATTRS = ['aria-label', 'title', 'alt', 'placeholder'];
  var hasDom = typeof document !== 'undefined' && !!document.documentElement;
  var textStore = hasDom && typeof WeakMap !== 'undefined' ? new WeakMap() : null;
  var attrStore = hasDom && typeof WeakMap !== 'undefined' ? new WeakMap() : null;
  var observer = null;

  function isSkipped(el) {
    while (el && el.nodeType === 1) {
      var name = el.nodeName;
      if (name === 'SCRIPT' || name === 'STYLE' || name === 'TEXTAREA' || name === 'TEMPLATE') return true;
      if (el.hasAttribute('data-i18n-skip')) return true;
      el = el.parentNode;
    }
    return false;
  }

  function applyText(node) {
    var current = node.data;
    var state = textStore.get(node);
    if (!state && !/\S/.test(current)) return;
    var source = (state && state.out === current) ? state.de : current;
    var out = translate(source);
    if (state) { state.de = source; state.out = out; }
    else textStore.set(node, { de: source, out: out });
    if (out !== current) node.data = out;
  }

  function applyAttr(el, name) {
    if (!el.hasAttribute(name)) return;
    var current = el.getAttribute(name);
    var states = attrStore.get(el);
    if (!states) { states = {}; attrStore.set(el, states); }
    var state = states[name];
    var source = (state && state.out === current) ? state.de : current;
    var out = translate(source);
    states[name] = { de: source, out: out };
    if (out !== current) el.setAttribute(name, out);
  }

  function applyElement(el) {
    for (var i = 0; i < ATTRS.length; i += 1) applyAttr(el, ATTRS[i]);
    if (el.nodeName === 'META' && el.getAttribute('name') === 'description') applyAttr(el, 'content');
  }

  /* Translate a subtree; `checked` means the ancestors are known to be fine. */
  function walk(node, checked) {
    if (node.nodeType === 3) {
      if (checked || !isSkipped(node.parentNode)) applyText(node);
      return;
    }
    if (node.nodeType !== 1) return;
    if (checked) {
      var name = node.nodeName;
      if (name === 'SCRIPT' || name === 'STYLE' || name === 'TEXTAREA' || name === 'TEMPLATE' || node.hasAttribute('data-i18n-skip')) return;
    } else if (isSkipped(node)) {
      return;
    }
    applyElement(node);
    for (var child = node.firstChild; child; child = child.nextSibling) walk(child, true);
  }

  function onMutations(records) {
    if (locale === 'de') return; // German is what the code writes; nothing to do.
    for (var i = 0; i < records.length; i += 1) {
      var record = records[i];
      if (record.type === 'characterData') {
        if (record.target.nodeType === 3 && !isSkipped(record.target.parentNode)) applyText(record.target);
      } else if (record.type === 'attributes') {
        if (!isSkipped(record.target)) applyAttr(record.target, record.attributeName);
      } else {
        for (var j = 0; j < record.addedNodes.length; j += 1) {
          var added = record.addedNodes[j];
          if (added.isConnected !== false) walk(added, false);
        }
      }
    }
  }

  function applyDom() {
    if (!hasDom || !textStore) return;
    document.documentElement.lang = locale;
    walk(document.documentElement, false);
    // Our own writes need no second look.
    if (observer) observer.takeRecords();
  }

  if (hasDom && textStore && typeof MutationObserver !== 'undefined') {
    observer = new MutationObserver(onMutations);
    observer.observe(document.documentElement, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: ATTRS.concat(['content'])
    });
  }

  /* ---------------------------------------------------------
     Public API
     --------------------------------------------------------- */
  function normalize(value) {
    var code = String(value == null ? '' : value).trim().toLowerCase().slice(0, 2);
    return code === 'en' ? 'en' : (code === 'de' ? 'de' : null);
  }

  NTK.TEXTS = { de: null, en: EN }; // de: the source strings themselves
  NTK.locale = locale;

  NTK.t = function (text) { return translate(text); };

  NTK.onLocaleChange = function (fn) {
    if (typeof fn === 'function') listeners.push(fn);
  };

  NTK.setLocale = function (value) {
    var next = normalize(value);
    if (!next) return false;
    if (next === locale) {
      if (hasDom) document.documentElement.lang = locale;
      return false;
    }
    locale = next;
    NTK.locale = next;
    applyDom();
    for (var i = 0; i < listeners.length; i += 1) {
      try { listeners[i](next); } catch (err) {
        if (window.console && console.error) console.error('NTK i18n listener:', err);
      }
    }
    // Listeners may have written fresh German text synchronously.
    if (observer) onMutations(observer.takeRecords());
    return true;
  };

  /* Diagnostics for quality checks: German texts seen without an English entry. */
  NTK.i18n = {
    missing: function () { return Object.keys(missing); },
    clearMissing: function () { missing = {}; },
    translateTo: function (text) { var keep = locale; locale = 'en'; var out = translate(text); locale = keep; return out; }
  };
})();
