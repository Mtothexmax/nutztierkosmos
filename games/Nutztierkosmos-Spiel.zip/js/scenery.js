/* =========================================================
   Nutztierkosmos · Landschaft
   Umland (Hügel, Felder, Wald, Windräder), wehendes Gras,
   Wiesenblumen und Vögel. Erweitert NTK.World, ohne die
   Spiellogik zu berühren. Alles prozedural, keine Assets.
   ========================================================= */
(function () {
  'use strict';

  var T = window.THREE;
  var NTK = window.NTK = window.NTK || {};
  var World = NTK.World;
  if (!T || !World) return;

  // Playable farm rectangle (matches the ground plane in world.js).
  var FARM = { minX: -37, maxX: 37, minZ: -35, maxZ: 33 };

  // Deterministic random so the landscape looks the same on every start.
  var seed = 20240731;
  function rnd() {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  }
  function range(a, b) { return a + rnd() * (b - a); }
  function smooth(a, b, v) {
    var t = Math.max(0, Math.min(1, (v - a) / (b - a)));
    return t * t * (3 - 2 * t);
  }
  function hash2(x, z) {
    var s = Math.sin(x * 127.1 + z * 311.7) * 43758.5453;
    return s - Math.floor(s);
  }
  function farmDistance(x, z) {
    var dx = Math.max(FARM.minX - x, 0, x - FARM.maxX);
    var dz = Math.max(FARM.minZ - z, 0, z - FARM.maxZ);
    return Math.sqrt(dx * dx + dz * dz);
  }

  function terrainHeight(x, z) {
    var d = farmDistance(x, z);
    if (d <= 0) return -0.35;
    var rolling = Math.sin(x * 0.045 + 1.3) * Math.cos(z * 0.05 - 0.7) * 3.6 +
      Math.sin(x * 0.11 + z * 0.07) * 1.3 +
      Math.sin(z * 0.13 - x * 0.05 + 2.0) * 1.1;
    var rise = 1.2 + d * 0.045;
    var h = (rolling + rise) * smooth(3, 38, d);
    // Keep the southern side (behind the camera) low so it never blocks the view.
    if (z > FARM.maxZ) h *= 0.45;
    // Distant ridge closes the horizon.
    var angle = Math.atan2(z, x);
    h += smooth(105, 185, d) * (15 + Math.sin(angle * 5.0 + 0.6) * 5 + Math.sin(angle * 11.0) * 2.5);
    return h - 0.35 * (1 - smooth(0, 3, d));
  }

  function forestAmount(x, z) {
    return Math.sin(x * 0.058 + 2.0) * Math.sin(z * 0.067 + 1.0) + Math.sin((x + z) * 0.031) * 0.8;
  }

  var FIELD_COLORS = [
    0x5f9a40, 0x70a846, 0x4f8a3c, 0x7fb24c,   // meadows
    0xdcb448, 0xe6c257, 0xc99a3c,             // ripe grain / stubble
    0x94a94f, 0x9a7b52                        // clover, bare soil
  ];

  function fieldColor(x, z, out) {
    var d = farmDistance(x, z);
    var u = Math.floor((x + z * 0.32) / 27);
    var v = Math.floor((z - x * 0.22) / 21);
    var idx = Math.floor(hash2(u, v) * FIELD_COLORS.length);
    out.setHex(FIELD_COLORS[idx]);
    if (forestAmount(x, z) > 0.62 && d > 10) out.setHex(0x4c7a44);
    // Blend into the farm meadow right at the border.
    var near = 1 - smooth(4, 16, d);
    if (near > 0) out.lerp(new T.Color(0x5c9440), near);
    // Hazy ridge in the far distance.
    var far = smooth(110, 180, d);
    if (far > 0) out.lerp(new T.Color(0x6f927a), far);
    var jitter = 0.94 + hash2(x * 0.7, z * 0.7) * 0.12;
    out.convertSRGBToLinear().multiplyScalar(jitter);
    return out;
  }

  // Merge simple non-indexed geometries (position + color only), then recompute normals.
  function mergeParts(parts) {
    var positions = [];
    var colors = [];
    parts.forEach(function (part) {
      var geo = part.geometry.index ? part.geometry.toNonIndexed() : part.geometry;
      if (part.matrix) geo.applyMatrix4(part.matrix);
      var pos = geo.attributes.position;
      var c = new T.Color(part.color).convertSRGBToLinear();
      for (var i = 0; i < pos.count; i += 1) {
        positions.push(pos.getX(i), pos.getY(i), pos.getZ(i));
        var shade = part.shade ? part.shade(pos.getX(i), pos.getY(i), pos.getZ(i)) : 1;
        colors.push(c.r * shade, c.g * shade, c.b * shade);
      }
    });
    var merged = new T.BufferGeometry();
    merged.setAttribute('position', new T.Float32BufferAttribute(positions, 3));
    merged.setAttribute('color', new T.Float32BufferAttribute(colors, 3));
    merged.computeVertexNormals();
    return merged;
  }

  function matrixAt(x, y, z, sx, sy, sz, ry) {
    var m = new T.Matrix4();
    var q = new T.Quaternion().setFromEuler(new T.Euler(0, ry || 0, 0));
    m.compose(new T.Vector3(x, y, z), q, new T.Vector3(sx, sy == null ? sx : sy, sz == null ? sx : sz));
    return m;
  }

  /* ---------------------------------------------------------
     Build
     --------------------------------------------------------- */

  World.prototype.buildScenery = function () {
    this.sceneryLow = window.innerWidth < 760;
    this.windUniform = { value: 0 };
    this.turbines = [];
    this.birds = [];
    this.buildOuterTerrain();
    this.buildForest();
    this.buildTurbines();
    this.buildFarmsteads();
    this.buildBirds();
  };

  World.prototype.buildOuterTerrain = function () {
    var size = 440;
    var seg = this.sceneryLow ? 72 : 104;
    var plane = new T.PlaneGeometry(size, size, seg, seg);
    plane.rotateX(-Math.PI / 2);
    var p = plane.attributes.position;
    for (var i = 0; i < p.count; i += 1) {
      p.setY(i, terrainHeight(p.getX(i), p.getZ(i)));
    }
    var geo = plane.toNonIndexed();
    var pos = geo.attributes.position;
    var colors = new Float32Array(pos.count * 3);
    var c = new T.Color();
    for (var t = 0; t < pos.count; t += 3) {
      var cx = (pos.getX(t) + pos.getX(t + 1) + pos.getX(t + 2)) / 3;
      var cz = (pos.getZ(t) + pos.getZ(t + 1) + pos.getZ(t + 2)) / 3;
      fieldColor(cx, cz, c);
      for (var k = 0; k < 3; k += 1) {
        colors[(t + k) * 3] = c.r;
        colors[(t + k) * 3 + 1] = c.g;
        colors[(t + k) * 3 + 2] = c.b;
      }
    }
    geo.setAttribute('color', new T.BufferAttribute(colors, 3));
    geo.computeVertexNormals();
    var mat = new T.MeshStandardMaterial({ vertexColors: true, roughness: 1, metalness: 0, flatShading: true });
    var terrain = new T.Mesh(geo, mat);
    terrain.name = 'outer-terrain';
    terrain.receiveShadow = true;
    this.scene.add(terrain);
    this.outerTerrain = terrain;
  };

  World.prototype.buildForest = function () {
    var shadeByHeight = function (x, y) { return 0.55 + Math.max(0, Math.min(1, (y + 1) / 2)) * 0.45; };
    var crownGeo = mergeParts([
      { geometry: new T.IcosahedronGeometry(1, 1), color: 0xffffff, matrix: matrixAt(0, 0, 0, 1.15, 0.9, 1.05), shade: shadeByHeight },
      { geometry: new T.IcosahedronGeometry(1, 0), color: 0xffffff, matrix: matrixAt(0.75, 0.5, 0.2, 0.7), shade: shadeByHeight },
      { geometry: new T.IcosahedronGeometry(1, 0), color: 0xffffff, matrix: matrixAt(-0.7, 0.35, -0.3, 0.75), shade: shadeByHeight }
    ]);
    var coniferGeo = mergeParts([
      { geometry: new T.ConeGeometry(1.0, 1.7, 7), color: 0xffffff, matrix: matrixAt(0, 0.4, 0, 1), shade: function () { return 0.78; } },
      { geometry: new T.ConeGeometry(0.78, 1.5, 7), color: 0xffffff, matrix: matrixAt(0, 1.35, 0, 1), shade: function () { return 0.92; } },
      { geometry: new T.ConeGeometry(0.5, 1.3, 7), color: 0xffffff, matrix: matrixAt(0, 2.25, 0, 1), shade: function () { return 1.08; } }
    ]);
    var trunkGeo = new T.CylinderGeometry(0.16, 0.26, 1, 6);

    var leafy = [];
    var conifers = [];
    var maxLeafy = this.sceneryLow ? 220 : 430;
    var maxConifer = this.sceneryLow ? 90 : 190;
    var tries = 0;
    while (tries < 9000 && (leafy.length < maxLeafy || conifers.length < maxConifer)) {
      tries += 1;
      var x = range(-170, 170);
      var z = range(-170, 150);
      var d = farmDistance(x, z);
      if (d < 5 || d > 150) continue;
      var f = forestAmount(x, z);
      var hedge = hash2(Math.floor(x / 27) * 3.1, Math.floor(z / 21) * 1.7) > 0.9;
      if (f < 0.62 && !(hedge && rnd() < 0.5) && !(d < 16 && rnd() < 0.16)) continue;
      // Leave the southern approach open (the camera sits there).
      if (z > FARM.maxZ && Math.abs(x) < 26 && d < 40) continue;
      var item = { x: x, z: z, y: terrainHeight(x, z), s: range(1.5, 2.7), r: rnd() * Math.PI * 2, tint: rnd() };
      if ((f > 0.95 || rnd() < 0.22) && conifers.length < maxConifer) conifers.push(item);
      else if (leafy.length < maxLeafy) leafy.push(item);
    }

    var dummy = this._tmpObj;
    var color = new T.Color();
    var crownMat = new T.MeshStandardMaterial({ vertexColors: true, roughness: 0.95, flatShading: true });
    var coniferMat = new T.MeshStandardMaterial({ vertexColors: true, roughness: 0.95, flatShading: true });
    var trunkMat = new T.MeshStandardMaterial({ color: 0x6d5038, roughness: 1, flatShading: true });
    var leafPalette = [0x3a8433, 0x4a9439, 0x5ca03f, 0x2c6e30, 0x70a843];
    var coniferPalette = [0x245238, 0x2d5e3e, 0x1f4a36];

    var crowns = new T.InstancedMesh(crownGeo, crownMat, Math.max(1, leafy.length));
    var trunks = new T.InstancedMesh(trunkGeo, trunkMat, Math.max(1, leafy.length + conifers.length));
    var cones = new T.InstancedMesh(coniferGeo, coniferMat, Math.max(1, conifers.length));
    var ti = 0;
    leafy.forEach(function (tree, i) {
      dummy.position.set(tree.x, tree.y + tree.s * 1.55, tree.z);
      dummy.rotation.set(0, tree.r, 0);
      dummy.scale.set(tree.s, tree.s * range(0.9, 1.15), tree.s);
      dummy.updateMatrix();
      crowns.setMatrixAt(i, dummy.matrix);
      crowns.setColorAt(i, color.setHex(leafPalette[Math.floor(tree.tint * leafPalette.length)]).convertSRGBToLinear());
      dummy.position.set(tree.x, tree.y + tree.s * 0.45, tree.z);
      dummy.scale.set(tree.s, tree.s * 1.3, tree.s);
      dummy.updateMatrix();
      trunks.setMatrixAt(ti, dummy.matrix);
      ti += 1;
    });
    conifers.forEach(function (tree, i) {
      var s = tree.s * 1.15;
      dummy.position.set(tree.x, tree.y + s * 0.75, tree.z);
      dummy.rotation.set(0, tree.r, 0);
      dummy.scale.set(s, s * 1.25, s);
      dummy.updateMatrix();
      cones.setMatrixAt(i, dummy.matrix);
      cones.setColorAt(i, color.setHex(coniferPalette[Math.floor(tree.tint * coniferPalette.length)]).convertSRGBToLinear());
      dummy.position.set(tree.x, tree.y + s * 0.35, tree.z);
      dummy.scale.set(s * 0.8, s, s * 0.8);
      dummy.updateMatrix();
      trunks.setMatrixAt(ti, dummy.matrix);
      ti += 1;
    });
    [crowns, trunks, cones].forEach(function (mesh) {
      mesh.instanceMatrix.needsUpdate = true;
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
      mesh.frustumCulled = false;
      mesh.castShadow = false;
      mesh.receiveShadow = false;
      this.scene.add(mesh);
    }, this);
    crowns.name = 'forest-crowns';
    cones.name = 'forest-conifers';
    trunks.name = 'forest-trunks';
  };

  World.prototype.buildTurbines = function () {
    var towerMat = new T.MeshStandardMaterial({ color: 0xf2f1ea, roughness: 0.7 });
    var spots = [[-64, -118, 1.0], [-8, -138, 1.15], [58, -112, 0.95], [112, -70, 0.9]];
    spots.forEach(function (s, i) {
      var g = new T.Group();
      var k = s[2];
      var tower = new T.Mesh(new T.CylinderGeometry(0.45 * k, 0.95 * k, 26 * k, 8), towerMat);
      tower.position.y = 13 * k;
      g.add(tower);
      var nacelle = new T.Mesh(new T.BoxGeometry(1.4 * k, 1.3 * k, 3.2 * k), towerMat);
      nacelle.position.set(0, 26.2 * k, 0.4 * k);
      g.add(nacelle);
      var rotor = new T.Group();
      for (var b = 0; b < 3; b += 1) {
        var blade = new T.Mesh(new T.BoxGeometry(0.75 * k, 11 * k, 0.16 * k), towerMat);
        blade.geometry.translate(0, 6.2 * k, 0);
        blade.rotation.z = b * Math.PI * 2 / 3;
        rotor.add(blade);
      }
      var hub = new T.Mesh(new T.SphereGeometry(0.85 * k, 8, 6), towerMat);
      rotor.add(hub);
      rotor.position.set(0, 26.2 * k, 2.1 * k);
      g.add(rotor);
      g.position.set(s[0], terrainHeight(s[0], s[1]) - 0.5, s[1]);
      g.rotation.y = Math.atan2(-s[0] * 0.25, 1);
      this.scene.add(g);
      this.turbines.push({ rotor: rotor, speed: 0.5 + i * 0.07 });
    }, this);
  };

  World.prototype.buildFarmsteads = function () {
    // A few tiny neighbouring farmhouses give the landscape scale.
    var wallMat = new T.MeshStandardMaterial({ color: 0xf0e6d2, roughness: 1, flatShading: true });
    var roofMat = new T.MeshStandardMaterial({ color: 0xb4583c, roughness: 1, flatShading: true });
    var barnMat = new T.MeshStandardMaterial({ color: 0x9a4a36, roughness: 1, flatShading: true });
    var spots = [[-78, -74, 0.4, 0], [70, -84, -0.5, 1], [-104, -18, 1.1, 1], [96, 6, 0.2, 0]];
    spots.forEach(function (s) {
      var g = new T.Group();
      var body = new T.Mesh(new T.BoxGeometry(9, 4.2, 6), s[3] ? barnMat : wallMat);
      body.position.y = 2.1;
      g.add(body);
      var roof = new T.Mesh(new T.CylinderGeometry(0.01, 4.6, 3.2, 4, 1), roofMat);
      roof.rotation.y = Math.PI / 4;
      roof.scale.set(1.45, 1, 1);
      roof.position.y = 5.8;
      g.add(roof);
      g.position.set(s[0], terrainHeight(s[0], s[1]) - 0.3, s[1]);
      g.rotation.y = s[2];
      this.scene.add(g);
    }, this);
  };

  World.prototype.buildBirds = function () {
    var mat = new T.MeshBasicMaterial({ color: 0x2d3a3a, side: T.DoubleSide });
    var wingGeo = new T.BufferGeometry();
    wingGeo.setAttribute('position', new T.Float32BufferAttribute([0, 0, -0.16, 0, 0, 0.2, 1, 0, -0.05], 3));
    for (var i = 0; i < 6; i += 1) {
      var g = new T.Group();
      var left = new T.Mesh(wingGeo, mat);
      var right = new T.Mesh(wingGeo, mat);
      right.scale.x = -1;
      g.add(left, right);
      g.scale.setScalar(range(0.55, 0.85));
      this.scene.add(g);
      this.birds.push({
        group: g, left: left, right: right,
        cx: range(-30, 40), cz: range(-60, -15), y: range(16, 26),
        radius: range(10, 24), speed: range(0.14, 0.24) * (i % 2 ? 1 : -1), phase: rnd() * 6.28
      });
    }
  };

  /* ---------------------------------------------------------
     Meadow: grass tufts and flowers on every free patch of
     the farm ground. Free patches are found with one coarse
     ray per cell, so paths, buildings and pens stay clear.
     --------------------------------------------------------- */

  World.prototype.buildMeadow = function () {
    var targets = [];
    var allowed = [this.ground];
    this.scene.traverse(function (o) {
      if (!o.isMesh || o.isInstancedMesh || o === this.sky || o === this.outerTerrain) return;
      if (o.material && (o.material.isSpriteMaterial || o.material.transparent)) {
        if (o.geometry && o.geometry.type === 'PlaneGeometry' && o.position.y < 0.05) allowed.push(o);
        else return;
      }
      if (o.userData && o.userData.sceneryIgnore) return;
      targets.push(o);
    }.bind(this));
    this.scene.updateMatrixWorld(true);

    var ray = new T.Raycaster();
    var origin = new T.Vector3();
    var down = new T.Vector3(0, -1, 0);
    var free = [];
    var step = 1.0;
    for (var x = FARM.minX + 0.5; x < FARM.maxX; x += step) {
      for (var z = FARM.minZ + 0.5; z < FARM.maxZ; z += step) {
        origin.set(x, 2.2, z);
        ray.set(origin, down);
        ray.far = 2.6;
        var hits = ray.intersectObjects(targets, false);
        if (!hits.length) continue;
        if (allowed.indexOf(hits[0].object) === -1) continue;
        free.push([x, z]);
      }
    }
    if (!free.length) return;
    var freeSet = {};
    free.forEach(function (c) { freeSet[Math.round(c[0] * 2) + ':' + Math.round(c[1] * 2)] = true; });
    function open(x, z) {
      // A cell counts as open meadow only if its neighbours are free too.
      var bx = Math.round((Math.floor(x - FARM.minX) + FARM.minX + 0.5) * 2);
      var bz = Math.round((Math.floor(z - FARM.minZ) + FARM.minZ + 0.5) * 2);
      return freeSet[bx + ':' + bz];
    }

    // --- grass tufts ---------------------------------------------------
    var bladeParts = [];
    for (var b = 0; b < 7; b += 1) {
      var blade = new T.BufferGeometry();
      var w = 0.02 + b * 0.002;
      var h = 0.15 + (b % 3) * 0.045;
      var lean = (b - 2) * 0.035;
      blade.setAttribute('position', new T.Float32BufferAttribute([
        -w, 0, 0, w, 0, 0, lean, h, 0.02
      ], 3));
      var ang = b * 0.9;
      bladeParts.push({
        geometry: blade, color: 0xffffff,
        matrix: matrixAt(Math.cos(ang) * (0.04 + b * 0.012), 0, Math.sin(ang) * (0.04 + b * 0.012), 1, 1, 1, ang * 1.7),
        shade: function (px, py) { return 0.9 + py * 1.5; }
      });
    }
    var tuftGeo = mergeParts(bladeParts);
    // All blades face up for soft, even lighting.
    var normals = tuftGeo.attributes.normal;
    for (var n = 0; n < normals.count; n += 1) normals.setXYZ(n, 0, 1, 0);

    var wind = this.windUniform;
    var grassMat = new T.MeshLambertMaterial({ vertexColors: true, side: T.DoubleSide });
    grassMat.onBeforeCompile = function (shader) {
      shader.uniforms.uWind = wind;
      shader.vertexShader = 'uniform float uWind;\n' + shader.vertexShader.replace(
        '#include <begin_vertex>',
        [
          '#include <begin_vertex>',
          '#ifdef USE_INSTANCING',
          '  vec3 ntkRoot = (modelMatrix * instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz;',
          '  float ntkBend = position.y * position.y * 3.0;',
          '  transformed.x += sin(uWind * 1.7 + ntkRoot.x * 0.55 + ntkRoot.z * 0.35) * ntkBend;',
          '  transformed.z += cos(uWind * 1.3 + ntkRoot.x * 0.3 - ntkRoot.z * 0.6) * ntkBend * 0.6;',
          '#endif'
        ].join('\n')
      );
    };

    var tuftCount = this.sceneryLow ? 9000 : 24000;
    var dummy = this._tmpObj;
    var color = new T.Color();
    var grassPalette = [0x5f9a45, 0x6ea84c, 0x7db455, 0x528a40, 0x8fbd5c, 0xa3c263];
    // Tufts are grouped into square chunks so the renderer can skip every
    // chunk outside the camera view instead of drawing the whole meadow.
    var CHUNK = 13;
    var chunks = {};
    var placed = 0;
    var guard = 0;
    while (placed < tuftCount && guard < tuftCount * 6) {
      guard += 1;
      var cell = free[Math.floor(rnd() * free.length)];
      var gx = cell[0] + range(-0.5, 0.5);
      var gz = cell[1] + range(-0.5, 0.5);
      // Patchy density: lush clumps with lighter areas in between.
      var patch = Math.sin(gx * 0.42 + 1.0) * Math.sin(gz * 0.37 + 2.0) + Math.sin((gx - gz) * 0.19);
      if (patch < -0.55 && rnd() < 0.75) continue;
      var s = range(0.8, 1.4) * (patch > 0.5 ? 1.2 : 1);
      var ckx = Math.floor(gx / CHUNK);
      var ckz = Math.floor(gz / CHUNK);
      var key = ckx + ':' + ckz;
      var chunk = chunks[key] || (chunks[key] = { cx: (ckx + 0.5) * CHUNK, cz: (ckz + 0.5) * CHUNK, items: [] });
      chunk.items.push([gx - chunk.cx, gz - chunk.cz, rnd() * 6.28, s, s * range(0.8, 1.35), grassPalette[Math.floor(rnd() * grassPalette.length)]]);
      placed += 1;
    }
    tuftGeo.boundingSphere = new T.Sphere(new T.Vector3(0, 0.2, 0), CHUNK * 0.76);
    this.grassChunks = [];
    Object.keys(chunks).forEach(function (key) {
      var chunk = chunks[key];
      var mesh = new T.InstancedMesh(tuftGeo, grassMat, chunk.items.length);
      chunk.items.forEach(function (it, i) {
        dummy.position.set(it[0], 0, it[1]);
        dummy.rotation.set(0, it[2], 0);
        dummy.scale.set(it[3], it[4], it[3]);
        dummy.updateMatrix();
        mesh.setMatrixAt(i, dummy.matrix);
        mesh.setColorAt(i, color.setHex(it[5]).convertSRGBToLinear());
      });
      mesh.position.set(chunk.cx, 0, chunk.cz);
      mesh.instanceMatrix.needsUpdate = true;
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
      mesh.receiveShadow = true;
      mesh.matrixAutoUpdate = false;
      mesh.updateMatrix();
      mesh.name = 'meadow-grass';
      mesh.userData.fullCount = chunk.items.length;
      this.scene.add(mesh);
      this.grassChunks.push(mesh);
    }, this);

    // --- flowers ---------------------------------------------------------
    var petal = new T.ConeGeometry(0.075, 0.05, 6);
    var flowerGeo = mergeParts([
      { geometry: new T.CylinderGeometry(0.008, 0.012, 0.3, 3), color: 0x4f8a3c, matrix: matrixAt(0, 0.15, 0, 1) },
      { geometry: petal, color: 0xffffff, matrix: new T.Matrix4().makeRotationX(Math.PI).setPosition(0, 0.31, 0) },
      { geometry: new T.SphereGeometry(0.026, 4, 3), color: 0xf2c230, matrix: matrixAt(0, 0.335, 0, 1) }
    ]);
    // Tint only the petals: stem and centre keep their own colour via a white instance tint blend.
    var flowerMat = new T.MeshLambertMaterial({ vertexColors: true });
    flowerMat.onBeforeCompile = function (shader) {
      shader.uniforms.uWind = wind;
      shader.vertexShader = 'uniform float uWind;\n' + shader.vertexShader
        .replace('#include <color_vertex>', [
          '#include <color_vertex>',
          '#ifdef USE_INSTANCING_COLOR',
          '  float ntkPetal = step(0.99, color.r) * step(0.99, color.g) * step(0.99, color.b);',
          '  vColor.xyz = mix(color.xyz, color.xyz * instanceColor.xyz, ntkPetal);',
          '#endif'
        ].join('\n'))
        .replace('#include <begin_vertex>', [
          '#include <begin_vertex>',
          '#ifdef USE_INSTANCING',
          '  vec3 ntkRoot = (modelMatrix * instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz;',
          '  transformed.x += sin(uWind * 1.5 + ntkRoot.x * 0.6 + ntkRoot.z * 0.4) * position.y * 0.22;',
          '#endif'
        ].join('\n'));
    };
    var flowerPalette = [0xffffff, 0xffffff, 0xf7d24a, 0xf7d24a, 0xe2483c, 0x5b7fe0, 0xf3a6c0, 0xb48ae0];
    var flowerCount = this.sceneryLow ? 700 : 1700;
    var flowers = new T.InstancedMesh(flowerGeo, flowerMat, flowerCount);
    var fPlaced = 0;
    var clusters = Math.floor(flowerCount / 14);
    for (var cidx = 0; cidx < clusters && fPlaced < flowerCount; cidx += 1) {
      var centre = free[Math.floor(rnd() * free.length)];
      var hue = flowerPalette[Math.floor(rnd() * flowerPalette.length)];
      var spread = range(0.8, 2.6);
      for (var fidx = 0; fidx < 14 && fPlaced < flowerCount; fidx += 1) {
        var a = rnd() * 6.28;
        var r = Math.sqrt(rnd()) * spread;
        var fx = centre[0] + Math.cos(a) * r;
        var fz = centre[1] + Math.sin(a) * r;
        if (!open(fx, fz)) continue;
        var fs = range(0.8, 1.45);
        dummy.position.set(fx, 0, fz);
        dummy.rotation.set(range(-0.12, 0.12), rnd() * 6.28, range(-0.12, 0.12));
        dummy.scale.set(fs, fs * range(0.75, 1.3), fs);
        dummy.updateMatrix();
        flowers.setMatrixAt(fPlaced, dummy.matrix);
        color.setHex(rnd() < 0.82 ? hue : flowerPalette[Math.floor(rnd() * flowerPalette.length)]).convertSRGBToLinear();
        flowers.setColorAt(fPlaced, color);
        fPlaced += 1;
      }
    }
    flowers.count = fPlaced;
    flowers.instanceMatrix.needsUpdate = true;
    if (flowers.instanceColor) flowers.instanceColor.needsUpdate = true;
    flowers.frustumCulled = false;
    flowers.name = 'meadow-flowers';
    this.scene.add(flowers);
    this.meadowStats = { cells: free.length, tufts: placed, flowers: fPlaced };
  };

  /* ---------------------------------------------------------
     Per-frame
     --------------------------------------------------------- */

  // Thins the meadow uniformly (instances are stored in random order).
  World.prototype.setMeadowDensity = function (factor) {
    if (!this.grassChunks) return;
    this.meadowDensity = factor;
    this._meadowLodTimer = 0;
  };

  World.prototype.updateScenery = function (dt) {
    if (!this.windUniform) return;
    if (!this.reducedMotion) this.windUniform.value += dt;
    var i;
    // Distant meadow chunks draw fewer tufts; nobody can see single blades there.
    this._meadowLodTimer = (this._meadowLodTimer || 0) - dt;
    if (this.grassChunks && this._meadowLodTimer <= 0) {
      this._meadowLodTimer = 0.3;
      var density = this.meadowDensity == null ? 1 : this.meadowDensity;
      var cam = this.camera.position;
      for (i = 0; i < this.grassChunks.length; i += 1) {
        var mesh = this.grassChunks[i];
        var dx = mesh.position.x - cam.x;
        var dz = mesh.position.z - cam.z;
        var dist = Math.sqrt(dx * dx + dz * dz);
        var lod = dist < 24 ? 1 : Math.max(0.3, 1 - (dist - 24) / 36);
        mesh.count = Math.max(1, Math.round(mesh.userData.fullCount * lod * density));
      }
    }
    for (i = 0; i < this.turbines.length; i += 1) {
      this.turbines[i].rotor.rotation.z += this.turbines[i].speed * dt * (this.reducedMotion ? 0.3 : 1);
    }
    for (i = 0; i < this.birds.length; i += 1) {
      var b = this.birds[i];
      b.group.visible = !this.reducedMotion;
      if (this.reducedMotion) continue;
      var t = this.time * b.speed + b.phase;
      b.group.position.set(b.cx + Math.cos(t) * b.radius, b.y + Math.sin(t * 1.7) * 0.8, b.cz + Math.sin(t) * b.radius);
      b.group.rotation.y = -t + (b.speed > 0 ? 0 : Math.PI);
      var flap = Math.sin(this.time * 7 + b.phase) * 0.55;
      b.left.rotation.z = flap;
      b.right.rotation.z = -flap;
    }
  };
})();
