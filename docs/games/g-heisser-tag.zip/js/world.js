/* =========================================================
   Nutztierkosmos · low-poly farm world
   Built entirely from procedural Three.js geometry & canvas textures.
   ========================================================= */
(function () {
  'use strict';

  var NTK = window.NTK = window.NTK || {};
  var D = window.NTK_DATA;
  var T = window.THREE;

  function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function rand(min, max) { return min + Math.random() * (max - min); }
  function damp(current, target, lambda, dt) {
    return target + (current - target) * Math.exp(-lambda * dt);
  }
  function angleLerp(a, b, t) {
    var diff = ((b - a + Math.PI) % (Math.PI * 2)) - Math.PI;
    if (diff < -Math.PI) diff += Math.PI * 2;
    return a + diff * t;
  }
  function angleDelta(a, b) {
    var diff = ((b - a + Math.PI) % (Math.PI * 2)) - Math.PI;
    if (diff < -Math.PI) diff += Math.PI * 2;
    return diff;
  }

  var COLORS = {
    grass: '#6f9c5c',
    grassLight: '#8cb671',
    grassDark: '#557d4a',
    path: '#c9ab7d',
    wood: '#86583f',
    woodDark: '#5f3c2d',
    cream: '#efe0c5',
    red: '#a6533f',
    roof: '#8d4739',
    green: '#2c5d4b',
    water: '#6fb8c8',
    straw: '#d9bd7c',
    pink: '#d8a58f',
    stone: '#9b9b8c'
  };

  function World(container) {
    this.container = container;
    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.time = 0;
    this.introMode = true;
    this.uiBlocked = false;
    this.allowSimulation = true;
    this.moveInput = { x: 0, z: 0 };
    // Fixed front camera: the world is authored to be read from the south.
    this.cameraYaw = 0;
    this.cameraPitch = 0.27;
    this.cameraDistance = 9.4;
    this.cameraTarget = new T.Vector3();
    this.desiredCam = new T.Vector3();
    this.lookTarget = new T.Vector3();
    this.colliders = { circles: [], rects: [] };
    this.markers = {};
    this.markerList = [];
    this.cows = [];
    this.fans = [];
    this.treeCanopies = [];
    this.clouds = [];
    this.butterflies = [];
    this.puffs = [];
    this.dust = [];
    this.ripples = [];
    this.buildBursts = [];
    this.ventStreaks = [];
    this.buildState = {};
    this.measures = {};
    this.missionState = null;
    this.dayProgress = 0.28;
    this.maxAniso = 4;
    this.markerScale = (window.matchMedia('(pointer: coarse)').matches || window.innerWidth < 760) ? 0.75 : 1;
    this._materialJitterSeed = 0x9e3779b9;
    // The walk-up 3D terminal is created whenever CSS3D exists; resize() decides
    // per viewport whether it is usable (wide enough) or the dialog is shown instead.
    this.terminalAvailable = !!T.CSS3DRenderer;
    this.terminalNear = false;
    this.terminalProximity = 0;
    this.terminalDistance = Infinity;
    this.terminalEl = null;
    this.terminalObject = null;
    this.terminalGroup = null;
    this.cssRenderer = null;
    this.cssDirty = false;
    this.terminalFocus = false;
    this._terminalViewPos = new T.Vector3();
    this.terminalScreenWidth = 2.5;
    this.terminalScreenHeight = 1.6;
    this.terminalCenter = new T.Vector3();
    this.terminalNormal = new T.Vector3(0, 0, 1);
    this.dustTimer = 0;
    this.playerWalkPhase = 0;
    this.playerSpeed = 0;
    this.sprint = false;
    this.pigs = [];
    this.chickens = [];
    this.player = null;
    this.playerModel = null;
    this.fanSwitch = null;
    this.shadeGroup = null;
    this.troughGroup = null;
    this.fanBlades = [];
    this.resizeHandler = this.resize.bind(this);
    this.pointer = { dragging: false, id: null, lastX: 0, lastY: 0 };
    this._tmpVec = new T.Vector3();
    this._tmpVec2 = new T.Vector3();
    this._tmpObj = new T.Object3D();

    this.initRenderer();
    this.initScene();
    this.initCSS3D();
    this.initLights();
    this.buildTerrain();
    if (this.buildScenery) this.buildScenery();
    this.buildPaths();
    this.buildFences();
    this.buildFarmBuildings();
    this.buildPens();
    this.buildGarden();
    this.buildProps();
    this.buildTrees();
    this.buildWeatherStation();
    this.buildBuildSpots();
    if (this.buildMeadow) this.buildMeadow();
    this.createCows();
    this.createPlayer();
    this.createAmbientLife();
    this.createMarkers();
    this.createParticles();
    this.applyMaterialMicroOffsets();
    this.bindPointer();
    this.resize();
    this.reset();
    if (this.cssRenderer) {
      this.cssRenderer.render(this.scene, this.camera);
    }
  }

  /* ---------------------------------------------------------
     Core rendering
     --------------------------------------------------------- */

  World.prototype.initRenderer = function () {
    var renderer = new T.WebGLRenderer({
      antialias: true,
      alpha: false,
      powerPreference: 'high-performance'
    });
    var compact = window.innerWidth < 760;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, compact ? 1.4 : 1.5));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = T.PCFSoftShadowMap;
    renderer.outputEncoding = T.sRGBEncoding;
    renderer.toneMapping = T.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 0.92;
    renderer.domElement.setAttribute('aria-label', '3D-Spielwelt: Forschungsbauernhof mit Kuhweide');
    renderer.domElement.setAttribute('role', 'img');
    this.renderer = renderer;
    this.container.appendChild(renderer.domElement);
    this.maxAniso = renderer.capabilities.getMaxAnisotropy();
  };

  World.prototype.initScene = function () {
    this.scene = new T.Scene();
    this.scene.background = new T.Color(0xdfe9dc);
    this.scene.fog = new T.FogExp2(0xcfe2e4, 0.0026);

    this.camera = new T.PerspectiveCamera(48, 1, 0.1, 420);
    this.camera.position.set(0, 20, 38);

    this.createSky();
    this.createClouds();
  };

  World.prototype.initCSS3D = function () {
    if (!this.terminalAvailable) return;
    var layer = document.getElementById('css3dLayer');
    if (!layer) {
      this.terminalAvailable = false;
      return;
    }
    try {
      var renderer = new T.CSS3DRenderer();
      renderer.domElement.style.position = 'absolute';
      renderer.domElement.style.inset = '0';
      renderer.domElement.style.pointerEvents = 'none';
      layer.appendChild(renderer.domElement);
      layer.setAttribute('aria-hidden', 'true');
      this.cssRenderer = renderer;
      this.css3dLayer = layer;
    } catch (err) {
      this.terminalAvailable = false;
      this.cssRenderer = null;
    }
  };

  World.prototype.createSky = function () {
    var uniforms = {
      topColor: { value: new T.Color(0x4a94d4) },
      horizonColor: { value: new T.Color(0xd3e6ea) },
      sunColor: { value: new T.Color(0xffdda2) },
      sunDirection: { value: new T.Vector3(0.4, 0.7, 0.2).normalize() }
    };
    var shader = new T.ShaderMaterial({
      side: T.BackSide,
      depthWrite: false,
      fog: false,
      uniforms: uniforms,
      vertexShader: [
        'varying vec3 vDir;',
        'void main() {',
        '  vDir = normalize(position);',
        '  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);',
        '}'
      ].join('\n'),
      fragmentShader: [
        'uniform vec3 topColor;',
        'uniform vec3 horizonColor;',
        'uniform vec3 sunColor;',
        'uniform vec3 sunDirection;',
        'varying vec3 vDir;',
        'void main() {',
        '  float h = clamp(vDir.y, 0.0, 1.0);',
        '  vec3 mid = mix(horizonColor, topColor, 0.55);',
        '  vec3 col = mix(horizonColor, mid, smoothstep(0.0, 0.16, h));',
        '  col = mix(col, topColor, smoothstep(0.10, 0.62, h));',
        '  float sun = max(dot(normalize(vDir), normalize(sunDirection)), 0.0);',
        '  col += sunColor * smoothstep(0.9990, 0.9996, sun) * 1.4;',
        '  col += sunColor * pow(sun, 220.0) * 0.55;',
        '  col += sunColor * pow(sun, 10.0) * 0.16;',
        '  gl_FragColor = vec4(col, 1.0);',
        '}'
      ].join('\n')
    });
    var sky = new T.Mesh(new T.SphereGeometry(380, 32, 20), shader);
    sky.frustumCulled = false;
    sky.renderOrder = -10;
    this.sky = sky;
    this.skyUniforms = uniforms;
    this.scene.add(sky);
  };

  World.prototype.createClouds = function () {
    var cloudMat = new T.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0x9fb4c8,
      emissiveIntensity: 0.6,
      roughness: 1,
      metalness: 0,
      transparent: true,
      opacity: 0.94,
      flatShading: true,
      fog: false
    });
    var geo = new T.IcosahedronGeometry(1, 1);
    for (var i = 0; i < 16; i += 1) {
      var group = new T.Group();
      var puffs = 4 + Math.floor(Math.random() * 4);
      for (var p = 0; p < puffs; p += 1) {
        var puff = new T.Mesh(geo, cloudMat);
        var mid = 1 - Math.abs((p + 0.5) / puffs - 0.5) * 1.3;
        puff.position.set(p * rand(1.3, 1.9) - puffs, mid * rand(0.3, 0.9), rand(-0.6, 0.6));
        puff.scale.set(rand(1.3, 2.3), rand(0.7, 1.1) * (0.6 + mid), rand(1.0, 1.6));
        group.add(puff);
      }
      var far = i / 16;
      group.position.set(rand(-150, 150), rand(34, 46) + far * 22, -20 - far * 190 + rand(-12, 12));
      group.scale.setScalar(rand(1.6, 2.8) * (1 + far * 2.2));
      group.userData.speed = rand(0.12, 0.42);
      this.clouds.push(group);
      this.scene.add(group);
    }
  };

  World.prototype.initLights = function () {
    var hemi = new T.HemisphereLight(0xcfe6ff, 0x5f8442, 0.6);
    this.scene.add(hemi);

    var ambient = new T.AmbientLight(0xfff5df, 0.14);
    this.scene.add(ambient);

    var sun = new T.DirectionalLight(0xfff0cc, 1.6);
    sun.position.set(24, 36, 20);
    sun.castShadow = true;
    var shadowSize = window.innerWidth < 760 ? 1024 : 2048;
    sun.shadow.mapSize.set(shadowSize, shadowSize);
    sun.shadow.camera.left = -38;
    sun.shadow.camera.right = 38;
    sun.shadow.camera.top = 38;
    sun.shadow.camera.bottom = -38;
    sun.shadow.camera.near = 2;
    sun.shadow.camera.far = 100;
    sun.shadow.bias = -0.00035;
    sun.shadow.normalBias = 0.035;
    sun.target.position.set(10, 0, -2);
    this.scene.add(sun);
    this.scene.add(sun.target);
    this.sun = sun;

    var fill = new T.DirectionalLight(0xaad4dc, 0.25);
    fill.position.set(-22, 16, -10);
    this.scene.add(fill);
  };

  /* ---------------------------------------------------------
     Texture & geometry helpers
     --------------------------------------------------------- */

  World.prototype.makeTexture = function (w, h, draw, repeatX, repeatY) {
    var canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    var ctx = canvas.getContext('2d');
    draw(ctx, w, h);
    var texture = new T.CanvasTexture(canvas);
    texture.encoding = T.sRGBEncoding;
    texture.anisotropy = Math.min(this.maxAniso, 8);
    if (repeatX || repeatY) {
      texture.wrapS = T.RepeatWrapping;
      texture.wrapT = T.RepeatWrapping;
      texture.repeat.set(repeatX || 1, repeatY || 1);
    }
    return texture;
  };

  World.prototype.makeGrassTexture = function () {
    return this.makeTexture(256, 256, function (ctx, w, h) {
      ctx.fillStyle = '#6a9c4c';
      ctx.fillRect(0, 0, w, h);
      for (var i = 0; i < 3800; i += 1) {
        var x = Math.random() * w;
        var y = Math.random() * h;
        var shade = Math.random();
        ctx.fillStyle = shade > 0.72 ? 'rgba(168, 188, 105, 0.34)' : (shade > 0.35 ? 'rgba(45, 91, 46, 0.36)' : 'rgba(104, 136, 70, 0.34)');
        ctx.fillRect(x, y, 1 + Math.random() * 2, 2 + Math.random() * 4);
      }
      for (var f = 0; f < 28; f += 1) {
        ctx.fillStyle = f % 3 === 0 ? 'rgba(247, 223, 137, 0.75)' : 'rgba(248, 244, 218, 0.6)';
        ctx.beginPath();
        ctx.arc(Math.random() * w, Math.random() * h, 0.8 + Math.random(), 0, Math.PI * 2);
        ctx.fill();
      }
    }, 14, 12);
  };

  World.prototype.makePathTexture = function () {
    return this.makeTexture(256, 256, function (ctx, w, h) {
      ctx.fillStyle = '#b08a5d';
      ctx.fillRect(0, 0, w, h);
      for (var i = 0; i < 1500; i += 1) {
        var c = Math.random();
        ctx.fillStyle = c > 0.72 ? 'rgba(225, 198, 151, 0.55)' : (c > 0.35 ? 'rgba(122, 90, 54, 0.3)' : 'rgba(95, 70, 44, 0.24)');
        ctx.beginPath();
        ctx.arc(Math.random() * w, Math.random() * h, 0.7 + Math.random() * 2.2, 0, Math.PI * 2);
        ctx.fill();
      }
    }, 1, 6);
  };

  World.prototype.makeWoodTexture = function () {
    return this.makeTexture(256, 256, function (ctx, w, h) {
      ctx.fillStyle = '#8c5c43';
      ctx.fillRect(0, 0, w, h);
      for (var x = 0; x < w; x += 24) {
        ctx.fillStyle = 'rgba(63, 37, 27, 0.2)';
        ctx.fillRect(x, 0, 2, h);
        ctx.fillStyle = 'rgba(235, 200, 155, 0.09)';
        ctx.fillRect(x + 3, 0, 3, h);
      }
      for (var i = 0; i < 120; i += 1) {
        ctx.strokeStyle = 'rgba(70, 42, 30, 0.12)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        var y = Math.random() * h;
        ctx.moveTo(0, y);
        ctx.bezierCurveTo(w * 0.3, y + rand(-8, 8), w * 0.7, y + rand(-8, 8), w, y + rand(-4, 4));
        ctx.stroke();
      }
    }, 2, 1);
  };

  World.prototype.makeStrawTexture = function () {
    return this.makeTexture(256, 256, function (ctx, w, h) {
      ctx.fillStyle = '#cfb277';
      ctx.fillRect(0, 0, w, h);
      for (var i = 0; i < 2200; i += 1) {
        var x = Math.random() * w;
        var y = Math.random() * h;
        ctx.strokeStyle = Math.random() > 0.5 ? 'rgba(247, 224, 161, 0.6)' : 'rgba(132, 102, 53, 0.35)';
        ctx.lineWidth = 0.7 + Math.random();
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + rand(-7, 7), y + rand(-2, 2));
        ctx.stroke();
      }
    }, 3, 2);
  };

  World.prototype.makeCowTexture = function (seed, base, spots) {
    var random = (function (s) {
      return function () {
        s = (s * 1664525 + 1013904223) % 4294967296;
        return s / 4294967296;
      };
    })(seed);
    return this.makeTexture(512, 256, function (ctx, w, h) {
      ctx.fillStyle = base;
      ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = spots;
      for (var i = 0; i < 10; i += 1) {
        var cx = random() * w;
        var cy = random() * h;
        var rx = 22 + random() * 58;
        var ry = 18 + random() * 42;
        ctx.beginPath();
        var points = 8;
        for (var p = 0; p <= points; p += 1) {
          var a = (p / points) * Math.PI * 2;
          var noise = 0.75 + random() * 0.45;
          var x = cx + Math.cos(a) * rx * noise;
          var y = cy + Math.sin(a) * ry * noise;
          if (p === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.fill();
      }
      ctx.fillStyle = 'rgba(255,255,255,0.12)';
      for (var s = 0; s < 30; s += 1) {
        ctx.beginPath();
        ctx.arc(random() * w, random() * h, 1 + random() * 3, 0, Math.PI * 2);
        ctx.fill();
      }
    });
  };

  World.prototype.makeSailTexture = function () {
    return this.makeTexture(256, 256, function (ctx, w, h) {
      ctx.fillStyle = '#eadcc4';
      ctx.fillRect(0, 0, w, h);
      ctx.fillStyle = '#c96f4d';
      for (var i = 0; i < 4; i += 1) {
        ctx.fillRect(i * 64 + 30, 0, 22, h);
      }
      ctx.fillStyle = 'rgba(255,255,255,0.18)';
      ctx.fillRect(0, 0, w, 18);
      ctx.fillStyle = 'rgba(70,50,35,0.08)';
      for (var y = 0; y < h; y += 32) ctx.fillRect(0, y, w, 1);
    }, 1, 1);
  };

  World.prototype.makeSignTexture = function (title, sub) {
    return this.makeTexture(512, 224, function (ctx, w, h) {
      ctx.clearRect(0, 0, w, h);
      ctx.fillStyle = '#f5ead1';
      ctx.strokeStyle = '#254e3d';
      ctx.lineWidth = 10;
      var r = 26;
      ctx.beginPath();
      ctx.moveTo(16 + r, 16);
      ctx.arcTo(w - 16, 16, w - 16, h - 16, r);
      ctx.arcTo(w - 16, h - 16, 16, h - 16, r);
      ctx.arcTo(16, h - 16, 16, 16, r);
      ctx.arcTo(16, 16, w - 16, 16, r);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#214c3b';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = '700 40px "Trebuchet MS", sans-serif';
      ctx.fillText(title, w / 2, sub ? 85 : 112);
      if (sub) {
        ctx.fillStyle = '#b05f43';
        ctx.font = '700 22px "Trebuchet MS", sans-serif';
        ctx.fillText(sub, w / 2, 144);
      }
      ctx.fillStyle = '#c8a967';
      ctx.fillRect(w / 2 - 50, h - 35, 100, 6);
    });
  };

  World.prototype.makeSign = function (title, sub, width, height) {
    var texture = this.makeSignTexture(title, sub);
    var mat = new T.MeshBasicMaterial({ map: texture, transparent: true, side: T.DoubleSide });
    var mesh = new T.Mesh(new T.PlaneGeometry(width, height), mat);
    mesh.castShadow = false;
    return mesh;
  };

  World.prototype.box = function (w, h, d, color, x, y, z, options) {
    options = options || {};
    var material;
    if (options.material) {
      material = options.material;
    } else {
      material = new T.MeshStandardMaterial({
        color: new T.Color(color),
        roughness: options.roughness == null ? 0.92 : options.roughness,
        metalness: options.metalness || 0,
        flatShading: !!options.flat,
        transparent: !!options.transparent,
        opacity: options.opacity == null ? 1 : options.opacity,
        side: options.side || T.FrontSide
      });
      if (options.map) material.map = options.map;
      if (options.emissive) material.emissive = new T.Color(options.emissive);
      if (options.emissiveIntensity != null) material.emissiveIntensity = options.emissiveIntensity;
    }
    var mesh = new T.Mesh(new T.BoxGeometry(w, h, d), material);
    mesh.position.set(x, y, z);
    if (options.rotation) mesh.rotation.set(options.rotation.x || 0, options.rotation.y || 0, options.rotation.z || 0);
    mesh.castShadow = options.castShadow !== false;
    mesh.receiveShadow = options.receiveShadow !== false;
    return mesh;
  };

  World.prototype.cylinder = function (rt, rb, h, seg, color, x, y, z, options) {
    options = options || {};
    var mat = options.material || new T.MeshStandardMaterial({
      color: new T.Color(color),
      roughness: options.roughness == null ? 0.9 : options.roughness,
      metalness: options.metalness || 0,
      flatShading: !!options.flat
    });
    var mesh = new T.Mesh(new T.CylinderGeometry(rt, rb, h, seg || 8), mat);
    mesh.position.set(x, y, z);
    if (options.rotation) mesh.rotation.set(options.rotation.x || 0, options.rotation.y || 0, options.rotation.z || 0);
    mesh.castShadow = options.castShadow !== false;
    mesh.receiveShadow = options.receiveShadow !== false;
    return mesh;
  };

  World.prototype.sphere = function (radius, color, x, y, z, options) {
    options = options || {};
    var mat = options.material || new T.MeshStandardMaterial({
      color: new T.Color(color),
      roughness: options.roughness == null ? 0.85 : options.roughness,
      metalness: options.metalness || 0,
      flatShading: !!options.flat,
      transparent: !!options.transparent,
      opacity: options.opacity == null ? 1 : options.opacity
    });
    var mesh = new T.Mesh(new T.SphereGeometry(radius, options.segments || 10, options.rings || 7), mat);
    mesh.position.set(x, y, z);
    if (options.scale) mesh.scale.set(options.scale.x, options.scale.y, options.scale.z);
    mesh.castShadow = options.castShadow !== false;
    mesh.receiveShadow = options.receiveShadow !== false;
    return mesh;
  };

  /* ---------------------------------------------------------
     Land, paths, fences
     --------------------------------------------------------- */

  World.prototype.buildTerrain = function () {
    var grassTex = this.makeGrassTexture();
    var groundMat = new T.MeshStandardMaterial({
      color: 0xffffff,
      map: grassTex,
      roughness: 1,
      metalness: 0
    });
    var ground = new T.Mesh(new T.PlaneGeometry(74, 68, 1, 1), groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.set(0, 0, -1);
    ground.receiveShadow = true;
    this.scene.add(ground);
    this.ground = ground;

    // A slightly warmer, lusher pasture carpet.
    var pastureMat = new T.MeshStandardMaterial({
      color: 0xa8ca8b,
      map: grassTex.clone(),
      roughness: 1,
      transparent: true,
      opacity: 0.16,
      depthWrite: false
    });
    pastureMat.map.needsUpdate = true;
    pastureMat.map.repeat.set(9, 8);
    var pasture = new T.Mesh(new T.PlaneGeometry(25.4, 23.2), pastureMat);
    pasture.rotation.x = -Math.PI / 2;
    pasture.position.set(17, 0.008, -1.5);
    pasture.receiveShadow = true;
    this.scene.add(pasture);

    // A few warm stones.
    var stoneMat = new T.MeshStandardMaterial({ color: 0x8e9183, roughness: 1, flatShading: true });
    for (var s = 0; s < 14; s += 1) {
      var stone = new T.Mesh(new T.DodecahedronGeometry(rand(0.18, 0.45), 0), stoneMat);
      var sx = rand(-30, 30);
      var sz = rand(-25, 25);
      if (Math.abs(sx) < 5 && Math.abs(sz - 15) < 8) {
        sx += 7;
      }
      stone.position.set(sx, rand(0.05, 0.16), sz);
      stone.rotation.set(rand(0, 1), rand(0, 3), rand(0, 1));
      stone.scale.y = rand(0.4, 0.75);
      stone.castShadow = true;
      stone.receiveShadow = true;
      this.scene.add(stone);
    }
  };

  World.prototype.makePathRibbon = function (points, width, material) {
    var curve = new T.CatmullRomCurve3(points.map(function (p) { return new T.Vector3(p[0], 0, p[1]); }));
    var count = 90;
    var curvePoints = curve.getSpacedPoints(count);
    var positions = [];
    var uvs = [];
    var indices = [];
    for (var i = 0; i <= count; i += 1) {
      var p = curvePoints[i];
      var prev = curvePoints[Math.max(0, i - 1)];
      var next = curvePoints[Math.min(count, i + 1)];
      var dx = next.x - prev.x;
      var dz = next.z - prev.z;
      var len = Math.sqrt(dx * dx + dz * dz) || 1;
      var nx = -dz / len;
      var nz = dx / len;
      var wobble = Math.sin(i * 0.7) * 0.12;
      var w = width * 0.5 + wobble;
      positions.push(p.x + nx * w, 0.025, p.z + nz * w);
      positions.push(p.x - nx * w, 0.025, p.z - nz * w);
      uvs.push(0, i / 7, 1, i / 7);
      if (i < count) {
        var a = i * 2;
        indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
      }
    }
    var geo = new T.BufferGeometry();
    geo.setAttribute('position', new T.Float32BufferAttribute(positions, 3));
    geo.setAttribute('uv', new T.Float32BufferAttribute(uvs, 2));
    geo.setIndex(indices);
    geo.computeVertexNormals();
    var mesh = new T.Mesh(geo, material);
    mesh.receiveShadow = true;
    return mesh;
  };

  World.prototype.buildPaths = function () {
    var tex = this.makePathTexture();
    var mat = new T.MeshStandardMaterial({
      map: tex,
      color: 0xffffff,
      roughness: 1,
      side: T.DoubleSide,
      polygonOffset: true,
      polygonOffsetFactor: -1
    });
    var mainPath = this.makePathRibbon([[4.8, 24], [4.5, 20.8], [5.3, 17.2], [6.8, 13.5], [8.7, 10.6], [10.3, 7.4]], 2.5, mat.clone());
    mainPath.name = 'path-main';
    var stationPath = this.makePathRibbon([[4.5, 20.8], [0.4, 18.8], [-3.7, 17.9]], 1.8, mat.clone());
    stationPath.name = 'path-station';
    var pasturePath = this.makePathRibbon([[9.3, 8.2], [13.2, 6.6], [18.0, 7.3], [23.2, 7.7]], 1.4, mat.clone());
    pasturePath.name = 'path-pasture';
    this.scene.add(mainPath, stationPath, pasturePath);
  };

  World.prototype.addFenceCollider = function (x1, z1, x2, z2) {
    this.colliders.rects.push({
      minX: Math.min(x1, x2) - 0.24,
      maxX: Math.max(x1, x2) + 0.24,
      minZ: Math.min(z1, z2) - 0.24,
      maxZ: Math.max(z1, z2) + 0.24
    });
  };

  World.prototype.fenceLine = function (x1, z1, x2, z2) {
    var dx = x2 - x1;
    var dz = z2 - z1;
    var len = Math.sqrt(dx * dx + dz * dz);
    if (len < 0.2) return;
    var angle = Math.atan2(-dz, dx);
    var count = Math.max(1, Math.round(len / 2));
    for (var i = 0; i <= count; i += 1) {
      var t = i / count;
      this.fencePosts.push({ x: lerp(x1, x2, t), z: lerp(z1, z2, t), y: 0.58 });
    }
    for (var r = 0; r < count; r += 1) {
      var t1 = (r + 0.5) / count;
      var segLen = len / count;
      this.fenceRails.push({ x: lerp(x1, x2, t1), z: lerp(z1, z2, t1), y: 0.44, rot: angle, scale: segLen });
      this.fenceRails.push({ x: lerp(x1, x2, t1), z: lerp(z1, z2, t1), y: 0.82, rot: angle, scale: segLen });
    }
    this.addFenceCollider(x1, z1, x2, z2);
  };

  World.prototype.buildFences = function () {
    this.fencePosts = [];
    this.fenceRails = [];

    // Main cow pasture: open gate between x=7.2 and x=10.2.
    this.fenceLine(4, 10.5, 7.2, 10.5);
    this.fenceLine(10.2, 10.5, 30, 10.5);
    this.fenceLine(4, 10.5, 4, -13.5);
    this.fenceLine(30, 10.5, 30, -13.5);
    this.fenceLine(4, -13.5, 7, -13.5);
    this.fenceLine(23, -13.5, 30, -13.5);

    // Pig pen with a small gate.
    this.fenceLine(-28, -8, -17, -8);
    this.fenceLine(-28, 3, -17, 3);
    this.fenceLine(-28, -8, -28, 3);
    this.fenceLine(-17, -8, -17, -3.2);
    this.fenceLine(-17, -0.8, -17, 3);

    // Chicken yard with a gate.
    this.fenceLine(-17, -1, -9, -1);
    this.fenceLine(-17, 6, -9, 6);
    this.fenceLine(-17, -1, -17, 6);
    this.fenceLine(-9, -1, -9, 2);
    this.fenceLine(-9, 4, -9, 6);

    var postGeo = new T.BoxGeometry(1, 1, 1);
    var postMat = new T.MeshStandardMaterial({ color: 0x765039, roughness: 0.94 });
    var railMat = new T.MeshStandardMaterial({ color: 0xb08b5c, roughness: 0.94 });
    var dummy = new T.Object3D();
    var posts = new T.InstancedMesh(postGeo, postMat, this.fencePosts.length);
    posts.castShadow = true;
    posts.receiveShadow = true;
    this.fencePosts.forEach(function (p, i) {
      dummy.position.set(p.x, p.y, p.z);
      dummy.rotation.set(0, 0, 0);
      dummy.scale.set(0.17, 1.16, 0.17);
      dummy.updateMatrix();
      posts.setMatrixAt(i, dummy.matrix);
    });
    posts.instanceMatrix.needsUpdate = true;
    this.scene.add(posts);

    var rails = new T.InstancedMesh(postGeo, railMat, this.fenceRails.length);
    rails.castShadow = true;
    rails.receiveShadow = true;
    this.fenceRails.forEach(function (p, i) {
      dummy.position.set(p.x, p.y, p.z);
      dummy.rotation.set(0, p.rot, 0);
      dummy.scale.set(p.scale, 0.09, 0.08);
      dummy.updateMatrix();
      rails.setMatrixAt(i, dummy.matrix);
    });
    rails.instanceMatrix.needsUpdate = true;
    this.scene.add(rails);

    // Gate posts are a little more substantial.
    [7.2, 10.2].forEach(function (x) {
      var post = this.box(0.28, 1.5, 0.28, '#6d4933', x, 0.75, 10.5);
      this.scene.add(post);
    }, this);

    // Open wooden gate leaf resting to the side.
    var gate = new T.Group();
    var gateFrame = this.box(2.5, 0.13, 0.1, '#b28a5c', 0, 0.72, 0);
    var gateFrame2 = this.box(2.5, 0.13, 0.1, '#b28a5c', 0, 0.28, 0);
    var gateBar = this.box(0.11, 1.0, 0.1, '#b28a5c', -1.1, 0.52, 0);
    var gateBar2 = this.box(0.11, 1.0, 0.1, '#b28a5c', 1.1, 0.52, 0);
    gate.add(gateFrame, gateFrame2, gateBar, gateBar2);
    gate.position.set(10.4, 0, 9.3);
    gate.rotation.y = -0.75;
    this.scene.add(gate);
  };

  /* ---------------------------------------------------------
     Buildings
     --------------------------------------------------------- */

  World.prototype.buildFarmBuildings = function () {
    var woodTex = this.makeWoodTexture();
    this.woodTex = woodTex;
    this.woodMat = new T.MeshStandardMaterial({ map: woodTex, color: 0xffffff, roughness: 0.92 });
    this.strawTex = this.makeStrawTexture();
    this.strawMat = new T.MeshStandardMaterial({ map: this.strawTex, color: 0xffffff, roughness: 1 });

    this.buildBarn();
    this.buildResearchStation();
  };

  World.prototype.buildBarn = function () {
    var g = new T.Group();
    var floor = new T.Mesh(new T.PlaneGeometry(16.6, 9.4), this.strawMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(15, 0.035, -18.25);
    floor.receiveShadow = true;
    g.add(floor);

    var back = this.box(16.4, 4.1, 0.36, '#ffffff', 15, 2.05, -23, { material: this.woodMat.clone() });
    back.name = 'barn-back-wall';
    var left = this.box(0.36, 4.1, 9.4, '#ffffff', 7, 2.05, -18.25, { material: this.woodMat.clone() });
    left.name = 'barn-left-wall';
    var right = this.box(0.36, 4.1, 9.4, '#ffffff', 23, 2.05, -18.25, { material: this.woodMat.clone() });
    right.name = 'barn-right-wall';
    g.add(back, left, right);

    // White trim at the open front.
    g.add(this.box(16.1, 0.25, 0.32, '#eadfc8', 15, 4.12, -13.5));
    [7.25, 11.2, 15, 18.8, 22.75].forEach(function (x) {
      g.add(this.box(0.25, 4.2, 0.28, '#e8ddc6', x, 2.1, -13.5));
    }, this);
    [7.4, 22.6].forEach(function (x) {
      g.add(this.box(0.2, 4.2, 0.2, '#e8ddc6', x, 2.1, -23.15));
    }, this);

    // Gable roof: two broad sloped panels.
    var roofMat = new T.MeshStandardMaterial({ color: 0x78362d, roughness: 0.82, metalness: 0.04 });
    var backRoof = new T.Mesh(new T.BoxGeometry(17.2, 0.24, 5.65), roofMat.clone());
    backRoof.name = 'barn-back-roof';
    backRoof.position.set(15, 5.45, -20.75);
    backRoof.rotation.x = -0.268;
    backRoof.castShadow = true;
    backRoof.receiveShadow = true;
    g.add(backRoof);
    var frontRoof = new T.Mesh(new T.BoxGeometry(17.2, 0.24, 5.65), roofMat.clone());
    frontRoof.name = 'barn-front-roof';
    frontRoof.position.set(15, 5.45, -15.75);
    frontRoof.rotation.x = 0.268;
    frontRoof.castShadow = true;
    frontRoof.receiveShadow = true;
    g.add(frontRoof);
    g.add(this.box(17.4, 0.22, 0.34, '#5d342b', 15, 6.15, -18.25, { castShadow: true }));

    // Hayloft opening detail.
    g.add(this.box(2.2, 1.15, 0.1, '#52392c', 15, 3.2, -22.79, { castShadow: false }));
    g.add(this.box(2.0, 0.12, 0.12, '#e1d1b4', 15, 3.72, -22.72, { castShadow: false }));
    g.add(this.box(2.0, 0.12, 0.12, '#e1d1b4', 15, 2.67, -22.72, { castShadow: false }));

    // Interior stalls and feed rack.
    var stallMat = new T.MeshStandardMaterial({ color: 0x72503b, roughness: 0.95 });
    for (var s = 0; s < 4; s += 1) {
      var x = 9 + s * 3.2;
      g.add(this.box(0.12, 1.1, 3.7, '#72503b', x, 0.58, -20.4, { material: stallMat }));
      g.add(this.box(2.9, 0.12, 0.12, '#72503b', x + 1.5, 1.1, -18.55, { material: stallMat }));
    }
    for (var h = 0; h < 3; h += 1) {
      var bale = this.cylinder(0.48, 0.48, 1.0, 10, '#d3b574', 20.2 + h * 1.12, 0.5, -21.5, { rotation: { z: Math.PI / 2 }, flat: true });
      g.add(bale);
    }
    g.add(this.box(6.0, 0.24, 0.46, '#7b5c3e', 15, 1.05, -22.25));
    g.add(this.box(5.4, 0.1, 0.15, '#d7b96f', 15, 1.18, -22.1));

    // Two ceiling fans.
    [11.3, 18.7].forEach(function (fx) {
      var fanGroup = new T.Group();
      fanGroup.position.set(fx, 4.15, -18.2);
      fanGroup.add(this.cylinder(0.22, 0.22, 0.36, 10, '#4d4a43', 0, 0, 0, { metalness: 0.3 }));
      var blades = new T.Group();
      for (var b = 0; b < 4; b += 1) {
        var blade = this.box(1.4, 0.05, 0.22, '#d7cbb4', 0.72, 0, 0, { castShadow: false });
        blade.rotation.y = (b / 4) * Math.PI * 2;
        blade.position.x = Math.cos((b / 4) * Math.PI * 2) * 0.7;
        blade.position.z = -Math.sin((b / 4) * Math.PI * 2) * 0.7;
        blades.add(blade);
      }
      blades.rotation.x = 0.08;
      fanGroup.add(blades);
      this.fanBlades.push({ group: blades, speed: 0 });
      g.add(fanGroup);
    }, this);

    // Small warm barn lights.
    [10.5, 19.5].forEach(function (lx) {
      var lamp = this.sphere(0.13, '#ffe1a0', lx, 3.9, -17.6, {
        emissive: '#ffcf76',
        castShadow: false,
        segments: 8,
        rings: 6
      });
      lamp.material.emissiveIntensity = 1.1;
      g.add(lamp);
    }, this);

    // Fan switch on a front post. Interactable.
    var switchGroup = new T.Group();
    switchGroup.position.set(15.05, 1.05, -13.3);
    switchGroup.add(this.box(0.22, 0.32, 0.14, '#e9ddc7', 0, 0, 0));
    var switchLamp = this.sphere(0.055, '#b76b4f', 0, 0.02, 0.09, { castShadow: false, segments: 6, rings: 4 });
    switchGroup.add(switchLamp);
    this.fanSwitchLamp = switchLamp;
    g.add(switchGroup);

    var sign = this.makeSign('LAUFSTALL', 'LUFT · SCHATTEN · RÜCKZUG', 4.4, 1.92);
    sign.position.set(15, 5.5, -13.32);
    g.add(sign);

    this.scene.add(g);
    this.barn = g;

    // Wall collisions only — the south front stays open.
    this.colliders.rects.push({ minX: 6.75, maxX: 7.25, minZ: -23.2, maxZ: -13.4 });
    this.colliders.rects.push({ minX: 22.75, maxX: 23.25, minZ: -23.2, maxZ: -13.4 });
    this.colliders.rects.push({ minX: 6.75, maxX: 23.25, minZ: -23.25, maxZ: -22.75 });
  };

  World.prototype.buildResearchStation = function () {
    var g = new T.Group();
    var floorMat = new T.MeshStandardMaterial({ color: 0xcfc3a9, roughness: 0.95 });
    var floor = new T.Mesh(new T.BoxGeometry(9.2, 0.18, 6.6), floorMat);
    floor.position.set(-3.5, 0.09, 14.25);
    floor.receiveShadow = true;
    floor.castShadow = false;
    g.add(floor);

    var wallMat = new T.MeshStandardMaterial({ color: 0xf0e6d2, roughness: 0.9 });
    var beamMat = new T.MeshStandardMaterial({ color: 0x3d6855, roughness: 0.85 });
    var stationBack = this.box(9.0, 3.25, 0.24, '#f0e6d2', -3.5, 1.65, 11.05, { material: wallMat.clone() });
    stationBack.name = 'station-back-wall';
    var stationLeft = this.box(0.24, 3.25, 6.5, '#f0e6d2', -8.0, 1.65, 14.3, { material: wallMat.clone() });
    stationLeft.name = 'station-left-wall';
    var stationRight = this.box(0.24, 3.25, 6.5, '#f0e6d2', 1.0, 1.65, 14.3, { material: wallMat.clone() });
    stationRight.name = 'station-right-wall';
    g.add(stationBack, stationLeft, stationRight);
    [11.1, 14.25, 17.45].forEach(function (z) {
      g.add(this.box(0.16, 3.3, 0.16, '#355c4b', -8, 1.65, z, { material: beamMat }));
      g.add(this.box(0.16, 3.3, 0.16, '#355c4b', 1, 1.65, z, { material: beamMat }));
    }, this);
    g.add(this.box(9.3, 0.18, 0.18, '#355c4b', -3.5, 3.22, 17.4, { material: beamMat }));

    // Green roof with overhang.
    var roofMat = new T.MeshStandardMaterial({ color: 0x3f6850, roughness: 0.8, metalness: 0.05 });
    var roof = new T.Mesh(new T.BoxGeometry(10.1, 0.26, 7.6), roofMat);
    roof.position.set(-3.5, 3.42, 14.25);
    roof.castShadow = true;
    roof.receiveShadow = true;
    g.add(roof);
    g.add(this.box(10.2, 0.1, 0.18, '#c8b279', -3.5, 3.57, 17.95, { castShadow: false }));

    // Solar panel on the roof.
    var panel = this.box(2.8, 0.08, 1.6, '#2a4857', -5.9, 3.65, 14.25, {
      metalness: 0.55,
      roughness: 0.3,
      rotation: { x: -0.12 },
      castShadow: false
    });
    g.add(panel);
    for (var p = 0; p < 4; p += 1) {
      g.add(this.box(0.03, 0.11, 1.55, '#b8cbd0', -6.95 + p * 0.7, 3.71, 14.25, { castShadow: false }));
    }

    // Windows on the side.
    var glassMat = new T.MeshStandardMaterial({
      color: 0xa9d4d4,
      roughness: 0.12,
      metalness: 0.1,
      transparent: true,
      opacity: 0.62
    });
    var window = new T.Mesh(new T.PlaneGeometry(2.4, 1.35), glassMat);
    window.position.set(-8.13, 1.85, 14.3);
    window.rotation.y = Math.PI / 2;
    g.add(window);
    g.add(this.box(0.08, 1.5, 0.1, '#f5ead5', -8.16, 1.85, 14.3, { castShadow: false }));
    g.add(this.box(0.08, 0.1, 2.55, '#f5ead5', -8.16, 1.85, 14.3, { castShadow: false }));

    // Desk and research equipment.
    var desk = new T.Group();
    desk.add(this.box(3.2, 0.13, 1.2, '#c59a67', 0, 0.92, 0));
    [[-1.4, -0.45], [1.4, -0.45], [-1.4, 0.45], [1.4, 0.45]].forEach(function (leg) {
      desk.add(this.box(0.12, 0.9, 0.12, '#755039', leg[0], 0.46, leg[1]));
    }, this);
    var laptopBase = this.box(0.9, 0.06, 0.62, '#394b4a', 0.35, 1.015, -0.05, { metalness: 0.25 });
    var laptopScreen = this.box(0.88, 0.56, 0.05, '#2e4c4c', 0.35, 1.3, -0.3, { rotation: { x: -0.18 } });
    var screenGlow = this.box(0.77, 0.44, 0.015, '#9fcfc2', 0.35, 1.31, -0.33, {
      emissive: '#75b9a6',
      emissiveIntensity: 0.5,
      rotation: { x: -0.18 },
      castShadow: false
    });
    desk.add(laptopBase, laptopScreen, screenGlow);
    desk.add(this.box(0.45, 0.04, 0.32, '#f3ead7', 1.3, 1.005, 0.2));
    desk.add(this.box(0.32, 0.2, 0.32, '#5d8c80', 1.3, 1.12, 0.2, { metalness: 0.15 }));
    desk.add(this.cylinder(0.1, 0.12, 0.28, 8, '#93c6b9', -0.45, 1.08, 0.3, { transparent: true, opacity: 0.7 }));
    desk.position.set(-3.7, 0, 14.25);
    g.add(desk);

    // Shelves on the back wall.
    g.add(this.box(3.0, 0.1, 0.45, '#9b754c', -5.2, 2.25, 11.32));
    for (var j = 0; j < 5; j += 1) {
      var jar = this.cylinder(0.12, 0.12, 0.3, 8, j % 2 ? '#89aa82' : '#d2b078', -6.2 + j * 0.5, 2.45, 11.32, {
        transparent: true,
        opacity: 0.75
      });
      g.add(jar);
    }

    // Chart board.
    var chart = this.box(1.5, 1.2, 0.06, '#e9ddc6', -5.9, 2.45, 11.2, {
      castShadow: false,
      rotation: { y: 0 }
    });
    g.add(chart);
    g.add(this.box(1.25, 0.05, 0.03, '#b66c4f', -5.9, 2.65, 11.15, { castShadow: false }));
    g.add(this.box(1.0, 0.03, 0.03, '#5b8a6e', -5.9, 2.3, 11.15, { castShadow: false }));

    // A plant by the entrance.
    var pot = this.cylinder(0.3, 0.24, 0.4, 8, '#b46b4e', 0.25, 0.3, 16.2);
    g.add(pot);
    for (var leaf = 0; leaf < 5; leaf += 1) {
      var l = this.sphere(0.2, '#5f8a57', 0.25 + Math.cos(leaf * 1.3) * 0.18, 0.62 + leaf * 0.1, 16.2 + Math.sin(leaf * 1.3) * 0.14, {
        scale: { x: 1.4, y: 0.5, z: 0.7 },
        flat: true
      });
      g.add(l);
    }

    var sign = this.makeSign('FORSCHUNG', 'TIERWOHL · KLIMA · VERHALTEN', 3.6, 1.57);
    sign.position.set(-3.5, 4.45, 18.1);
    g.add(sign);

    this.scene.add(g);
    this.station = g;

    this.colliders.rects.push({ minX: -8.2, maxX: 1.2, minZ: 10.9, maxZ: 11.35 });
    this.colliders.rects.push({ minX: -8.2, maxX: -7.75, minZ: 10.9, maxZ: 17.6 });
    this.colliders.rects.push({ minX: 0.75, maxX: 1.2, minZ: 10.9, maxZ: 17.6 });
    this.colliders.rects.push({ minX: -5.4, maxX: -2.0, minZ: 13.55, maxZ: 14.95 });
  };

  /* ---------------------------------------------------------
     Pens, garden, props, trees
     --------------------------------------------------------- */

  World.prototype.buildPens = function () {
    // Pig pen ground and mud.
    var mud = new T.Mesh(new T.CircleGeometry(3.7, 28), new T.MeshStandardMaterial({ color: 0x6f5541, roughness: 1 }));
    mud.rotation.x = -Math.PI / 2;
    mud.position.set(-22.5, 0.02, -2.5);
    mud.scale.set(1.35, 0.75, 1);
    mud.receiveShadow = true;
    this.scene.add(mud);

    var strawPatch = new T.Mesh(new T.CircleGeometry(2.3, 20), new T.MeshStandardMaterial({ color: 0xc9ad71, roughness: 1 }));
    strawPatch.rotation.x = -Math.PI / 2;
    strawPatch.position.set(-19.7, 0.025, 1.2);
    strawPatch.scale.set(1.2, 0.8, 1);
    this.scene.add(strawPatch);

    var shelter = new T.Group();
    shelter.add(this.box(4.6, 0.24, 3.2, '#6b4a36', 0, 0.13, 0));
    shelter.add(this.box(4.6, 2.2, 0.2, '#9a6e4d', 0, 1.2, -1.45));
    shelter.add(this.box(0.2, 2.2, 3.2, '#9a6e4d', -2.2, 1.2, 0));
    shelter.add(this.box(0.2, 2.2, 3.2, '#9a6e4d', 2.2, 1.2, 0));
    var roof = this.box(5.2, 0.18, 3.8, '#7c4f3d', 0, 2.4, 0, { rotation: { x: 0.08 } });
    shelter.add(roof);
    shelter.position.set(-24.9, 0, -5.2);
    this.scene.add(shelter);

    this.scene.add(this.cylinder(0.7, 0.7, 0.35, 12, '#8a6c4f', -20.2, 0.2, 0.2, { flat: true }));

    // Chicken coop and yard.
    var coop = new T.Group();
    coop.add(this.box(4.4, 0.22, 3.3, '#b88d5b', 0, 0.16, 0));
    coop.add(this.box(4.4, 1.9, 0.18, '#a97a4f', 0, 1.08, -1.55));
    coop.add(this.box(0.18, 1.9, 3.3, '#a97a4f', -2.1, 1.08, 0));
    coop.add(this.box(0.18, 1.9, 3.3, '#a97a4f', 2.1, 1.08, 0));
    var coopRoof = this.box(4.9, 0.18, 3.8, '#98513b', 0, 2.15, 0, { rotation: { x: 0.09 } });
    coop.add(coopRoof);
    coop.add(this.box(1.0, 1.25, 0.1, '#e6c994', 1.0, 1.0, 1.57));
    for (var n = 0; n < 3; n += 1) {
      var nest = this.box(0.9, 0.5, 0.8, '#9d7149', -1.1 + n * 1.1, 1.0, -0.9, { castShadow: false });
      coop.add(nest);
    }
    var ramp = this.box(0.9, 0.09, 2.1, '#b98d5e', 1.0, 0.48, 2.55, { rotation: { x: 0.45 } });
    coop.add(ramp);
    coop.add(this.box(0.15, 0.9, 0.15, '#755038', 2.2, 0.55, 1.75));
    coop.position.set(-13.2, 0, 3.7);
    this.scene.add(coop);
    this.coop = coop;

    // Chicken perch.
    var perch = new T.Group();
    perch.add(this.cylinder(0.07, 0.08, 3.0, 6, '#8a623f', 0, 0.72, 0, { rotation: { z: Math.PI / 2 } }));
    perch.add(this.box(0.1, 0.75, 0.1, '#8a623f', -1.35, 0.37, 0));
    perch.add(this.box(0.1, 0.75, 0.1, '#8a623f', 1.35, 0.37, 0));
    perch.position.set(-11.5, 0, 1.1);
    this.scene.add(perch);

    // Sand bath.
    var sand = new T.Mesh(new T.CircleGeometry(1.25, 18), new T.MeshStandardMaterial({ color: 0xcbb98f, roughness: 1 }));
    sand.rotation.x = -Math.PI / 2;
    sand.position.set(-14.8, 0.022, 1.2);
    this.scene.add(sand);

    // Feeding troughs.
    var pigTrough = this.box(2.2, 0.3, 0.65, '#7e817a', -19.3, 0.22, 0.7, { metalness: 0.2 });
    this.scene.add(pigTrough);
    var chickenFeed = this.cylinder(0.55, 0.42, 0.28, 12, '#8b8c7d', -11.6, 0.16, 4.7, { metalness: 0.2 });
    this.scene.add(chickenFeed);
  };

  World.prototype.buildGarden = function () {
    var g = new T.Group();
    var soilMat = new T.MeshStandardMaterial({ color: 0x715339, roughness: 1 });
    for (var row = 0; row < 4; row += 1) {
      var bed = new T.Mesh(new T.BoxGeometry(10.2, 0.16, 1.15), soilMat);
      bed.position.set(-22.2, 0.08, 11.2 + row * 2.0);
      bed.receiveShadow = true;
      g.add(bed);
      for (var p = 0; p < 12; p += 1) {
        var crop = this.sphere(rand(0.18, 0.28), p % 3 === 0 ? '#7ca05f' : '#5d8b4d', -26.8 + p * 0.85, 0.35, 11.2 + row * 2.0, {
          flat: true,
          segments: 7,
          rings: 5,
          scale: { x: 1.3, y: 0.8, z: 1.3 }
        });
        g.add(crop);
      }
    }
    // Compost.
    g.add(this.box(2.2, 1.0, 1.8, '#72543b', -25.7, 0.5, 19.1));
    g.add(this.box(2.0, 0.2, 1.6, '#4b3b2c', -25.7, 1.02, 19.1));
    g.add(this.box(2.3, 0.12, 1.9, '#9a7b52', -25.7, 1.12, 19.1));

    // Watering can.
    g.add(this.cylinder(0.28, 0.34, 0.5, 10, '#5e8e87', -18.3, 0.26, 17.8));
    g.add(this.box(0.7, 0.06, 0.07, '#5e8e87', -17.9, 0.42, 17.8, { rotation: { z: 0.6 } }));

    this.scene.add(g);
  };

  World.prototype.buildProps = function () {
    var baleMat = new T.MeshStandardMaterial({ color: 0xd3b475, roughness: 1, flatShading: true });
    var baleGeo = new T.CylinderGeometry(0.62, 0.62, 1.15, 12, 1);
    var bales = [
      [4.2, 0.62, -10.3], [5.2, 0.62, -9.8], [4.9, 1.42, -10.2],
      [2.0, 0.62, 8.0], [23.7, 0.62, -12.2]
    ];
    bales.forEach(function (b) {
      var mesh = new T.Mesh(baleGeo, baleMat);
      mesh.position.set(b[0], b[1], b[2]);
      mesh.rotation.z = Math.PI / 2;
      mesh.rotation.y = rand(-0.3, 0.3);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      this.scene.add(mesh);
    }, this);

    // Wooden crates.
    var crateMat = new T.MeshStandardMaterial({ color: 0x9e7249, roughness: 0.95 });
    for (var c = 0; c < 3; c += 1) {
      var crate = this.box(1.0, 0.8, 0.9, '#9e7249', 2.5 + c * 0.1, 0.4 + c * 0.81, 12.8, { material: crateMat });
      this.scene.add(crate);
      this.scene.add(this.box(1.05, 0.07, 0.95, '#6d4b33', 2.5 + c * 0.1, 0.78 + c * 0.81, 12.8, { castShadow: false }));
    }

    // Barrels.
    var barrelMat = new T.MeshStandardMaterial({ color: 0x7a5b3d, roughness: 0.9 });
    [[-9.8, 9.5], [-10.6, 9.9], [26.5, 7.2]].forEach(function (b) {
      var barrel = this.cylinder(0.35, 0.4, 1.0, 10, '#7a5b3d', b[0], 0.5, b[1], { material: barrelMat });
      this.scene.add(barrel);
      var band = this.cylinder(0.4, 0.4, 0.07, 10, '#4f4b42', b[0], 0.7, b[1], { metalness: 0.35 });
      this.scene.add(band);
    }, this);

    // A wheelbarrow near the garden.
    var barrow = new T.Group();
    barrow.add(this.box(1.4, 0.3, 0.8, '#527a69', 0, 0.45, 0));
    barrow.add(this.cylinder(0.35, 0.35, 0.12, 12, '#3f4a45', 0.6, 0.28, 0, { rotation: { z: Math.PI / 2 } }));
    barrow.add(this.box(0.12, 0.7, 0.12, '#5e4532', -0.6, 0.35, 0.35, { rotation: { z: 0.2 } }));
    barrow.add(this.box(0.12, 0.7, 0.12, '#5e4532', -0.6, 0.35, -0.35, { rotation: { z: 0.2 } }));
    barrow.position.set(-14.4, 0, 17.2);
    barrow.rotation.y = -0.4;
    this.scene.add(barrow);

    // Small plaque mounted on the pasture fence at the gate.
    var gateSign = new T.Group();
    var signMesh = this.makeSign('KUHWEIDE', 'FORSCHUNGSHERDE', 1.5, 0.66);
    signMesh.position.set(0, 1.16, 0.05);
    gateSign.add(signMesh);
    gateSign.add(this.box(1.5, 0.07, 0.08, '#6e4a31', 0, 0.82, -0.02, { castShadow: false }));
    gateSign.position.set(12.5, 0, 10.6);
    gateSign.rotation.y = 0;
    this.scene.add(gateSign);

    // Small orientation signs for the other research areas.
    this.addAreaSign('SCHWEINE', 'WÜHLEN · ERKUNDEN', -15.8, 5.4, 0);
    this.addAreaSign('HÜHNERHOF', 'SITZSTANGE · SAND', -8.2, 7.2, 0);
    this.addAreaSign('FUTTERGARTEN', 'PFLANZEN · KREISLAUF', -13.0, 10.1, 0);
  };

  World.prototype.addAreaSign = function (title, sub, x, z, rotation) {
    var g = new T.Group();
    g.add(this.cylinder(0.08, 0.1, 1.55, 6, '#6e4a31', 0, 0.78, 0));
    var sign = this.makeSign(title, sub, 1.85, 0.81);
    sign.position.set(0, 1.45, 0.05);
    g.add(sign);
    g.position.set(x, 0, z);
    g.rotation.y = rotation;
    this.scene.add(g);
  };

  World.prototype.makeTree = function (x, z, scale, variant) {
    var g = new T.Group();
    scale = scale || 1;
    variant = variant || 0;
    var trunkMat = new T.MeshStandardMaterial({ color: variant === 2 ? 0x6d5135 : 0x76553a, roughness: 1, flatShading: true });
    var trunk = new T.Mesh(new T.CylinderGeometry(0.22 * scale, 0.34 * scale, 2.5 * scale, 7), trunkMat);
    trunk.position.y = 1.25 * scale;
    trunk.castShadow = true;
    trunk.receiveShadow = true;
    g.add(trunk);

    if (variant !== 2) {
      var branchMat = new T.MeshStandardMaterial({ color: 0x6d4c32, roughness: 1, flatShading: true });
      var b1 = new T.Mesh(new T.CylinderGeometry(0.09 * scale, 0.13 * scale, 1.4 * scale, 6), branchMat);
      b1.position.set(0.28 * scale, 2.15 * scale, 0.05);
      b1.rotation.z = -0.55;
      g.add(b1);
      var b2 = b1.clone();
      b2.position.set(-0.3 * scale, 2.25 * scale, -0.1);
      b2.rotation.z = 0.65;
      g.add(b2);
    }

    var foliageColors = [0x2f6a2c, 0x3a7a30, 0x4a8a34, 0x285e2a];
    var leafMat = new T.MeshStandardMaterial({
      color: foliageColors[variant % foliageColors.length],
      roughness: 0.95,
      flatShading: true,
      vertexColors: true
    });
    var shadeCanopy = function (geo, tint) {
      var pos = geo.attributes.position;
      var cols = new Float32Array(pos.count * 3);
      geo.computeBoundingBox();
      var lo = geo.boundingBox.min.y, span = (geo.boundingBox.max.y - lo) || 1;
      for (var v = 0; v < pos.count; v += 1) {
        var k = (0.6 + ((pos.getY(v) - lo) / span) * 0.55) * tint;
        cols[v * 3] = k * 1.02; cols[v * 3 + 1] = k; cols[v * 3 + 2] = k * 0.9;
      }
      geo.setAttribute('color', new T.BufferAttribute(cols, 3));
      return geo;
    };
    var clumps = variant === 2 ? 3 : 6;
    for (var i = 0; i < clumps; i += 1) {
      var radius = (1.2 + Math.random() * 0.55) * scale;
      var clump = new T.Mesh(shadeCanopy(new T.IcosahedronGeometry(radius * (i < 4 ? 1 : 0.72), 1), 0.9 + Math.random() * 0.25), leafMat);
      var angle = i * 2.4;
      clump.position.set(
        Math.cos(angle) * (0.75 + Math.random() * 0.5) * scale,
        (2.9 + Math.random() * 1.15) * scale,
        Math.sin(angle) * (0.7 + Math.random() * 0.45) * scale
      );
      clump.scale.set(1.05, 0.78, 1.0);
      clump.rotation.set(rand(0, 1), rand(0, 3), rand(0, 1));
      clump.castShadow = true;
      clump.receiveShadow = true;
      g.add(clump);
    }
    if (variant !== 2) {
      var top = new T.Mesh(shadeCanopy(new T.IcosahedronGeometry(1.35 * scale, 1), 1.12), leafMat);
      top.position.set(0.1, 4.0 * scale, 0);
      top.scale.set(1.1, 0.9, 1.05);
      top.castShadow = true;
      g.add(top);
    }
    g.position.set(x, 0, z);
    g.rotation.y = rand(0, Math.PI * 2);
    this.scene.add(g);
    this.colliders.circles.push({ x: x, z: z, r: 0.48 * scale });
    this.treeCanopies.push({
      group: g,
      material: leafMat,
      center: new T.Vector3(x, 3.5 * scale, z),
      radius: 2.35 * scale,
      opacity: 1
    });
    return g;
  };

  World.prototype.buildTrees = function () {
    // Pasture shade trees — deliberately shaded islands in the open field.
    this.treeA = this.makeTree(8.2, -9.3, 1.38, 0);
    this.treeB = this.makeTree(26.8, -9.5, 1.18, 1);
    this.treeC = this.makeTree(32.6, 6.5, 0.9, 2);

    var trees = [
      [-12.5, -12.8, 1.2, 1], [-20.5, -12.4, 1.05, 2], [-30, -12.5, 1.25, 0],
      [-31.2, 3.5, 1.1, 1], [-30.6, 15.5, 1.0, 2], [-28.5, 24.8, 1.25, 0],
      [-18.5, 25.5, 1.2, 1], [-8.5, 28.5, 1.0, 2], [20.5, 29.5, 1.1, 0],
      [16.5, 25.5, 1.3, 1], [27.5, 22.5, 1.1, 0], [33.0, 12.0, 1.25, 2],
      [33.0, -2.0, 1.0, 1], [32.0, -17.0, 1.2, 0], [24.0, -26.0, 1.1, 2],
      [10.0, -26.5, 1.2, 1], [-3.0, -27.0, 1.0, 0], [-15.0, -26.0, 1.25, 2],
      [-26.0, -22.0, 1.1, 1], [-31.0, -6.0, 0.9, 2]
    ];
    trees.forEach(function (t) { this.makeTree(t[0], t[1], t[2], t[3]); }, this);

    // Low bushes soften corners.
    var bushMat = new T.MeshStandardMaterial({ color: 0x5f9049, roughness: 1, flatShading: true });
    var bushGeo = new T.IcosahedronGeometry(1, 1);
    var bushes = [
      [-10, 10.5, 0.8], [-9.2, 10.9, 0.6], [3.4, 8.2, 0.7], [31.8, 5.5, 0.8],
      [-29.5, 7.0, 0.9], [-29.8, 9.4, 0.65], [4.2, -24.8, 0.8], [26.8, 12.4, 0.7]
    ];
    bushes.forEach(function (b) {
      var bush = new T.Mesh(bushGeo, bushMat);
      bush.position.set(b[0], b[2] * 0.55, b[1]);
      bush.scale.set(b[2], b[2] * 0.7, b[2] * 0.9);
      bush.rotation.set(rand(0, 1), rand(0, 3), 0);
      bush.castShadow = true;
      bush.receiveShadow = true;
      this.scene.add(bush);
    }, this);
  };

  World.prototype.buildWeatherStation = function () {
    var g = new T.Group();
    g.position.set(5.8, 0, 8.1);
    g.rotation.y = 0;
    this.terminalGroup = g;

    // A walk-up climate terminal: physical frame, local HTML screen,
    // and a live canvas standby display when the HTML layer is closed.
    g.add(this.box(3.7, 0.22, 1.25, '#7f867e', 0, 0.11, 0.14));
    g.add(this.box(2.78, 0.2, 0.42, '#59675f', 0, 0.26, 0.22));
    [-1.16, 1.16].forEach(function (x) {
      g.add(this.box(0.18, 0.56, 0.25, '#43574e', x, 0.52, 0.17));
    }, this);

    g.add(this.box(2.78, 1.88, 0.22, '#273b34', 0, 1.55, 0.03));
    g.add(this.box(2.58, 1.68, 0.06, '#010604', 0, 1.55, 0.15, { castShadow: false }));
    g.add(this.box(2.9, 0.12, 0.7, '#334a40', 0, 2.55, 0.13));
    g.add(this.box(2.7, 0.05, 0.06, '#a9d6bb', 0, 2.64, 0.44, { castShadow: false }));

    var sign = this.makeSign('WETTERSTATION', 'MIKROKLIMA · THI', 1.85, 0.78);
    sign.position.set(-0.02, 2.88, 0.16);
    g.add(sign);

    // Physical screen with a live standby canvas.
    this.terminalCanvas = document.createElement('canvas');
    this.terminalCanvas.width = 1000;
    this.terminalCanvas.height = 640;
    this.terminalTexture = new T.CanvasTexture(this.terminalCanvas);
    this.terminalTexture.encoding = T.sRGBEncoding;
    this.terminalTexture.anisotropy = Math.min(this.maxAniso, 8);
    this.drawTerminalStandby();
    var screenMaterial = new T.MeshBasicMaterial({
      map: this.terminalTexture,
      color: 0xffffff,
      toneMapped: false
    });
    var screen = new T.Mesh(new T.PlaneGeometry(this.terminalScreenWidth, this.terminalScreenHeight), screenMaterial);
    screen.position.set(0, 1.55, 0.185);
    screen.castShadow = false;
    screen.receiveShadow = false;
    g.add(screen);
    this.terminalScreen = screen;

    // Instrument mast beside the display.
    g.add(this.cylinder(0.055, 0.075, 3.2, 8, '#61766c', 1.75, 1.6, -0.08, { metalness: 0.22 }));
    g.add(this.box(0.52, 0.8, 0.3, '#d9d6c7', 1.75, 2.38, -0.06));
    g.add(this.box(0.4, 0.55, 0.03, '#3c5955', 1.75, 2.43, 0.11, { castShadow: false }));
    g.add(this.box(0.3, 0.32, 0.02, '#83a998', 1.75, 2.44, 0.13, { emissive: '#7ba694', emissiveIntensity: 0.6, castShadow: false }));

    var cupGroup = new T.Group();
    cupGroup.position.set(1.75, 3.18, -0.08);
    for (var i = 0; i < 3; i += 1) {
      var arm = this.box(0.5, 0.035, 0.035, '#d4c9b3', 0.25, 0, 0, { castShadow: false });
      arm.rotation.y = (i / 3) * Math.PI * 2;
      cupGroup.add(arm);
      var cup = this.cylinder(0.08, 0.13, 0.13, 7, '#eee4d2', 0.48, 0, 0, { castShadow: false });
      cup.rotation.z = Math.PI / 2;
      cup.rotation.y = (i / 3) * Math.PI * 2;
      cup.position.set(Math.cos((i / 3) * Math.PI * 2) * 0.48, 0, Math.sin((i / 3) * Math.PI * 2) * 0.48);
      cupGroup.add(cup);
    }
    g.add(cupGroup);
    this.weatherCups = cupGroup;

    var solar = this.box(0.7, 0.04, 0.4, '#2d4d5d', 1.75, 2.9, -0.25, { rotation: { z: 0.5 }, castShadow: false });
    g.add(solar);

    // Actual HTML lives inside the 3D display via CSS3DRenderer.
    if (this.terminalAvailable && T.CSS3DObject) {
      var template = document.getElementById('terminalTemplate');
      if (template) {
        this.terminalEl = template.content.firstElementChild.cloneNode(true);
        this.terminalEl.id = 'terminalUI';
        var object = new T.CSS3DObject(this.terminalEl);
        object.position.set(0, 1.55, 0.205);
        var s = this.terminalScreenWidth / 400;
        object.scale.set(s, s, s);
        object.visible = false;
        object.renderOrder = 50;
        g.add(object);
        this.terminalObject = object;
      } else {
        this.terminalAvailable = false;
      }
    }

    this.scene.add(g);
    this.weatherStation = g;
    g.updateMatrixWorld(true);
    this.terminalCenter.set(0, 1.55, 0.21).applyMatrix4(g.matrixWorld);
    this.terminalNormal.set(0, 0, 1).transformDirection(g.matrixWorld).normalize();
    this.colliders.rects.push({ minX: 3.95, maxX: 7.65, minZ: 7.55, maxZ: 8.55 });
  };

  World.prototype.drawTerminalStandby = function () {
    if (!this.terminalCanvas) return;
    var ctx = this.terminalCanvas.getContext('2d');
    var w = this.terminalCanvas.width;
    var h = this.terminalCanvas.height;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = '#04130e';
    ctx.fillRect(0, 0, w, h);

    // subtle grid
    ctx.strokeStyle = 'rgba(82, 190, 139, 0.10)';
    ctx.lineWidth = 1;
    for (var x = 0; x < w; x += 50) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (var y = 0; y < h; y += 50) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    ctx.strokeStyle = 'rgba(96, 220, 163, 0.38)';
    ctx.lineWidth = 3;
    ctx.strokeRect(20, 20, w - 40, h - 40);

    ctx.fillStyle = '#7cf0b9';
    ctx.font = '700 26px Consolas, "Courier New", monospace';
    ctx.fillText('FBN // WETTERSTATION', 46, 72);
    ctx.fillStyle = '#4f9f7d';
    ctx.font = '18px Consolas, "Courier New", monospace';
    ctx.fillText('WEIDE-01 · MIKROKLIMA · THI', 46, 101);

    var state = this.measurementState || {};
    var temp = state.tempDone ? '33,2 °C' : '--,- °C';
    var hum = state.humidityDone ? '61 %' : '-- %';
    var thi = (state.tempDone && state.humidityDone) ? '84,5' : '--,-';

    ctx.fillStyle = '#e7fff2';
    ctx.font = '700 78px Consolas, "Courier New", monospace';
    ctx.fillText(temp, 46, 245);
    ctx.fillText(hum, 530, 245);
    ctx.fillStyle = '#5eaa86';
    ctx.font = '18px Consolas, "Courier New", monospace';
    ctx.fillText('LUFTTEMPERATUR', 46, 278);
    ctx.fillText('LUFTFEUCHTE', 530, 278);

    ctx.strokeStyle = 'rgba(100, 215, 160, 0.24)';
    ctx.beginPath();
    ctx.moveTo(46, 318);
    ctx.lineTo(w - 46, 318);
    ctx.stroke();

    ctx.fillStyle = '#7cf0b9';
    ctx.font = '700 22px Consolas, "Courier New", monospace';
    ctx.fillText('THI', 46, 372);
    ctx.fillStyle = '#f4dda0';
    ctx.font = '700 54px Consolas, "Courier New", monospace';
    ctx.fillText(thi, 110, 376);
    ctx.fillStyle = '#67ae8c';
    ctx.font = '18px Consolas, "Courier New", monospace';
    ctx.fillText((state.tempDone && state.humidityDone) ? 'STARKE HITZEBELASTUNG' : 'MESSUNG AUSSTEHEND', 300, 370);

    ctx.fillStyle = '#8fe6bb';
    ctx.font = '700 22px Consolas, "Courier New", monospace';
    ctx.fillText('> KLICKEN / TIPPEN ZUM MESSEN', 46, 470);
    ctx.fillStyle = '#4d8b70';
    ctx.font = '16px Consolas, "Courier New", monospace';
    ctx.fillText('SYSTEM BEREIT · FORSCHUNGSBAUERNHOF', 46, 510);
    ctx.fillText('FBN · NUTZTIERKOSMOS', 46, 540);

    // Faint scanlines.
    ctx.fillStyle = 'rgba(120, 240, 183, 0.045)';
    for (var line = 0; line < h; line += 4) {
      ctx.fillRect(0, line, w, 1);
    }
    this.terminalTexture.needsUpdate = true;
  };

  World.prototype.updateTerminalStandby = function () {
    this.drawTerminalStandby();
  };

  World.prototype.buildBuildSpots = function () {
    // Shade sail, hidden until built.
    var shade = new T.Group();
    shade.position.set(14, 0, 2.5);
    var postMat = new T.MeshStandardMaterial({ color: 0x6c4933, roughness: 0.95 });
    [[-3.5, -2.4], [3.5, -2.4], [-3.5, 2.4], [3.5, 2.4]].forEach(function (p) {
      shade.add(this.cylinder(0.09, 0.12, 3.5, 8, '#6c4933', p[0], 1.75, p[1], { material: postMat }));
    }, this);
    var sailGeo = new T.PlaneGeometry(7.7, 5.5, 6, 4);
    sailGeo.rotateX(-Math.PI / 2);
    var pos = sailGeo.attributes.position;
    for (var i = 0; i < pos.count; i += 1) {
      var x = pos.getX(i);
      var z = pos.getZ(i);
      pos.setY(i, -0.2 * Math.cos((x / 7.7) * Math.PI) * Math.cos((z / 5.5) * Math.PI) - 0.08);
    }
    sailGeo.computeVertexNormals();
    var sailMat = new T.MeshStandardMaterial({
      map: this.makeSailTexture(),
      color: 0xffffff,
      side: T.DoubleSide,
      roughness: 0.96
    });
    var sail = new T.Mesh(sailGeo, sailMat);
    sail.position.y = 3.35;
    sail.castShadow = true;
    sail.receiveShadow = true;
    shade.add(sail);
    shade.add(this.box(0.16, 0.16, 5.2, '#6c4933', 0, 3.42, 0, { castShadow: false }));
    shade.visible = false;
    shade.userData.grow = 0;
    this.scene.add(shade);
    this.shadeGroup = shade;
    this.shadeBuilt = false;

    // New water trough, hidden until built.
    var trough = new T.Group();
    trough.position.set(20, 0, 0.7);
    var metal = new T.MeshStandardMaterial({ color: 0x8c9b93, roughness: 0.55, metalness: 0.35 });
    var outer = this.box(3.3, 0.75, 1.05, '#8c9b93', 0, 0.38, 0, { material: metal });
    trough.add(outer);
    trough.add(this.box(3.1, 0.07, 0.85, '#4c8c9d', 0, 0.79, 0, {
      metalness: 0.25,
      roughness: 0.18,
      transparent: true,
      opacity: 0.9,
      castShadow: false
    }));
    trough.add(this.cylinder(0.09, 0.08, 1.1, 8, '#6d7d76', -1.8, 0.75, 0, { metalness: 0.3 }));
    trough.add(this.box(0.7, 0.08, 0.08, '#6d7d76', -1.45, 1.28, 0, { metalness: 0.3 }));
    trough.visible = false;
    trough.userData.grow = 0;
    this.scene.add(trough);
    this.troughGroup = trough;
    this.troughBuilt = false;

    // Existing trough near the north-east fence.
    var oldTrough = new T.Group();
    oldTrough.position.set(23.5, 0, 5.3);
    oldTrough.add(this.box(2.2, 0.62, 0.82, '#8c9b93', 0, 0.31, 0, {
      material: new T.MeshStandardMaterial({ color: 0x8c9b93, roughness: 0.55, metalness: 0.35 })
    }));
    oldTrough.add(this.box(2.05, 0.06, 0.66, '#4c8c9d', 0, 0.65, 0, {
      roughness: 0.2,
      transparent: true,
      opacity: 0.9,
      castShadow: false
    }));

    this.scene.add(oldTrough);
    this.oldTrough = oldTrough;
    this.colliders.circles.push({ x: 23.5, z: 5.3, r: 1.3 });

    // New trough collision only after it exists — handled dynamically.
  };

  /* ---------------------------------------------------------
     Animals
     --------------------------------------------------------- */

  World.prototype.createCow = function (data) {
    var g = new T.Group();
    var bodyGroup = new T.Group();
    g.add(bodyGroup);

    var coat = this.makeCowTexture(data.patternSeed, data.color, data.pattern);
    var hideMat = new T.MeshStandardMaterial({ map: coat, roughness: 0.92, flatShading: true });
    var baseMat = new T.MeshStandardMaterial({ color: data.color, roughness: 0.92, flatShading: true });
    var darkMat = new T.MeshStandardMaterial({ color: data.pattern, roughness: 0.94, flatShading: true });
    var pinkMat = new T.MeshStandardMaterial({ color: 0xd89a8c, roughness: 0.88, flatShading: true });
    var hoofMat = new T.MeshStandardMaterial({ color: 0x3c3730, roughness: 0.9, flatShading: true });
    var hornMat = new T.MeshStandardMaterial({ color: 0xe3d4b3, roughness: 0.8, flatShading: true });

    // Barrel body.
    var body = new T.Mesh(new T.SphereGeometry(1, 12, 9), hideMat);
    body.scale.set(1.28, 0.71, 0.6);
    body.position.y = 1.08;
    body.castShadow = true;
    body.receiveShadow = true;
    bodyGroup.add(body);

    // Shoulder / rump shaping.
    var shoulder = new T.Mesh(new T.SphereGeometry(1, 10, 8), hideMat);
    shoulder.scale.set(0.55, 0.62, 0.56);
    shoulder.position.set(0.92, 1.12, 0);
    shoulder.castShadow = true;
    bodyGroup.add(shoulder);
    var rump = new T.Mesh(new T.SphereGeometry(1, 10, 8), hideMat);
    rump.scale.set(0.55, 0.62, 0.57);
    rump.position.set(-0.95, 1.1, 0);
    rump.castShadow = true;
    bodyGroup.add(rump);

    // Neck and head.
    var neck = new T.Mesh(new T.CylinderGeometry(0.3, 0.4, 0.85, 8), baseMat);
    neck.rotation.z = -1.08;
    neck.position.set(1.28, 1.34, 0);
    neck.castShadow = true;
    bodyGroup.add(neck);

    var headGroup = new T.Group();
    headGroup.position.set(1.62, 1.55, 0);
    var head = new T.Mesh(new T.SphereGeometry(1, 11, 8), baseMat);
    head.scale.set(0.39, 0.34, 0.3);
    head.castShadow = true;
    headGroup.add(head);
    var muzzle = new T.Mesh(new T.SphereGeometry(1, 9, 6), pinkMat);
    muzzle.scale.set(0.27, 0.2, 0.23);
    muzzle.position.set(0.28, -0.12, 0);
    headGroup.add(muzzle);
    var noseLeft = this.sphere(0.035, '#6c4038', 0.43, -0.1, 0.1, { castShadow: false, segments: 6, rings: 4 });
    var noseRight = this.sphere(0.035, '#6c4038', 0.43, -0.1, -0.1, { castShadow: false, segments: 6, rings: 4 });
    headGroup.add(noseLeft, noseRight);

    var eyeMat = new T.MeshStandardMaterial({ color: 0x1d1d1a, roughness: 0.3 });
    [-1, 1].forEach(function (side) {
      var eye = this.sphere(0.085, '#1d1d1a', 0.17, 0.1, side * 0.235, { material: eyeMat, castShadow: false, segments: 8, rings: 6 });
      eye.scale.set(1, 1.1, 0.6);
      headGroup.add(eye);
      var glint = this.sphere(0.022, '#ffffff', 0.2, 0.13, side * 0.27, { castShadow: false, segments: 5, rings: 4 });
      headGroup.add(glint);
      var ear = this.box(0.27, 0.14, 0.08, data.color, 0.02, 0.12, side * 0.35, {
        material: baseMat,
        rotation: { x: side * 0.25, z: -0.1 }
      });
      headGroup.add(ear);
      var innerEar = this.box(0.18, 0.08, 0.02, '#d09a8e', 0.04, 0.12, side * 0.4, {
        material: pinkMat,
        castShadow: false,
        rotation: { x: side * 0.25, z: -0.1 }
      });
      headGroup.add(innerEar);
      var horn = new T.Mesh(new T.ConeGeometry(0.07, 0.26, 6), hornMat);
      horn.position.set(-0.04, 0.32, side * 0.18);
      horn.rotation.z = side * 0.35;
      horn.castShadow = true;
      headGroup.add(horn);
    }, this);

    // A dark patch around one eye for individual character.
    var patch = this.sphere(0.16, data.pattern, -0.02, 0.11, 0.24, {
      material: darkMat,
      castShadow: false,
      segments: 8,
      rings: 6,
      scale: { x: 1.1, y: 0.9, z: 0.18 }
    });
    headGroup.add(patch);

    // Forelock.
    var tuft = this.sphere(0.15, data.color, 0.02, 0.32, 0, {
      material: baseMat,
      castShadow: false,
      scale: { x: 1.1, y: 0.5, z: 0.9 }
    });
    headGroup.add(tuft);
    bodyGroup.add(headGroup);

    // Legs.
    var legs = [];
    [[0.76, 0.28], [0.76, -0.28], [-0.76, 0.28], [-0.76, -0.28]].forEach(function (p, index) {
      var leg = new T.Group();
      leg.position.set(p[0], 0.8, p[1]);
      var upper = new T.Mesh(new T.CylinderGeometry(0.105, 0.085, 0.62, 6), baseMat);
      upper.position.y = -0.3;
      upper.castShadow = true;
      leg.add(upper);
      var lower = new T.Mesh(new T.CylinderGeometry(0.07, 0.065, 0.25, 6), baseMat);
      lower.position.y = -0.68;
      lower.castShadow = true;
      leg.add(lower);
      var hoof = new T.Mesh(new T.CylinderGeometry(0.09, 0.11, 0.13, 6), hoofMat);
      hoof.position.y = -0.84;
      hoof.castShadow = true;
      leg.add(hoof);
      leg.userData.index = index;
      bodyGroup.add(leg);
      legs.push(leg);
    }, this);

    // Udder.
    var udder = new T.Mesh(new T.SphereGeometry(1, 8, 6), pinkMat);
    udder.scale.set(0.31, 0.22, 0.24);
    udder.position.set(-0.63, 0.48, 0);
    udder.castShadow = true;
    bodyGroup.add(udder);
    for (var t = 0; t < 4; t += 1) {
      var teat = this.cylinder(0.025, 0.032, 0.12, 5, '#c78378', -0.58 + (t % 2) * 0.2, 0.35, (t < 2 ? -0.1 : 0.1), { castShadow: false });
      bodyGroup.add(teat);
    }

    // Tail.
    var tailGroup = new T.Group();
    tailGroup.position.set(-1.27, 1.25, 0);
    var tail = new T.Mesh(new T.CylinderGeometry(0.035, 0.045, 0.85, 5), baseMat);
    tail.position.y = -0.4;
    tail.rotation.z = 0.12;
    tail.castShadow = true;
    tailGroup.add(tail);
    var tailTuft = this.sphere(0.11, data.pattern, 0, -0.83, 0, {
      material: darkMat,
      castShadow: true,
      scale: { x: 0.75, y: 1.2, z: 0.75 }
    });
    tailGroup.add(tailTuft);
    bodyGroup.add(tailGroup);

    // Collar and bell.
    var collarMat = new T.MeshStandardMaterial({ color: 0x4d3b2c, roughness: 0.8 });
    var collar = new T.Mesh(new T.TorusGeometry(0.38, 0.035, 5, 14), collarMat);
    collar.position.set(1.43, 1.25, 0);
    collar.rotation.y = Math.PI / 2;
    collar.scale.set(1, 0.86, 1);
    bodyGroup.add(collar);
    var bell = this.sphere(0.11, '#d7a23d', 1.49, 0.98, 0, {
      material: new T.MeshStandardMaterial({ color: 0xd7a23d, roughness: 0.4, metalness: 0.5 }),
      castShadow: false,
      segments: 8,
      rings: 6
    });
    bodyGroup.add(bell);

    // Grounding shadow (softens contact in addition to shadow maps).
    var shadow = new T.Mesh(
      new T.CircleGeometry(1.25, 18),
      new T.MeshBasicMaterial({ color: 0x243c29, transparent: true, opacity: 0.12, depthWrite: false })
    );
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.y = 0.012;
    shadow.scale.set(1.2, 0.6, 1);
    g.add(shadow);

    g.scale.setScalar(data.bodyScale || 1);
    g.position.set(data.start.x, 0, data.start.z);
    this.scene.add(g);

    var statusTexture = this.getStatusTexture();
    var statusSprite = new T.Sprite(new T.SpriteMaterial({
      map: statusTexture,
      transparent: true,
      depthTest: false,
      depthWrite: false,
      opacity: 0
    }));
    statusSprite.scale.set(1.0, 0.5, 1);
    statusSprite.position.set(0, 3.05, 0);
    statusSprite.renderOrder = 20;
    g.add(statusSprite);

    return {
      data: data,
      group: g,
      bodyGroup: bodyGroup,
      body: body,
      headGroup: headGroup,
      legs: legs,
      tailGroup: tailGroup,
      statusSprite: statusSprite,
      stress: 0.85,
      pantPhase: rand(0, 10),
      mode: 'idle',
      target: new T.Vector3(data.start.x, 0, data.start.z),
      heading: rand(0, Math.PI * 2),
      walkPhase: rand(0, 10),
      moveSpeed: 0.48,
      timer: rand(2, 5),
      moving: false,
      puffTimer: rand(1, 3),
      grazePose: 0,
      home: new T.Vector3(data.start.x, 0, data.start.z)
    };
  };

  World.prototype.createCows = function () {
    D.cows.forEach(function (cow) {
      var entry = this.createCow(cow);
      entry.group.rotation.y = entry.heading;
      this.cows.push(entry);
    }, this);

    // Let the herd settle naturally.
    this.cows[0].mode = 'shade';
    this.cows[0].target.set(9.4, 0, -7.0);
    this.cows[1].mode = 'idle';
    this.cows[2].mode = 'drink';
    this.cows[2].target.set(22.5, 0, 5.4);
    this.cows[3].mode = 'graze';
    this.cows[3].target.set(13.2, 0, -2.2);
  };

  World.prototype.getStatusTexture = function () {
    if (this._statusTexture) return this._statusTexture;
    var self = this;
    var texture = this.makeTexture(256, 128, function (ctx, w, h) {
      ctx.clearRect(0, 0, w, h);
      ctx.shadowColor = 'rgba(30, 18, 10, 0.28)';
      ctx.shadowBlur = 10;
      ctx.fillStyle = '#c25f3b';
      var x = 32;
      var y = 20;
      var rw = 192;
      var rh = 64;
      var r = 30;
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.arcTo(x + rw, y, x + rw, y + rh, r);
      ctx.arcTo(x + rw, y + rh, x, y + rh, r);
      ctx.arcTo(x, y + rh, x, y, r);
      ctx.arcTo(x, y, x + rw, y, r);
      ctx.closePath();
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#fff7e7';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = '800 32px "Trebuchet MS", sans-serif';
      ctx.fillText('HITZE?', 128, 53);
      ctx.strokeStyle = 'rgba(255,247,231,0.8)';
      ctx.lineWidth = 4;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(95, 83);
      ctx.bezierCurveTo(84, 92, 107, 99, 96, 109);
      ctx.moveTo(128, 83);
      ctx.bezierCurveTo(117, 92, 140, 99, 129, 109);
      ctx.moveTo(161, 83);
      ctx.bezierCurveTo(150, 92, 173, 99, 162, 109);
      ctx.stroke();
    });
    this._statusTexture = texture;
    return texture;
  };

  World.prototype.createPlayer = function () {
    var g = new T.Group();
    var model = new T.Group();
    g.add(model);

    var skin = new T.MeshStandardMaterial({ color: 0xd9a77e, roughness: 0.9 });
    var shirt = new T.MeshStandardMaterial({ color: 0xe6dfcc, roughness: 0.92 });
    var overalls = new T.MeshStandardMaterial({ color: 0x3e6b59, roughness: 0.94 });
    var legOveralls = overalls.clone();
    var bibOveralls = overalls.clone();
    var pocketMat = overalls.clone();
    var boots = new T.MeshStandardMaterial({ color: 0x574335, roughness: 0.95 });
    var hatMat = new T.MeshStandardMaterial({ color: 0xd9b86d, roughness: 0.95 });
    var brimMat = hatMat.clone();
    var crownMat = hatMat.clone();
    var hairMat = new T.MeshStandardMaterial({ color: 0x5b3e2a, roughness: 0.95 });
    var ponytailMat = hairMat.clone();
    var headSkin = skin.clone();
    var neckSkin = skin.clone();

    var legs = [];
    [-0.14, 0.14].forEach(function (x) {
      var leg = new T.Group();
      leg.position.set(x, 0.62, 0);
      var pant = this.box(0.2, 0.5, 0.24, '#3e6b59', 0, -0.22, 0, { material: legOveralls });
      pant.name = x < 0 ? 'player-left-pant' : 'player-right-pant';
      leg.add(pant);
      var boot = this.box(0.23, 0.2, 0.33, '#574335', 0.02, -0.52, 0.05, { material: boots });
      leg.add(boot);
      model.add(leg);
      legs.push(leg);
    }, this);

    var torso = this.box(0.54, 0.68, 0.32, '#e6dfcc', 0, 0.98, 0, { material: shirt });
    torso.name = 'player-torso';
    model.add(torso);
    // The bib sits in front of the shirt, with its rear face safely inside
    // the torso. This removes the coplanar back faces at the character's hip.
    var bib = this.box(0.36, 0.5, 0.3, '#3e6b59', 0, 0.86, 0.055, { material: bibOveralls });
    bib.name = 'player-bib';
    model.add(bib);
    var pocket = this.box(0.2, 0.14, 0.02, '#315a4a', 0, 0.8, 0.23, { material: pocketMat, castShadow: false });
    pocket.name = 'player-pocket';
    model.add(pocket);

    var arms = [];
    [-0.37, 0.37].forEach(function (x) {
      var arm = new T.Group();
      arm.position.set(x, 1.2, 0);
      var sleeve = this.box(0.16, 0.5, 0.18, '#e6dfcc', 0, -0.2, 0, { material: shirt });
      arm.add(sleeve);
      var hand = this.sphere(0.09, '#d9a77e', 0, -0.49, 0, { material: skin, castShadow: true, segments: 7, rings: 5 });
      arm.add(hand);
      arm.rotation.z = x > 0 ? -0.08 : 0.08;
      model.add(arm);
      arms.push(arm);
    }, this);

    var neck = this.cylinder(0.1, 0.11, 0.12, 8, '#d9a77e', 0, 1.4, 0, { material: neckSkin });
    model.add(neck);
    var head = this.sphere(0.25, '#d9a77e', 0, 1.68, 0.01, { material: headSkin, segments: 10, rings: 8 });
    head.scale.set(0.94, 1.05, 0.94);
    model.add(head);

    var hair = this.sphere(0.255, '#5b3e2a', 0, 1.73, -0.03, {
      material: hairMat,
      segments: 9,
      rings: 7,
      castShadow: false,
      scale: { x: 0.98, y: 0.62, z: 0.98 }
    });
    model.add(hair);
    var ponytail = this.cylinder(0.06, 0.1, 0.35, 6, '#5b3e2a', 0, 1.65, -0.24, {
      material: ponytailMat,
      rotation: { x: 0.35 },
      castShadow: false
    });
    model.add(ponytail);

    [-1, 1].forEach(function (side) {
      var eye = this.sphere(0.027, '#1e2b26', side * 0.09, 1.71, 0.22, { castShadow: false, segments: 6, rings: 4 });
      model.add(eye);
    }, this);

    var brim = this.cylinder(0.36, 0.38, 0.06, 16, '#d9b86d', 0, 1.89, 0.01, { material: brimMat });
    model.add(brim);
    var crown = this.cylinder(0.22, 0.27, 0.24, 12, '#d9b86d', 0, 2.0, 0, { material: crownMat });
    model.add(crown);
    var band = this.cylinder(0.272, 0.272, 0.06, 12, '#3e6b59', 0, 1.94, 0, {
      material: new T.MeshStandardMaterial({ color: 0x3e6b59, roughness: 0.9 }),
      castShadow: false
    });
    model.add(band);

    var satchel = this.box(0.3, 0.35, 0.16, '#8d6146', -0.34, 0.86, -0.25, {
      rotation: { z: 0.12 },
      castShadow: true
    });
    satchel.name = 'player-satchel';
    model.add(satchel);
    var strap = this.box(0.06, 0.9, 0.02, '#6b4734', -0.02, 1.05, 0.18, {
      rotation: { z: -0.6 },
      castShadow: false
    });
    model.add(strap);

    // Tool in hand — a small naturalist's notebook.
    var notebook = this.box(0.2, 0.26, 0.05, '#e9d9ba', 0.41, 0.67, 0.1, {
      rotation: { z: 0.08 },
      castShadow: false
    });
    model.add(notebook);
    model.add(this.box(0.21, 0.04, 0.045, '#b65e43', 0.41, 0.79, 0.1, { castShadow: false }));

    g.position.set(4.8, 0, 22.8);
    g.rotation.y = Math.PI;
    this.scene.add(g);
    this.player = g;
    this.playerModel = model;
    // The figure still casts its shadow on the ground but receives none itself:
    // shadows crawling over the small face and shoulders flickered while walking.
    g.traverse(function (o) { if (o.isMesh) o.receiveShadow = false; });
    this.playerLegs = legs;
    this.playerArms = arms;
    this.playerHair = ponytail;
    this.playerNotebook = notebook;
  };

  World.prototype.createSimplePig = function (x, z, radius, color, size) {
    var g = new T.Group();
    var skin = new T.MeshStandardMaterial({ color: color, roughness: 0.9, flatShading: true });
    var dark = new T.MeshStandardMaterial({ color: 0x9b6a5f, roughness: 0.9, flatShading: true });
    var body = this.sphere(0.65, color, 0, 0.58, 0, { material: skin, scale: { x: 1.35, y: 0.85, z: 0.8 }, segments: 9, rings: 7 });
    body.castShadow = true;
    g.add(body);
    var head = this.sphere(0.43, color, 0.78, 0.58, 0, { material: skin, segments: 8, rings: 6 });
    head.castShadow = true;
    g.add(head);
    var snout = this.cylinder(0.2, 0.24, 0.22, 8, '#c88e83', 1.12, 0.48, 0, {
      material: new T.MeshStandardMaterial({ color: 0xcf9587, roughness: 0.85 }),
      rotation: { z: Math.PI / 2 }
    });
    g.add(snout);
    [-0.12, 0.12].forEach(function (z2) {
      g.add(this.sphere(0.045, '#7b4f47', 1.23, 0.49, z2, { castShadow: false, segments: 5, rings: 4 }));
    }, this);
    [-1, 1].forEach(function (side) {
      var ear = this.box(0.2, 0.23, 0.06, color, 0.68, 0.94, side * 0.24, {
        material: skin,
        rotation: { x: side * 0.45, z: -0.25 },
        castShadow: true
      });
      g.add(ear);
      g.add(this.sphere(0.042, '#2f2824', 0.97, 0.69, side * 0.2, { castShadow: false, segments: 5, rings: 4 }));
    }, this);
    [[0.42, 0.22], [0.42, -0.22], [-0.42, 0.22], [-0.42, -0.22]].forEach(function (p) {
      var leg = this.cylinder(0.09, 0.1, 0.38, 6, color, p[0], 0.18, p[1], { material: skin });
      g.add(leg);
    }, this);
    var tail = new T.Group();
    tail.position.set(-0.86, 0.68, 0);
    var curl = new T.Mesh(new T.TorusGeometry(0.13, 0.025, 4, 10, Math.PI * 1.6), dark);
    curl.rotation.y = Math.PI / 2;
    tail.add(curl);
    g.add(tail);
    g.position.set(x, 0, z);
    g.scale.setScalar(size);
    g.rotation.y = rand(0, Math.PI * 2);
    this.scene.add(g);
    this.pigs.push({
      group: g,
      center: new T.Vector3(x, 0, z),
      radius: radius,
      timer: rand(0, 4),
      target: new T.Vector3(x, 0, z),
      phase: rand(0, 10),
      speed: rand(0.16, 0.24)
    });
  };

  World.prototype.createSimpleChicken = function (x, z, radius, color, size) {
    var g = new T.Group();
    var body = this.sphere(0.24, color, 0, 0.3, 0, {
      material: new T.MeshStandardMaterial({ color: color, roughness: 0.95, flatShading: true }),
      scale: { x: 0.95, y: 0.88, z: 0.8 },
      segments: 8,
      rings: 6
    });
    g.add(body);
    var head = this.sphere(0.15, color, 0, 0.55, 0.12, { castShadow: true, segments: 7, rings: 5 });
    g.add(head);
    var beak = this.cylinder(0.02, 0.07, 0.14, 5, '#d3a34f', 0, 0.52, 0.28, {
      rotation: { x: Math.PI / 2 },
      castShadow: false
    });
    g.add(beak);
    var comb = this.box(0.05, 0.12, 0.09, '#c6553f', 0, 0.69, 0.1, { castShadow: false });
    g.add(comb);
    g.add(this.sphere(0.02, '#24201d', -0.08, 0.58, 0.22, { castShadow: false, segments: 5, rings: 4 }));
    g.add(this.sphere(0.02, '#24201d', 0.08, 0.58, 0.22, { castShadow: false, segments: 5, rings: 4 }));
    [-1, 1].forEach(function (s) {
      var wing = this.sphere(0.12, color, 0, 0.31, s * 0.18, {
        scale: { x: 1.2, y: 0.55, z: 0.35 },
        castShadow: false,
        segments: 6,
        rings: 4
      });
      g.add(wing);
      var leg = this.cylinder(0.016, 0.02, 0.18, 4, '#d3a34f', s * 0.08, 0.11, 0, { castShadow: false });
      g.add(leg);
    }, this);
    var tail = this.sphere(0.13, color, -0.2, 0.38, 0, {
      scale: { x: 1.4, y: 0.8, z: 0.5 },
      rotation: { z: -0.5 },
      castShadow: false,
      segments: 6,
      rings: 4
    });
    g.add(tail);
    g.position.set(x, 0, z);
    g.scale.setScalar(size);
    g.rotation.y = rand(0, Math.PI * 2);
    this.scene.add(g);
    this.chickens.push({
      group: g,
      center: new T.Vector3(x, 0, z),
      radius: radius,
      timer: rand(0, 2),
      target: new T.Vector3(x, 0, z),
      phase: rand(0, 10),
      peck: 0
    });
  };

  World.prototype.createAmbientLife = function () {
    this.createSimplePig(-23.2, -3.2, 3.0, 0xd8a28f, 1.0);
    this.createSimplePig(-21.1, -1.0, 2.6, 0x8f7a6c, 0.88);
    this.createSimplePig(-25.1, -1.7, 2.4, 0xd9b29d, 0.82);

    this.createSimpleChicken(-12.4, 2.2, 3.0, 0xe8dfcc, 0.95);
    this.createSimpleChicken(-14.0, 3.8, 2.6, 0xb98056, 0.88);
    this.createSimpleChicken(-11.2, 4.2, 2.4, 0x5e5145, 0.84);
    this.createSimpleChicken(-15.1, 1.0, 2.5, 0xd7c7a5, 0.9);
    this.createSimpleChicken(-10.4, 0.4, 2.2, 0xe3d3b7, 0.78);

    // Butterflies around the pasture.
    var wingColors = [0xf4d580, 0xe6a68d, 0xf1eee0, 0xe4bd6a, 0xefd9a0];
    for (var i = 0; i < 5; i += 1) {
      var g = new T.Group();
      var wingMat = new T.MeshBasicMaterial({ color: wingColors[i], side: T.DoubleSide, transparent: true, opacity: 0.86 });
      // Wings lie flat and hinge at the body, so they beat up and down.
      var leftGeo = new T.PlaneGeometry(0.26, 0.22);
      leftGeo.rotateX(-Math.PI / 2);
      leftGeo.translate(-0.13, 0, 0);
      var rightGeo = new T.PlaneGeometry(0.26, 0.22);
      rightGeo.rotateX(-Math.PI / 2);
      rightGeo.translate(0.13, 0, 0);
      var left = new T.Mesh(leftGeo, wingMat);
      var right = new T.Mesh(rightGeo, wingMat);
      var body = new T.Mesh(new T.BoxGeometry(0.035, 0.035, 0.2), new T.MeshBasicMaterial({ color: 0x4a3a2c }));
      g.add(left, right, body);
      g.position.set(rand(7, 26), rand(0.7, 1.7), rand(-9, 8));
      this.scene.add(g);
      this.butterflies.push({
        group: g,
        left: left,
        right: right,
        center: new T.Vector3(rand(8, 25), 0.9, rand(-8, 8)),
        radius: rand(1.2, 3.8),
        speed: rand(0.25, 0.6),
        phase: rand(0, 10)
      });
    }
  };

  /* ---------------------------------------------------------
     Markers, particles
     --------------------------------------------------------- */

  World.prototype.drawMarkerIcon = function (ctx, type) {
    ctx.strokeStyle = '#1f4b3b';
    ctx.fillStyle = '#1f4b3b';
    ctx.lineWidth = 7;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    if (type === 'eye') {
      ctx.ellipse(0, 0, 33, 18, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, 0, 8, 0, Math.PI * 2);
      ctx.fill();
    } else if (type === 'thermometer') {
      ctx.moveTo(-8, -30);
      ctx.lineTo(-8, 12);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(-8, 22, 13, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(6, -30);
      ctx.lineTo(6, 8);
      ctx.stroke();
    } else if (type === 'droplet') {
      ctx.moveTo(0, -36);
      ctx.bezierCurveTo(-28, -2, -22, 30, 0, 34);
      ctx.bezierCurveTo(22, 30, 28, -2, 0, -36);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(-6, 17, 8, 0.3, 2.2);
      ctx.stroke();
    } else if (type === 'shade') {
      ctx.moveTo(-38, 2);
      ctx.quadraticCurveTo(-24, -34, 0, -34);
      ctx.quadraticCurveTo(24, -34, 38, 2);
      ctx.closePath();
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, -32);
      ctx.lineTo(0, 32);
      ctx.moveTo(-20, 33);
      ctx.quadraticCurveTo(0, 20, 20, 33);
      ctx.stroke();
    } else if (type === 'wind') {
      ctx.moveTo(-36, -18);
      ctx.lineTo(10, -18);
      ctx.quadraticCurveTo(28, -18, 24, -2);
      ctx.quadraticCurveTo(19, 10, 2, 5);
      ctx.moveTo(-36, 4);
      ctx.lineTo(23, 4);
      ctx.moveTo(-36, 24);
      ctx.lineTo(2, 24);
      ctx.quadraticCurveTo(18, 24, 14, 35);
      ctx.stroke();
    } else if (type === 'spark') {
      ctx.moveTo(0, -36);
      ctx.bezierCurveTo(2, -12, 12, -2, 36, 0);
      ctx.bezierCurveTo(12, 2, 2, 12, 0, 36);
      ctx.bezierCurveTo(-2, 12, -12, 2, -36, 0);
      ctx.bezierCurveTo(-12, -2, -2, -12, 0, -36);
      ctx.stroke();
    } else if (type === 'book') {
      ctx.rect(-34, -25, 29, 50);
      ctx.stroke();
      ctx.beginPath();
      ctx.rect(5, -25, 29, 50);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(-5, -28);
      ctx.lineTo(-5, 28);
      ctx.stroke();
    } else {
      ctx.arc(0, 0, 32, 0, Math.PI * 2);
      ctx.stroke();
    }
  };

  World.prototype.getMarkerTexture = function (label, icon) {
    var key = label + '|' + icon;
    if (!this._markerCache) this._markerCache = {};
    if (this._markerCache[key]) return this._markerCache[key];
    var self = this;
    var texture = this.makeTexture(512, 256, function (ctx, w, h) {
      ctx.clearRect(0, 0, w, h);
      // Badge
      ctx.save();
      ctx.shadowColor = 'rgba(7, 28, 21, 0.28)';
      ctx.shadowBlur = 16;
      ctx.shadowOffsetY = 5;
      ctx.fillStyle = '#fff8e8';
      ctx.beginPath();
      ctx.arc(256, 84, 60, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      ctx.strokeStyle = '#20513f';
      ctx.lineWidth = 7;
      ctx.beginPath();
      ctx.arc(256, 84, 60, 0, Math.PI * 2);
      ctx.stroke();
      ctx.save();
      ctx.translate(256, 84);
      self.drawMarkerIcon(ctx, icon);
      ctx.restore();

      // Label
      ctx.font = '800 30px "Trebuchet MS", "Segoe UI", sans-serif';
      var textWidth = ctx.measureText(label).width;
      var boxW = Math.max(190, textWidth + 52);
      var x = 256 - boxW / 2;
      var y = 158;
      ctx.save();
      ctx.shadowColor = 'rgba(7, 28, 21, 0.25)';
      ctx.shadowBlur = 12;
      ctx.shadowOffsetY = 4;
      ctx.fillStyle = 'rgba(20, 62, 49, 0.94)';
      var r = 24;
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.arcTo(x + boxW, y, x + boxW, y + 52, r);
      ctx.arcTo(x + boxW, y + 52, x, y + 52, r);
      ctx.arcTo(x, y + 52, x, y, r);
      ctx.arcTo(x, y, x + boxW, y, r);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
      ctx.fillStyle = '#fff7e5';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(label, 256, y + 27);
    }, 0, 0);
    this._markerCache[key] = texture;
    return texture;
  };

  World.prototype.addMarker = function (id, label, icon, x, y, z, radius) {
    var group = new T.Group();
    group.position.set(x, 0, z);
    var sprite = new T.Sprite(new T.SpriteMaterial({
      map: this.getMarkerTexture(label, icon),
      transparent: true,
      depthTest: false,
      depthWrite: false
    }));
    sprite.scale.set(2.9 * this.markerScale, 1.45 * this.markerScale, 1);
    sprite.position.y = y;
    sprite.renderOrder = 30;
    group.add(sprite);

    var ring = new T.Mesh(
      new T.RingGeometry(0.62, 0.78, 32),
      new T.MeshBasicMaterial({
        color: 0xf0c46a,
        transparent: true,
        opacity: 0.8,
        side: T.DoubleSide,
        depthWrite: false
      })
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.016;
    ring.renderOrder = 12;
    group.add(ring);

    group.visible = false;
    this.scene.add(group);
    var marker = {
      id: id,
      group: group,
      sprite: sprite,
      ring: ring,
      baseY: y,
      radius: radius || 3.2,
      active: false,
      x: x,
      z: z,
      icon: icon,
      label: label,
      bob: rand(0, 10)
    };
    this.markers[id] = marker;
    this.markerList.push(marker);
    return marker;
  };

  World.prototype.setMarkerAppearance = function (marker, label, icon) {
    if (marker.label === label && marker.icon === icon) return;
    marker.label = label;
    marker.icon = icon;
    marker.sprite.material.map = this.getMarkerTexture(label, icon);
    marker.sprite.material.needsUpdate = true;
  };

  World.prototype.createMarkers = function () {
    this.cows.forEach(function (cow) {
      var marker = this.addMarker('cow:' + cow.data.id, 'Beobachten', 'eye', cow.group.position.x, 4.15, cow.group.position.z, 3.0);
      marker.cow = cow;
      cow.marker = marker;
    }, this);

    this.weatherMarker = this.addMarker('weather', 'Bedienen', 'thermometer', 5.8, 3.8, 8.1, 3.2);
    this.shadeMarker = this.addMarker('build:shade', 'Schatten bauen', 'shade', 14, 2.65, 2.5, 3.3);
    this.troughMarker = this.addMarker('build:water', 'Tränke bauen', 'droplet', 20, 2.35, 0.7, 3.1);
    this.ventMarker = this.addMarker('build:ventilation', 'Lüftung starten', 'wind', 15.05, 2.25, -13.3, 3.0);
    this.analysisMarker = this.addMarker('analysis', 'Auswerten', 'spark', -3.5, 2.6, 19.2, 3.4);
  };

  World.prototype.createParticles = function () {
    var puffTexture = this.makeTexture(128, 128, function (ctx, w, h) {
      var grad = ctx.createRadialGradient(64, 64, 2, 64, 64, 60);
      grad.addColorStop(0, 'rgba(255,255,255,0.9)');
      grad.addColorStop(0.55, 'rgba(255,252,245,0.4)');
      grad.addColorStop(1, 'rgba(255,252,245,0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);
    });
    this.puffTexture = puffTexture;
    for (var i = 0; i < 30; i += 1) {
      var mat = new T.SpriteMaterial({ map: puffTexture, transparent: true, opacity: 0, depthWrite: false });
      var sprite = new T.Sprite(mat);
      sprite.scale.set(0.45, 0.45, 1);
      sprite.visible = false;
      this.scene.add(sprite);
      this.puffs.push({ sprite: sprite, life: 0, maxLife: 1, velocity: new T.Vector3() });
    }

    var dustTexture = this.makeTexture(64, 64, function (ctx, w, h) {
      var grad = ctx.createRadialGradient(32, 32, 1, 32, 32, 30);
      grad.addColorStop(0, 'rgba(210,185,139,0.8)');
      grad.addColorStop(1, 'rgba(210,185,139,0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);
    });
    for (var d = 0; d < 18; d += 1) {
      var dmat = new T.SpriteMaterial({ map: dustTexture, transparent: true, opacity: 0, depthWrite: false });
      var dsprite = new T.Sprite(dmat);
      dsprite.scale.set(0.35, 0.25, 1);
      dsprite.visible = false;
      this.scene.add(dsprite);
      this.dust.push({ sprite: dsprite, life: 0, maxLife: 0.7 });
    }

    // Thin air streaks for the fans.
    var streakMat = new T.MeshBasicMaterial({ color: 0xe6f4ec, transparent: true, opacity: 0.22, depthWrite: false });
    for (var s = 0; s < 14; s += 1) {
      var streak = new T.Mesh(new T.BoxGeometry(rand(0.8, 2.0), 0.012, 0.012), streakMat);
      streak.position.set(rand(9, 21), rand(0.6, 3.4), rand(-21, -14.2));
      streak.visible = false;
      this.scene.add(streak);
      this.ventStreaks.push({ mesh: streak, speed: rand(0.9, 2.2), phase: rand(0, 10) });
    }

    // Water rings. The new trough's ripples stay hidden until it is built.
    [[23.5, 0.69, 5.3, 0.55], [20, 0.83, 0.7, 0.8]].forEach(function (p) {
      for (var r = 0; r < 3; r += 1) {
        var ring = new T.Mesh(
          new T.RingGeometry(0.2, 0.24, 24),
          new T.MeshBasicMaterial({ color: 0xc8edf0, transparent: true, opacity: 0.42, side: T.DoubleSide, depthWrite: false })
        );
        ring.rotation.x = -Math.PI / 2;
        ring.position.set(p[0], p[1], p[2]);
        ring.scale.setScalar(p[3] + r * 0.34);
        ring.userData.phase = r / 3;
        ring.userData.center = new T.Vector3(p[0], p[1], p[2]);
        ring.userData.base = p[3];
        ring.userData.needsTrough = p[0] === 20;
        ring.visible = !ring.userData.needsTrough;
        this.scene.add(ring);
        this.ripples.push(ring);
      }
    }, this);
  };

  /* ---------------------------------------------------------
     Depth micro-jitter (anti z-fighting)
     Every non-sprite material gets a tiny, permanent polygon offset.
     This shifts only depth (not visible geometry), so coplanar
     surfaces (paths, decals, seams) separate cleanly at any camera
     distance without moving objects around.
     --------------------------------------------------------- */

  World.prototype.nextMaterialJitter = function () {
    this._materialJitterSeed = (this._materialJitterSeed * 1664525 + 1013904223) >>> 0;
    return this._materialJitterSeed / 4294967296;
  };

  World.prototype.applyMaterialMicroOffset = function (material) {
    if (!material) return;
    if (Array.isArray(material)) {
      for (var i = 0; i < material.length; i += 1) this.applyMaterialMicroOffset(material[i]);
      return;
    }
    if (material.isSpriteMaterial || material.isShaderMaterial || material.isRawShaderMaterial) return;
    if (material.userData && material.userData.__microDepthOffset) return;

    if (!material.userData) material.userData = {};
    material.userData.__microDepthOffset = true;

    var baseFactor = material.polygonOffset ? (material.polygonOffsetFactor || 0) : 0;
    var baseUnits = material.polygonOffset ? (material.polygonOffsetUnits || 0) : 0;
    var factorJitter = 0.004 + this.nextMaterialJitter() * 0.018;
    var unitJitter = 0.04 + this.nextMaterialJitter() * 0.30;

    material.polygonOffset = true;
    material.polygonOffsetFactor = baseFactor - factorJitter;
    material.polygonOffsetUnits = baseUnits - unitJitter;
    material.needsUpdate = true;
  };

  World.prototype.applyMaterialMicroOffsets = function () {
    var seen = typeof Set !== 'undefined' ? new Set() : null;
    var self = this;
    this.scene.traverse(function (object) {
      if (!object.material) return;
      var materials = Array.isArray(object.material) ? object.material : [object.material];
      for (var i = 0; i < materials.length; i += 1) {
        var material = materials[i];
        if (!material) continue;
        if (seen) {
          if (seen.has(material)) continue;
          seen.add(material);
        }
        self.applyMaterialMicroOffset(material);
      }
    });
  };

  /* ---------------------------------------------------------
     Interaction, state, input
     --------------------------------------------------------- */

  World.prototype.sync = function (state) {
    this.missionState = state;
    this.measurementState = state;
    var phase = state.phase;
    var measures = state.measures || {};
    this.measures = measures;
    this.updateTerminalStandby();

    // Cows
    this.cows.forEach(function (cow) {
      var show = false;
      var label = 'Beobachten';
      if (phase === 'observe' && !state.observed[cow.data.id]) {
        show = true;
      } else if (phase === 'followup' && state.observed[cow.data.id] && !state.followup[cow.data.id]) {
        show = true;
        label = 'Vergleichen';
      }
      this.setMarkerAppearance(cow.marker, label, 'eye');
      cow.marker.active = show;
      cow.marker.group.visible = show;
    }, this);

    this.weatherMarker.active = phase === 'measure' && !(state.tempDone && state.humidityDone);
    this.weatherMarker.group.visible = this.weatherMarker.active;

    this.shadeMarker.active = phase === 'act' && !measures.shade;
    this.shadeMarker.group.visible = this.shadeMarker.active;
    this.troughMarker.active = phase === 'act' && !measures.water;
    this.troughMarker.group.visible = this.troughMarker.active;
    this.ventMarker.active = phase === 'act' && !measures.ventilation;
    this.ventMarker.group.visible = this.ventMarker.active;

    this.analysisMarker.active = phase === 'evaluate';
    this.analysisMarker.group.visible = this.analysisMarker.active;

    // Reveal/raise built objects as soon as the game records a measure.
    var newlyBuilt = false;
    if (measures.shade && !this.shadeBuilt) {
      this.shadeBuilt = true;
      this.shadeGroup.visible = true;
      this.shadeGroup.scale.set(0.75, 0.04, 0.75);
      this.shadeGroup.userData.grow = 0.01;
      this.spawnBuildBurst(14, 0.2, 2.5);
      newlyBuilt = true;
    }
    if (measures.water && !this.troughBuilt) {
      this.troughBuilt = true;
      this.troughGroup.visible = true;
      this.troughGroup.scale.set(0.6, 0.05, 0.6);
      this.troughGroup.userData.grow = 0.01;
      this.spawnBuildBurst(20, 0.2, 0.7);
      this.colliders.circles.push({ x: 20, z: 0.7, r: 1.7 });
      this.ripples.forEach(function (ring) {
        if (ring.userData.needsTrough) ring.visible = true;
      });
      newlyBuilt = true;
    }
    if (measures.ventilation && !this.ventilationOn) {
      this.ventilationOn = true;
      this.fanSwitchLamp.material.color.setHex(0x7fd39f);
      this.fanSwitchLamp.material.emissive = new T.Color(0x7fd39f);
      this.fanSwitchLamp.material.emissiveIntensity = 0.8;
      this.spawnBuildBurst(15.05, 0.3, -13.0);
      newlyBuilt = true;
    }
    if (!measures.ventilation && this.ventilationOn) {
      this.ventilationOn = false;
      this.fanSwitchLamp.material.color.setHex(0xb76b4f);
      this.fanSwitchLamp.material.emissive = new T.Color(0x000000);
    }
    if (newlyBuilt) this.refreshCowBehaviour(true);
  };

  World.prototype.refreshCowBehaviour = function (urgent) {
    this.cows.forEach(function (cow) {
      cow.timer = Math.min(cow.timer, urgent ? rand(0.3, 1.5) : rand(1, 4));
    }, this);
  };

  World.prototype.spawnBuildBurst = function (x, y, z) {
    for (var i = 0; i < 3; i += 1) {
      var burstMaterial = new T.MeshBasicMaterial({ color: 0xeac472, transparent: true, opacity: 0.75, side: T.DoubleSide, depthWrite: false });
      this.applyMaterialMicroOffset(burstMaterial);
      var ring = new T.Mesh(new T.RingGeometry(0.5, 0.62, 28), burstMaterial);
      ring.rotation.x = -Math.PI / 2;
      ring.position.set(x, y + i * 0.06, z);
      this.scene.add(ring);
      this.buildBursts.push({ mesh: ring, life: 0, maxLife: 1.4 + i * 0.12 });
    }
  };

  World.prototype.getNearestInteraction = function () {
    var nearest = null;
    var nearestDist = Infinity;
    for (var i = 0; i < this.markerList.length; i += 1) {
      var marker = this.markerList[i];
      if (!marker.active) continue;
      var px = marker.x;
      var pz = marker.z;
      if (marker.cow) {
        px = marker.cow.group.position.x;
        pz = marker.cow.group.position.z;
      }
      var dx = this.player.position.x - px;
      var dz = this.player.position.z - pz;
      var dist = Math.sqrt(dx * dx + dz * dz);
      if (dist < marker.radius && dist < nearestDist) {
        nearestDist = dist;
        nearest = { id: marker.id, marker: marker, distance: dist, label: marker.label };
      }
    }
    return nearest;
  };

  World.prototype.getLocation = function () {
    var p = this.player.position;
    if (p.z < -13.2 && p.x > 7 && p.x < 23) return 'Offener Laufstall';
    if (p.x > 4 && p.x < 30 && p.z > -13.5 && p.z < 10.5) return 'Kuhweide';
    if (p.x > -8.6 && p.x < 1.6 && p.z > 10.5 && p.z < 18) return 'Forschungsstation';
    if (p.x > -28.4 && p.x < -16.6 && p.z > -8.4 && p.z < 3.4) return 'Schweinegehege';
    if (p.x > -17.4 && p.x < -8.6 && p.z > -1.4 && p.z < 6.4) return 'Hühnerhof';
    if (p.x > -28.5 && p.x < -13.5 && p.z > 8.5 && p.z < 21) return 'Futtergarten';
    if (p.z > 17.5) return 'Hofweg';
    return 'Forschungshof';
  };

  World.prototype.setMoveInput = function (x, z) {
    this.moveInput.x = x;
    this.moveInput.z = z;
  };

  World.prototype.setSprint = function (sprint) {
    this.sprint = !!sprint;
  };

  World.prototype.setUiBlocked = function (blocked) {
    this.uiBlocked = !!blocked;
    if (blocked) {
      this.moveInput.x = 0;
      this.moveInput.z = 0;
      if (this.pointer.dragging) {
        this.pointer.dragging = false;
        this.pointer.id = null;
        this.renderer.domElement.classList.remove('is-dragging');
      }
    }
  };

  World.prototype.setIntro = function (intro) {
    this.introMode = !!intro;
    if (!intro) {
      this.cameraYaw = 0;
      this.cameraPitch = 0.27;
      this.cameraDistance = 9.4;
    }
  };

  World.prototype.bindPointer = function () {
    var el = this.renderer.domElement;
    var self = this;
    // Fixed front camera: dragging no longer rotates anything. The mouse
    // wheel is still allowed as a pure zoom, because it does not change the
    // viewing direction.
    el.addEventListener('wheel', function (e) {
      if (self.uiBlocked || self.introMode) return;
      e.preventDefault();
      self.cameraDistance = clamp(self.cameraDistance + e.deltaY * 0.008, 7.0, 12.5);
    }, { passive: false });
    el.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  };

  World.prototype.resize = function () {
    if (!this.renderer) return;
    var width = this.container.clientWidth || window.innerWidth;
    var height = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / Math.max(1, height);
    this.camera.updateProjectionMatrix();
    if (this.cssRenderer) {
      this.cssRenderer.setSize(width, height);
      this.cssRenderer.domElement.style.position = 'absolute';
      this.cssRenderer.domElement.style.inset = '0';
      this.cssDirty = true;
    }
    if (this.cssRenderer && this.terminalObject) {
      this.terminalAvailable = width >= 560 && width >= height;
      if (!this.terminalAvailable && this.terminalFocus) this.closeTerminal();
    }
  };

  World.prototype.hideTerminal = function () {
    this.terminalNear = false;
    this.terminalProximity = 0;
    this.terminalFocus = false;
    if (this.terminalObject) {
      this.terminalObject.visible = false;
      this.cssDirty = true;
    }
    if (this.terminalEl) {
      this.terminalEl.classList.remove('is-interactive');
      this.terminalEl.style.display = 'none';
      if ('inert' in this.terminalEl) this.terminalEl.inert = true;
    }
    if (this.css3dLayer) this.css3dLayer.setAttribute('aria-hidden', 'true');
    if (document.body) document.body.classList.remove('terminal-focus');
    if (this.playerModel) this.playerModel.visible = true;
  };

  World.prototype.updateTerminalProximity = function () {
    if (!this.terminalAvailable || !this.terminalObject || !this.player) return;
    var dx = this.player.position.x - this.terminalCenter.x;
    var dz = this.player.position.z - this.terminalCenter.z;
    var distance = Math.sqrt(dx * dx + dz * dz);
    this.terminalDistance = distance;

    var playerFront = (dx * this.terminalNormal.x + dz * this.terminalNormal.z) > 0.05;
    var near = distance < 4.7 && playerFront;
    this.terminalNear = near || this.terminalFocus;

    // The interactive CSS3D terminal only exists in the focused E mode.
    // Outside of it the physical screen shows its standby canvas, so the
    // DOM overlay can never cover the avatar in third person.
    var showTerminal = this.terminalFocus;
    if (showTerminal !== this.terminalObject.visible) {
      this.terminalObject.visible = showTerminal;
      this.cssDirty = true;
    }
    if (this.terminalEl) {
      this.terminalEl.style.display = showTerminal ? '' : 'none';
      this.terminalEl.classList.toggle('is-interactive', showTerminal);
      if ('inert' in this.terminalEl) this.terminalEl.inert = !showTerminal;
    }
    if (this.css3dLayer) this.css3dLayer.setAttribute('aria-hidden', showTerminal ? 'false' : 'true');
  };

  World.prototype.openTerminal = function () {
    if (!this.terminalAvailable || !this.terminalObject) return false;
    this.terminalFocus = true;
    if (this.playerModel) this.playerModel.visible = false;
    if (document.body) document.body.classList.add('terminal-focus');
    this.terminalObject.visible = true;
    this.cssDirty = true;
    if (this.terminalEl) {
      this.terminalEl.style.display = '';
      this.terminalEl.classList.add('is-interactive');
      if ('inert' in this.terminalEl) this.terminalEl.inert = false;
    }
    if (this.css3dLayer) this.css3dLayer.setAttribute('aria-hidden', 'false');
    this.setMoveInput(0, 0);
    return true;
  };

  World.prototype.closeTerminal = function () {
    if (!this.terminalFocus) return;
    this.terminalFocus = false;
    if (this.playerModel) this.playerModel.visible = true;
    if (document.body) document.body.classList.remove('terminal-focus');
    this.terminalObject.visible = false;
    this.cssDirty = true;
    if (this.terminalEl) {
      this.terminalEl.style.display = 'none';
      this.terminalEl.classList.remove('is-interactive');
      if ('inert' in this.terminalEl) this.terminalEl.inert = true;
    }
    if (this.css3dLayer) this.css3dLayer.setAttribute('aria-hidden', 'true');
  };

  World.prototype.reset = function () {
    this.hideTerminal();
    this.measurementState = {};
    this.buildState = {};
    this.measures = {};
    this.ventilationOn = false;
    this.shadeBuilt = false;
    this.troughBuilt = false;
    if (this.shadeGroup) {
      this.shadeGroup.visible = false;
      this.shadeGroup.scale.set(1, 1, 1);
    }
    if (this.troughGroup) {
      this.troughGroup.visible = false;
      this.troughGroup.scale.set(1, 1, 1);
    }
    this.colliders.circles = this.colliders.circles.filter(function (c) { return !(c.x === 20 && c.z === 0.7); });
    this.ripples.forEach(function (ring) {
      if (ring.userData.needsTrough) ring.visible = false;
    });
    this.fanSwitchLamp.material.color.setHex(0xb76b4f);
    this.fanSwitchLamp.material.emissive = new T.Color(0x000000);
    this.fanBlades.forEach(function (fan) { fan.speed = 0; });
    this.ventStreaks.forEach(function (s) { s.mesh.visible = false; });
    this.markerList.forEach(function (m) { m.active = false; m.group.visible = false; });

    this.cows.forEach(function (cow) {
      cow.group.position.set(cow.data.start.x, 0, cow.data.start.z);
      cow.heading = rand(0, Math.PI * 2);
      cow.group.rotation.y = cow.heading;
      cow.stress = 0.85;
      cow.mode = 'idle';
      cow.timer = rand(1.5, 4);
      cow.target.copy(cow.home);
      cow.moving = false;
      cow.statusSprite.material.opacity = 0;
    });
    this.cows[0].mode = 'shade';
    this.cows[0].target.set(9.4, 0, -7.0);
    this.cows[2].mode = 'drink';
    this.cows[2].target.set(22.5, 0, 5.4);

    this.pigs.forEach(function (pig, i) {
      pig.group.position.set(pig.center.x, 0, pig.center.z);
      pig.target.copy(pig.center);
      pig.timer = 1 + i;
    });
    this.chickens.forEach(function (chicken, i) {
      chicken.group.position.set(chicken.center.x, 0, chicken.center.z);
      chicken.target.copy(chicken.center);
      chicken.timer = 0.5 + i * 0.3;
    });

    if (this.player) {
      this.player.position.set(4.8, 0, 22.8);
      this.player.rotation.y = Math.PI;
      this.playerModel.position.y = 0;
      this.playerModel.visible = true;
    }
    this.playerSpeed = 0;
    this.playerWalkPhase = 0;
    this.sprint = false;
    this.cameraYaw = 0;
    this.cameraPitch = 0.27;
    this.cameraDistance = 9.4;
    this.introMode = true;
    this.moveInput.x = 0;
    this.moveInput.z = 0;
    this.treeCanopies.forEach(function (canopy) {
      canopy.opacity = 1;
      canopy.material.opacity = 1;
      canopy.material.transparent = false;
      canopy.material.depthWrite = true;
      canopy.material.needsUpdate = true;
    });
    this.puffs.forEach(function (p) { p.life = 0; p.sprite.visible = false; });
    this.dust.forEach(function (d) { d.life = 0; d.sprite.visible = false; });
    this.buildBursts.forEach(function (b) { b.life = 999; if (b.mesh.parent) b.mesh.parent.remove(b.mesh); });
    this.buildBursts = [];
  };

  /* ---------------------------------------------------------
     Simulation update
     --------------------------------------------------------- */

  World.prototype.updateDay = function (dt) {
    this.dayProgress = clamp(this.dayProgress + dt / 1500, 0.18, 0.86);
    var p = this.dayProgress;
    var angle = p * Math.PI;
    var sunX = Math.cos(angle) * 34 + 4;
    var sunY = 22 + Math.sin(angle) * 22;
    var sunZ = 20 - p * 36;
    this.sun.position.set(sunX, sunY, sunZ);
    this.skyUniforms.sunDirection.value.set(sunX, sunY, sunZ).normalize();
    var warm = Math.min(1, Math.max(0, (p - 0.55) * 1.7));
    this.sun.color.lerpColors(new T.Color(0xfff1cf), new T.Color(0xffd09a), warm);
    this.sun.intensity = 1.6 - warm * 0.2;
    this.skyUniforms.horizonColor.value.lerpColors(new T.Color(0xd3e6ea), new T.Color(0xf4d3a6), warm * 0.7);
    this.skyUniforms.topColor.value.lerpColors(new T.Color(0x4a94d4), new T.Color(0x5a92c4), warm * 0.3);
    this.scene.fog.color.copy(this.skyUniforms.horizonColor.value).multiplyScalar(0.97);
  };

  World.prototype.updatePlayer = function (dt) {
    if (this.uiBlocked || this.introMode || this.terminalFocus) {
      this.playerSpeed = damp(this.playerSpeed, 0, 8, dt);
    } else {
      var inputX = this.moveInput.x;
      var inputZ = this.moveInput.z;
      var mag = Math.sqrt(inputX * inputX + inputZ * inputZ);
      if (mag > 1) {
        inputX /= mag;
        inputZ /= mag;
        mag = 1;
      }
      var forwardX = -Math.sin(this.cameraYaw);
      var forwardZ = -Math.cos(this.cameraYaw);
      var rightX = Math.cos(this.cameraYaw);
      var rightZ = -Math.sin(this.cameraYaw);
      var dx = forwardX * inputZ + rightX * inputX;
      var dz = forwardZ * inputZ + rightZ * inputX;
      var maxSpeed = this.sprint ? 6.2 : 3.5;
      var desiredSpeed = mag > 0.08 ? maxSpeed : 0;
      this.playerSpeed = damp(this.playerSpeed, desiredSpeed, 10, dt);

      // Turn toward the pressed direction first, then run forward in the
      // direction the character is actually facing. This prevents the avatar
      // from sliding sideways while the body is still rotating.
      var travelSpeed = 0;
      if (mag > 0.08) {
        var desiredHeading = Math.atan2(dx, dz);
        var maxTurn = 12 * dt;
        var turnDiff = angleDelta(this.player.rotation.y, desiredHeading);
        this.player.rotation.y += clamp(turnDiff, -maxTurn, maxTurn);
        var remaining = Math.abs(angleDelta(this.player.rotation.y, desiredHeading));
        var alignment = Math.max(0, Math.cos(remaining));
        travelSpeed = this.playerSpeed * alignment;
      }

      var facingX = Math.sin(this.player.rotation.y);
      var facingZ = Math.cos(this.player.rotation.y);
      var vx = travelSpeed * facingX;
      var vz = travelSpeed * facingZ;
      var nx = this.player.position.x + vx * dt;
      var nz = this.player.position.z + vz * dt;
      var resolved = this.resolvePlayerCollisions(nx, nz);
      this.player.position.x = resolved.x;
      this.player.position.z = resolved.z;

      this.playerWalkPhase += dt * (2.2 + travelSpeed * 2.1);
      var swing = Math.sin(this.playerWalkPhase) * 0.6 * clamp(travelSpeed / 3.5, 0, 1);
      this.playerLegs[0].rotation.x = swing;
      this.playerLegs[1].rotation.x = -swing;
      this.playerArms[0].rotation.x = -swing * 0.7;
      this.playerArms[1].rotation.x = swing * 0.7;
      var bobAmount = this.reducedMotion ? 0.012 : 0.04;
      this.playerModel.position.y = Math.abs(Math.sin(this.playerWalkPhase)) * bobAmount * clamp(travelSpeed / 3.5, 0, 1);
      this.playerHair.rotation.x = 0.35 + Math.sin(this.playerWalkPhase * 0.9) * 0.03;
      if (travelSpeed > 1.8 && !this.reducedMotion) {
        this.dustTimer -= dt;
        if (this.dustTimer <= 0) {
          this.dustTimer = 0.22;
          this.spawnDust(this.player.position.x + rand(-0.2, 0.2), 0.1, this.player.position.z + rand(-0.15, 0.15));
        }
      }
    }
    if (this.playerSpeed < 0.1 && !this.uiBlocked) {
      this.playerModel.position.y = Math.sin(this.time * 1.8) * 0.008;
      this.playerArms[0].rotation.x = Math.sin(this.time * 1.4) * 0.02;
      this.playerArms[1].rotation.x = -Math.sin(this.time * 1.4) * 0.02;
    }
  };

  World.prototype.resolvePlayerCollisions = function (x, z) {
    var radius = 0.4;
    var minX = -30.3, maxX = 30.3, minZ = -26.2, maxZ = 26.1;
    x = clamp(x, minX, maxX);
    z = clamp(z, minZ, maxZ);

    for (var iter = 0; iter < 2; iter += 1) {
      for (var i = 0; i < this.colliders.circles.length; i += 1) {
        var c = this.colliders.circles[i];
        var dx = x - c.x;
        var dz = z - c.z;
        var distSq = dx * dx + dz * dz;
        var minDist = c.r + radius;
        if (distSq < minDist * minDist) {
          var dist = Math.sqrt(distSq) || 0.001;
          x = c.x + (dx / dist) * minDist;
          z = c.z + (dz / dist) * minDist;
        }
      }
      for (var j = 0; j < this.colliders.rects.length; j += 1) {
        var r = this.colliders.rects[j];
        var closestX = clamp(x, r.minX, r.maxX);
        var closestZ = clamp(z, r.minZ, r.maxZ);
        var ddx = x - closestX;
        var ddz = z - closestZ;
        var d2 = ddx * ddx + ddz * ddz;
        if (d2 < radius * radius) {
          if (d2 > 0.000001) {
            var d = Math.sqrt(d2);
            x = closestX + (ddx / d) * radius;
            z = closestZ + (ddz / d) * radius;
          } else {
            var left = Math.abs(x - r.minX);
            var right = Math.abs(r.maxX - x);
            var up = Math.abs(z - r.minZ);
            var down = Math.abs(r.maxZ - z);
            var min = Math.min(left, right, up, down);
            if (min === left) x = r.minX - radius;
            else if (min === right) x = r.maxX + radius;
            else if (min === up) z = r.minZ - radius;
            else z = r.maxZ + radius;
          }
        }
      }
    }
    x = clamp(x, minX, maxX);
    z = clamp(z, minZ, maxZ);
    return { x: x, z: z };
  };

  World.prototype.spawnDust = function (x, y, z) {
    for (var i = 0; i < this.dust.length; i += 1) {
      var d = this.dust[i];
      if (d.life <= 0) {
        d.life = d.maxLife;
        d.sprite.visible = true;
        d.sprite.position.set(x, y, z);
        d.sprite.material.opacity = 0.35;
        d.sprite.scale.set(rand(0.2, 0.36), rand(0.14, 0.22), 1);
        d.velocity = new T.Vector3(rand(-0.15, 0.15), rand(0.05, 0.18), rand(-0.15, 0.15));
        return;
      }
    }
  };

  World.prototype.spawnPuff = function (x, y, z) {
    for (var i = 0; i < this.puffs.length; i += 1) {
      var p = this.puffs[i];
      if (p.life <= 0) {
        p.life = p.maxLife = rand(0.8, 1.5);
        p.sprite.visible = true;
        p.sprite.position.set(x, y, z);
        p.sprite.material.opacity = 0.32;
        p.sprite.scale.set(rand(0.22, 0.4), rand(0.22, 0.4), 1);
        p.velocity.set(rand(-0.06, 0.06), rand(0.22, 0.42), rand(-0.06, 0.06));
        return;
      }
    }
  };

  World.prototype.updateCows = function (dt) {
    var self = this;
    this.cows.forEach(function (cow) {
      var pos = cow.group.position;
      var inBarn = pos.z < -13.2 && pos.x > 7 && pos.x < 23;
      var inNewShade = self.shadeBuilt && Math.abs(pos.x - 14) < 4.2 && Math.abs(pos.z - 2.5) < 3.2;
      var nearTree = (Math.abs(pos.x - 8.2) < 5.4 && Math.abs(pos.z + 9.3) < 5.0) ||
        (Math.abs(pos.x - 26.8) < 4.8 && Math.abs(pos.z + 9.5) < 4.2);
      var shade = inBarn || inNewShade || nearTree;
      var allMeasures = self.measures.shade && self.measures.water && self.measures.ventilation;
      var thi = 84.5;
      if (allMeasures) thi -= 5.5;
      if (shade) thi -= 8.0;
      if (inBarn) thi -= 3.4;
      if (self.measures.ventilation) thi -= inBarn ? 7.0 : 2.6;
      if (self.measures.water) thi -= 2.0;
      if (self.measures.shade && inNewShade) thi -= 0.8;
      var sensitivityFactor = 0.55 + cow.data.sensitivity * 0.12;
      var targetStress = clamp(((thi - 60) / 26) * sensitivityFactor, 0, 1);
      cow.stress = damp(cow.stress, targetStress, 1.35, dt);

      cow.timer -= dt;

      if (cow.moving) {
        var dx = cow.target.x - pos.x;
        var dz = cow.target.z - pos.z;
        var dist = Math.sqrt(dx * dx + dz * dz);
        if (dist < 0.38) {
          cow.moving = false;
          cow.mode = 'idle';
          cow.timer = rand(4, 9);
        } else {
          var speed = cow.moveSpeed * (cow.stress > 0.6 ? 0.72 : 1.0);
          var step = Math.min(dist, speed * dt);
          pos.x += (dx / dist) * step;
          pos.z += (dz / dist) * step;
          var heading = Math.atan2(dx, dz);
          cow.heading = angleLerp(cow.heading, heading, 1 - Math.exp(-5 * dt));
          cow.group.rotation.y = cow.heading;
          cow.walkPhase += dt * (3.4 + speed * 1.8);
          cow.grazePose = damp(cow.grazePose, 0, 5, dt);
        }
      } else if (cow.timer <= 0) {
        self.pickCowAction(cow);
      }

      // Separation from herd-mates.
      for (var o = 0; o < self.cows.length; o += 1) {
        var other = self.cows[o];
        if (other === cow) continue;
        var ox = pos.x - other.group.position.x;
        var oz = pos.z - other.group.position.z;
        var od2 = ox * ox + oz * oz;
        if (od2 < 2.2 * 2.2 && od2 > 0.001) {
          var od = Math.sqrt(od2);
          pos.x += (ox / od) * (2.2 - od) * 0.12;
          pos.z += (oz / od) * (2.2 - od) * 0.12;
        }
      }
      self.keepCowInBounds(cow);

      // Walk animation.
      var walkAmp = cow.moving ? 1 : 0;
      cow.legs.forEach(function (leg, index) {
        var targetRot = walkAmp ? Math.sin(cow.walkPhase + index * Math.PI) * 0.32 : 0;
        leg.rotation.z = damp(leg.rotation.z, targetRot, 7, dt);
      });
      var grazeTarget = (!cow.moving && (cow.mode === 'graze' || cow.mode === 'drink')) ? 0.45 : 0;
      cow.grazePose = damp(cow.grazePose, grazeTarget, 2.2, dt);
      cow.headGroup.position.y = 1.55 + Math.sin(cow.walkPhase * 1.5) * (cow.moving ? 0.025 : 0.012) - cow.grazePose * 0.52;
      cow.headGroup.rotation.z = -0.04 + cow.grazePose * 0.45 + Math.sin(self.time * 0.8 + cow.data.patternSeed) * 0.012;
      cow.bodyGroup.position.y = Math.sin(self.time * 1.05 + cow.data.patternSeed) * 0.006 - cow.grazePose * 0.03;
      cow.body.scale.y = 0.71 + Math.sin(self.time * 1.35 + cow.data.patternSeed) * (cow.stress > 0.6 ? 0.018 : 0.008);
      cow.tailGroup.rotation.y = Math.sin(self.time * (1.2 + cow.stress) + cow.data.patternSeed) * (0.28 + cow.stress * 0.38);
      cow.tailGroup.rotation.z = 0.06 + (cow.stress > 0.6 ? Math.sin(self.time * 2.1) * 0.1 : 0);

      // Heat status sprite.
      var showStatus = cow.stress > 0.63;
      var targetOpacity = showStatus ? 0.96 : 0;
      cow.statusSprite.material.opacity = damp(cow.statusSprite.material.opacity, targetOpacity, 3.5, dt);
      cow.statusSprite.position.y = 3.0 + Math.sin(self.time * 1.6 + cow.data.patternSeed) * 0.04;

      // Panting puffs.
      if (cow.stress > 0.67) {
        cow.puffTimer -= dt;
        if (cow.puffTimer <= 0) {
          cow.puffTimer = rand(1.0, 2.2);
          self._tmpVec.set(0.16, 0.05, 0);
          cow.headGroup.localToWorld(self._tmpVec);
          self.spawnPuff(self._tmpVec.x, self._tmpVec.y - 0.05, self._tmpVec.z);
        }
      }
      cow.statusSprite.visible = cow.statusSprite.material.opacity > 0.02;
    });

    // Keep marker anchors in sync with the moving cows.
    this.cows.forEach(function (cow) {
      if (cow.marker) {
        cow.marker.x = cow.group.position.x;
        cow.marker.z = cow.group.position.z;
      }
    });
  };

  World.prototype.pickCowAction = function (cow) {
    var stress = cow.stress;
    var r = Math.random();
    var mode = 'graze';
    var target = new T.Vector3();

    if (stress > 0.6) {
      if (this.ventilationOn && r < 0.16) {
        mode = 'barn';
        target.set(rand(9.5, 20.5), 0, rand(-21, -15));
      } else if (r < 0.56) {
        mode = 'shade';
        if (this.shadeBuilt && Math.random() < 0.7) {
          target.set(14 + rand(-2.6, 2.6), 0, 2.5 + rand(-1.6, 1.6));
        } else {
          target.set(8.2 + rand(-2.6, 2.6), 0, -9.3 + rand(-1.8, 1.8));
        }
      } else if (r < 0.76) {
        mode = 'drink';
        if (this.troughBuilt && Math.random() < 0.7) {
          target.set(20 + rand(-1.2, 1.2), 0, 1.9 + rand(-0.3, 0.5));
        } else {
          target.set(22.3 + rand(-0.5, 0.5), 0, 6.2 + rand(-0.3, 0.5));
        }
      } else if (r < 0.9) {
        mode = 'walk';
        target.set(rand(6, 28), 0, rand(-12, 9));
      } else {
        mode = 'idle';
      }
    } else {
      if (r < 0.38) {
        mode = 'graze';
        target.set(rand(6, 28), 0, rand(-12, 9));
      } else if (r < 0.56) {
        mode = 'shade';
        if (this.shadeBuilt && Math.random() < 0.7) target.set(14 + rand(-2.8, 2.8), 0, 2.5 + rand(-1.8, 1.8));
        else target.set(8.2 + rand(-2.5, 2.5), 0, -9.3 + rand(-1.8, 1.8));
      } else if (r < 0.72) {
        mode = 'idle';
      } else if (r < 0.86) {
        mode = 'drink';
        if (this.troughBuilt && Math.random() < 0.65) target.set(20 + rand(-1.2, 1.2), 0, 1.9 + rand(-0.3, 0.5));
        else target.set(22.3 + rand(-0.5, 0.5), 0, 6.2 + rand(-0.3, 0.5));
      } else {
        mode = 'walk';
        target.set(rand(6, 28), 0, rand(-12, 9));
      }
      if (cow.data.id === 'paula' && Math.random() < 0.25) {
        mode = 'drink';
        target.set(this.troughBuilt ? 20.5 : 22.4, 0, this.troughBuilt ? 1.9 : 6.2);
      }
    }

    cow.mode = mode;
    if (mode === 'idle') {
      cow.moving = false;
      cow.timer = rand(4, 8);
    } else {
      cow.target.copy(target);
      cow.moving = true;
      cow.timer = rand(5, 11);
    }
  };

  World.prototype.keepCowInBounds = function (cow) {
    var p = cow.group.position;
    var inBarn = p.z < -13.35;
    if (inBarn) {
      if (p.x < 8.2 || p.x > 21.8) {
        // The barn front is open only between these posts.
        p.z = -13.35;
        p.x = clamp(p.x, 5.0, 29.0);
        return;
      }
      if (p.z < -22.2) p.z = -22.2;
    } else {
      if (p.x < 5.0) p.x = 5.0;
      if (p.x > 29.0) p.x = 29.0;
      if (p.z > 9.7) p.z = 9.7;
    }
  };

  World.prototype.updateSimpleAnimals = function (dt) {
    this.pigs.forEach(function (pig) {
      pig.timer -= dt;
      var p = pig.group.position;
      if (pig.timer <= 0) {
        pig.timer = rand(3.5, 8);
        var a = rand(0, Math.PI * 2);
        var r = rand(0.4, pig.radius);
        pig.target.set(pig.center.x + Math.cos(a) * r, 0, pig.center.z + Math.sin(a) * r);
      }
      var dx = pig.target.x - p.x;
      var dz = pig.target.z - p.z;
      var dist = Math.sqrt(dx * dx + dz * dz);
      if (dist > 0.25) {
        var step = Math.min(dist, pig.speed * dt);
        p.x += (dx / dist) * step;
        p.z += (dz / dist) * step;
        pig.group.rotation.y = Math.atan2(dx, dz);
        pig.phase += dt * 4.5;
      }
      pig.group.position.y = Math.abs(Math.sin(pig.phase)) * 0.012;
    });

    this.chickens.forEach(function (chicken) {
      chicken.timer -= dt;
      var p = chicken.group.position;
      chicken.phase += dt * 8;
      if (chicken.timer <= 0) {
        chicken.timer = rand(1.2, 4.5);
        var a = rand(0, Math.PI * 2);
        var r = rand(0.3, chicken.radius);
        chicken.target.set(chicken.center.x + Math.cos(a) * r, 0, chicken.center.z + Math.sin(a) * r);
        chicken.peck = Math.random() < 0.6 ? rand(1.2, 2.5) : 0;
      }
      var dx = chicken.target.x - p.x;
      var dz = chicken.target.z - p.z;
      var dist = Math.sqrt(dx * dx + dz * dz);
      if (dist > 0.12) {
        var step = Math.min(dist, 0.3 * dt);
        p.x += (dx / dist) * step;
        p.z += (dz / dist) * step;
        chicken.group.rotation.y = Math.atan2(dx, dz);
        chicken.group.position.y = Math.abs(Math.sin(chicken.phase)) * 0.01;
      } else {
        chicken.group.position.y = 0;
        if (chicken.peck > 0) {
          chicken.peck -= dt;
          chicken.group.rotation.x = Math.sin(chicken.phase * 1.7) * 0.12;
        } else {
          chicken.group.rotation.x = damp(chicken.group.rotation.x, 0, 5, dt);
        }
      }
    });
  };

  World.prototype.updateAmbient = function (dt) {
    this.butterflies.forEach(function (b) {
      b.group.visible = !this.reducedMotion;
      if (this.reducedMotion) return;
      var t = this.time * b.speed + b.phase;
      var x = b.center.x + Math.cos(t) * b.radius;
      var z = b.center.z + Math.sin(t * 0.9 + 1) * b.radius * 0.7;
      var y = b.center.y + 0.25 + Math.sin(t * 2.3) * 0.25;
      b.group.position.set(x, y, z);
      b.group.rotation.y = -t * 0.7;
      var flap = Math.sin(this.time * 16 + b.phase) * 0.75;
      b.left.rotation.z = -0.25 - flap;
      b.right.rotation.z = 0.25 + flap;
    }, this);

    this.clouds.forEach(function (cloud) {
      cloud.position.x += cloud.userData.speed * dt;
      if (cloud.position.x > 170) cloud.position.x = -170;
    });

    this.weatherCups.rotation.y += dt * 0.7;

    this.fanBlades.forEach(function (fan, i) {
      var target = this.ventilationOn ? 8 + i * 0.4 : 0;
      fan.speed = damp(fan.speed, target, 1.2, dt);
      fan.group.rotation.y += fan.speed * dt;
    }, this);
    if (this.fanSwitchLamp) {
      this.fanSwitchLamp.material.emissiveIntensity = this.ventilationOn ? (0.6 + Math.sin(this.time * 3) * 0.15) : 0;
    }

    this.ventStreaks.forEach(function (s) {
      s.mesh.visible = this.ventilationOn;
      if (!s.mesh.visible) return;
      s.mesh.position.z -= s.speed * dt;
      s.mesh.position.x += Math.sin(this.time + s.phase) * 0.12 * dt;
      if (s.mesh.position.z < -22.2) {
        s.mesh.position.z = -14.2;
        s.mesh.position.x = rand(9, 21);
        s.mesh.position.y = rand(0.6, 3.4);
      }
    }, this);

    this.ripples.forEach(function (ring) {
      if (!ring.visible) return;
      var t = (this.time * 0.22 + ring.userData.phase) % 1;
      ring.scale.setScalar(ring.userData.base * (0.45 + t * 1.35));
      ring.material.opacity = 0.36 * (1 - t);
    }, this);

    if (this.updateScenery) this.updateScenery(dt);
    this.updateShadeGlow(dt);
    this.updateBuildBursts(dt);
    this.updatePuffs(dt);
    this.updateDust(dt);
    this.updateMarkers(dt);
  };

  World.prototype.updateShadeGlow = function (dt) {
    if (this.shadeBuilt && this.shadeGroup.userData.grow < 1) {
      var g = this.shadeGroup.userData.grow;
      g = Math.min(1, g + dt * 1.7);
      this.shadeGroup.userData.grow = g;
      var eased = 1 - Math.pow(1 - g, 3);
      this.shadeGroup.scale.set(0.75 + eased * 0.25, Math.max(0.04, eased), 0.75 + eased * 0.25);
      if (g >= 1) this.shadeGroup.scale.set(1, 1, 1);
    }
    if (this.troughBuilt && this.troughGroup.userData.grow < 1) {
      var g2 = this.troughGroup.userData.grow;
      g2 = Math.min(1, g2 + dt * 2.3);
      this.troughGroup.userData.grow = g2;
      var eased2 = 1 - Math.pow(1 - g2, 3);
      this.troughGroup.scale.set(0.6 + eased2 * 0.4, Math.max(0.05, eased2), 0.6 + eased2 * 0.4);
      if (g2 >= 1) this.troughGroup.scale.set(1, 1, 1);
    }
  };

  World.prototype.updateBuildBursts = function (dt) {
    for (var i = this.buildBursts.length - 1; i >= 0; i -= 1) {
      var b = this.buildBursts[i];
      b.life += dt;
      var t = b.life / b.maxLife;
      if (t >= 1) {
        if (b.mesh.parent) b.mesh.parent.remove(b.mesh);
        this.buildBursts.splice(i, 1);
        continue;
      }
      b.mesh.scale.setScalar(1 + t * 5.5);
      b.mesh.material.opacity = 0.62 * (1 - t);
    }
  };

  World.prototype.updatePuffs = function (dt) {
    this.puffs.forEach(function (p) {
      if (p.life <= 0) return;
      p.life -= dt;
      if (p.life <= 0) {
        p.sprite.visible = false;
        return;
      }
      p.sprite.position.addScaledVector(p.velocity, dt);
      p.sprite.position.x += Math.sin(this.time * 2 + p.life) * 0.02 * dt;
      var t = p.life / p.maxLife;
      p.sprite.material.opacity = 0.3 * t;
      var scale = 0.25 + (1 - t) * 0.65;
      p.sprite.scale.set(scale, scale, 1);
    }, this);
  };

  World.prototype.updateDust = function (dt) {
    this.dust.forEach(function (d) {
      if (d.life <= 0) return;
      d.life -= dt;
      if (d.life <= 0) {
        d.sprite.visible = false;
        return;
      }
      d.sprite.position.addScaledVector(d.velocity, dt);
      d.velocity.y -= dt * 0.12;
      d.sprite.material.opacity = 0.3 * (d.life / d.maxLife);
      d.sprite.scale.x += dt * 0.4;
      d.sprite.scale.y += dt * 0.2;
    });
  };

  World.prototype.updateMarkers = function (dt) {
    for (var i = 0; i < this.markerList.length; i += 1) {
      var marker = this.markerList[i];
      if (!marker.active) continue;
      var x = marker.x;
      var z = marker.z;
      if (marker.cow) {
        x = marker.cow.group.position.x;
        z = marker.cow.group.position.z;
      }
      marker.group.position.x = damp(marker.group.position.x, x, 10, dt);
      marker.group.position.z = damp(marker.group.position.z, z, 10, dt);
      marker.sprite.position.y = marker.baseY + Math.sin(this.time * 2.1 + marker.bob) * 0.09;
      var scale = 1 + Math.sin(this.time * 2 + marker.bob) * 0.018;
      marker.sprite.scale.set(2.9 * this.markerScale * scale, 1.45 * this.markerScale * scale, 1);
      marker.ring.material.opacity = 0.52 + Math.sin(this.time * 2.1 + marker.bob) * 0.18;
    }
  };

  World.prototype.updateCamera = function (dt) {
    if (this.introMode) {
      // Static front overview: the intro must not suggest a rotatable camera.
      this.camera.position.x = damp(this.camera.position.x, 4.5, 1.2, dt);
      this.camera.position.y = damp(this.camera.position.y, 13.5, 1.2, dt);
      this.camera.position.z = damp(this.camera.position.z, 38, 1.2, dt);
      this.camera.lookAt(4.5, 0.6, -2);
      return;
    }

    var player = this.player.position;

    if (this.terminalFocus && this.terminalGroup) {
      // E-mode: glide into a first-person view directly in front of the
      // display. The avatar is hidden, movement is locked, and the CSS3D
      // terminal becomes interactive. This camera move is explicit and only
      // happens when the player presses E at the station.
      // Step back far enough that the whole screen fits narrower viewports.
      var focusDist = Math.max(2.25, (this.terminalScreenWidth * 0.58) / (Math.tan(this.camera.fov * Math.PI / 360) * this.camera.aspect));
      this._terminalViewPos.set(
        this.terminalCenter.x + this.terminalNormal.x * focusDist,
        1.62,
        this.terminalCenter.z + this.terminalNormal.z * focusDist
      );
      var focusBlend = 1 - Math.exp(-9 * dt);
      this.camera.position.x = lerp(this.camera.position.x, this._terminalViewPos.x, focusBlend);
      this.camera.position.y = lerp(this.camera.position.y, this._terminalViewPos.y, focusBlend);
      this.camera.position.z = lerp(this.camera.position.z, this._terminalViewPos.z, focusBlend);
      this.camera.lookAt(this.terminalCenter.x, this.terminalCenter.y, this.terminalCenter.z);
      return;
    }

    var targetY = 1.52;
    var cosPitch = Math.cos(this.cameraPitch);
    var offsetX = Math.sin(this.cameraYaw) * cosPitch * this.cameraDistance;
    var offsetZ = Math.cos(this.cameraYaw) * cosPitch * this.cameraDistance;
    var offsetY = Math.sin(this.cameraPitch) * this.cameraDistance + 0.55;
    var desiredX = player.x + offsetX;
    var desiredY = targetY + offsetY;
    var desiredZ = player.z + offsetZ;
    var blend = 1 - Math.exp(-7.5 * dt);
    this.camera.position.x = lerp(this.camera.position.x, desiredX, blend);
    this.camera.position.y = lerp(this.camera.position.y, desiredY, blend);
    this.camera.position.z = lerp(this.camera.position.z, desiredZ, blend);
    if (this.camera.position.y < 0.8) this.camera.position.y = 0.8;
    this.lookTarget.set(
      player.x - Math.sin(this.cameraYaw) * 1.7,
      targetY + 0.12,
      player.z - Math.cos(this.cameraYaw) * 1.7
    );
    this.camera.lookAt(this.lookTarget);
    this.updateCanopyFade(dt);
  };

  World.prototype.updateCanopyFade = function (dt) {
    if (!this.treeCanopies) return;
    for (var i = 0; i < this.treeCanopies.length; i += 1) {
      var canopy = this.treeCanopies[i];
      var distance = this.camera.position.distanceTo(canopy.center);
      var target = distance < canopy.radius * 1.25 ? 0.2 : 1;
      canopy.opacity = damp(canopy.opacity, target, 5, dt);
      var material = canopy.material;
      material.opacity = canopy.opacity;
      var shouldBeTransparent = canopy.opacity < 0.985;
      if (material.transparent !== shouldBeTransparent) {
        material.transparent = shouldBeTransparent;
        material.depthWrite = !shouldBeTransparent;
        material.needsUpdate = true;
      }
    }
  };

  World.prototype.update = function (dt, allowSimulation) {
    this.updateQuality(dt);
    if (dt > 0.1) dt = 0.1;
    this.time += dt;
    this.updateTerminalProximity();
    if (allowSimulation !== false && !this.uiBlocked) {
      this.updatePlayer(dt);
    } else {
      this.playerSpeed = damp(this.playerSpeed, 0, 9, dt);
      if (this.playerModel) {
        this.playerLegs[0].rotation.x = damp(this.playerLegs[0].rotation.x, 0, 7, dt);
        this.playerLegs[1].rotation.x = damp(this.playerLegs[1].rotation.x, 0, 7, dt);
        this.playerArms[0].rotation.x = damp(this.playerArms[0].rotation.x, 0, 7, dt);
        this.playerArms[1].rotation.x = damp(this.playerArms[1].rotation.x, 0, 7, dt);
      }
    }

    if (allowSimulation !== false) {
      this.updateCows(dt);
      this.updateSimpleAnimals(dt);
      this.updateAmbient(dt);
      this.updateDay(dt);
    } else {
      this.updateMarkers(dt);
    }
    this.updateCamera(dt);
  };

  // Keeps the game fluid on weak devices: if frames stay slow, first the
  // render resolution and then meadow density and shadow detail are reduced.
  World.prototype.updateQuality = function (dt) {
    if (dt <= 0 || dt > 0.25) return;
    this._qTime = (this._qTime || 0) + dt;
    this._qFrames = (this._qFrames || 0) + 1;
    if (this._qTime < 1.5) return;
    var avg = this._qTime / this._qFrames;
    this._qTime = 0;
    this._qFrames = 0;
    if (this._qWarm !== true) { this._qWarm = true; return; }
    if (avg < 0.021) return;
    this.qualityLevel = (this.qualityLevel || 0) + 1;
    var ratio = this.renderer.getPixelRatio();
    if (ratio > 1.0) {
      this.renderer.setPixelRatio(Math.max(1.0, ratio * 0.8));
    } else if (!this._qThinned) {
      this._qThinned = true;
      if (this.setMeadowDensity) this.setMeadowDensity(0.5);
    } else if (!this._qShadow) {
      this._qShadow = true;
      this.sun.shadow.mapSize.set(1024, 1024);
      if (this.sun.shadow.map) { this.sun.shadow.map.dispose(); this.sun.shadow.map = null; }
    } else if (ratio > 0.7) {
      this.renderer.setPixelRatio(Math.max(0.7, ratio * 0.85));
    } else {
      return;
    }
    this.resize();
  };

  World.prototype.render = function () {
    this.renderer.render(this.scene, this.camera);
    if (this.cssRenderer && this.terminalObject && (this.terminalObject.visible || this.cssDirty)) {
      this.cssRenderer.render(this.scene, this.camera);
      if (!this.terminalObject.visible) this.cssDirty = false;
    }
  };

  /* ---------------------------------------------------------
     Build-time z-fighting audit
     A dependency-free approximation of triangle-plane bucketing:
     coplanar, overlapping triangles from different objects are
     reported, together with whether their materials carry a
     distinct polygon offset. This is intentionally run only by
     the build test, never during normal gameplay.
     --------------------------------------------------------- */

  World.prototype.auditZFighting = function (options) {
    options = options || {};
    this.scene.updateMatrixWorld(true);
    var maxTrianglesPerMesh = options.maxTrianglesPerMesh || 220;
    var maxConflicts = options.maxConflicts || 60;
    var epsilon = options.overlapEpsilon == null ? 0.004 : options.overlapEpsilon;
    var buckets = {};
    var meshCount = 0;
    var triangleCount = 0;
    var pairCount = 0;
    var mitigatedCount = 0;
    var unmitigatedCount = 0;
    var conflicts = [];
    var unmitigatedConflicts = [];
    var pairSeen = {};
    var materialCount = 0;
    var materialOffsetCount = 0;
    var materialsWithoutOffset = [];
    var vA = new T.Vector3();
    var vB = new T.Vector3();
    var vC = new T.Vector3();
    var ab = new T.Vector3();
    var ac = new T.Vector3();
    var cross = new T.Vector3();
    var self = this;

    function visibleInScene(object) {
      var node = object;
      while (node) {
        if (!node.visible) return false;
        node = node.parent;
      }
      return true;
    }

    function materialLabel(material) {
      if (!material) return 'none';
      return material.name || (material.type + '#' + material.id);
    }

    function offsetSignature(material) {
      if (!material || !material.polygonOffset) return null;
      return material.polygonOffsetFactor.toFixed(6) + ':' + material.polygonOffsetUnits.toFixed(6);
    }

    function objectLabel(object) {
      var pos = new T.Vector3().setFromMatrixPosition(object.matrixWorld);
      var material = Array.isArray(object.material) ? object.material[0] : object.material;
      return (object.name || object.geometry.type) + '#' + object.id +
        '@(' + pos.x.toFixed(1) + ',' + pos.y.toFixed(1) + ',' + pos.z.toFixed(1) + ')' +
        '[' + materialLabel(material) + ']';
    }

    this.scene.traverse(function (object) {
      var material = object.material;
      if (!material) return;
      var materials = Array.isArray(material) ? material : [material];
      for (var mi = 0; mi < materials.length; mi += 1) {
        var m = materials[mi];
        if (!m || m.isSpriteMaterial || m.isShaderMaterial || m.isRawShaderMaterial) continue;
        materialCount += 1;
        if (m.polygonOffset) materialOffsetCount += 1;
        else if (materialsWithoutOffset.length < 20) materialsWithoutOffset.push(materialLabel(m));
      }

      if (!object.isMesh || object.isInstancedMesh) return;
      if (!visibleInScene(object)) return;
      var mat = Array.isArray(object.material) ? object.material[0] : object.material;
      if (!mat || mat.isSpriteMaterial || mat.isShaderMaterial || mat.isRawShaderMaterial) return;
      if (mat.transparent || mat.depthWrite === false) return;
      var geometry = object.geometry;
      if (!geometry || !geometry.attributes || !geometry.attributes.position) return;

      var position = geometry.attributes.position;
      var index = geometry.index;
      var triCount = Math.floor((index ? index.count : position.count) / 3);
      if (triCount < 1) return;
      var step = Math.max(1, Math.ceil(triCount / maxTrianglesPerMesh));
      meshCount += 1;

      for (var tri = 0; tri < triCount; tri += step) {
        var i0 = index ? index.getX(tri * 3) : tri * 3;
        var i1 = index ? index.getX(tri * 3 + 1) : tri * 3 + 1;
        var i2 = index ? index.getX(tri * 3 + 2) : tri * 3 + 2;

        vA.fromBufferAttribute(position, i0).applyMatrix4(object.matrixWorld);
        vB.fromBufferAttribute(position, i1).applyMatrix4(object.matrixWorld);
        vC.fromBufferAttribute(position, i2).applyMatrix4(object.matrixWorld);
        ab.subVectors(vB, vA);
        ac.subVectors(vC, vA);
        cross.crossVectors(ab, ac);
        var area2 = cross.length();
        if (area2 < 0.00001) continue;
        cross.normalize();

        var nx = Math.round(cross.x * 1000) / 1000;
        var ny = Math.round(cross.y * 1000) / 1000;
        var nz = Math.round(cross.z * 1000) / 1000;
        var d = -cross.dot(vA);
        var dKey = Math.round(d * 500) / 500;
        var key = nx + '|' + ny + '|' + nz + '|' + dKey;

        var ax = Math.abs(nx);
        var ay = Math.abs(ny);
        var az = Math.abs(nz);
        var u;
        var v;
        if (ax >= ay && ax >= az) {
          u = 1; v = 2;
        } else if (ay >= ax && ay >= az) {
          u = 0; v = 2;
        } else {
          u = 0; v = 1;
        }
        var points = [vA, vB, vC];
        var minU = Infinity, maxU = -Infinity, minV = Infinity, maxV = -Infinity;
        for (var p = 0; p < 3; p += 1) {
          var coords = points[p].toArray();
          minU = Math.min(minU, coords[u]);
          maxU = Math.max(maxU, coords[u]);
          minV = Math.min(minV, coords[v]);
          maxV = Math.max(maxV, coords[v]);
        }

        if (!buckets[key]) buckets[key] = [];
        buckets[key].push({
          object: object,
          material: mat,
          triangle: tri,
          minU: minU,
          maxU: maxU,
          minV: minV,
          maxV: maxV,
          normal: new T.Vector3(nx, ny, nz),
          d: d
        });
        triangleCount += 1;
      }
    });

    var bucketKeys = Object.keys(buckets);
    var comparisons = 0;
    for (var bk = 0; bk < bucketKeys.length; bk += 1) {
      var bucket = buckets[bucketKeys[bk]];
      if (bucket.length < 2) continue;
      for (var i = 0; i < bucket.length; i += 1) {
        for (var j = i + 1; j < bucket.length; j += 1) {
          if (bucket[i].object === bucket[j].object) continue;
          comparisons += 1;
          if (comparisons > 400000) break;
          var overlapU = Math.min(bucket[i].maxU, bucket[j].maxU) - Math.max(bucket[i].minU, bucket[j].minU);
          if (overlapU <= epsilon) continue;
          var overlapV = Math.min(bucket[i].maxV, bucket[j].maxV) - Math.max(bucket[i].minV, bucket[j].minV);
          if (overlapV <= epsilon) continue;

          var sigA = offsetSignature(bucket[i].material);
          var sigB = offsetSignature(bucket[j].material);
          var mitigated = !!(sigA && sigB && sigA !== sigB);
          var pairKey = bucket[i].object.uuid + '|' + bucket[j].object.uuid;
          if (pairSeen[pairKey]) continue;
          pairSeen[pairKey] = true;
          pairCount += 1;
          if (mitigated) mitigatedCount += 1;
          else unmitigatedCount += 1;
          var conflict = {
            a: objectLabel(bucket[i].object),
            b: objectLabel(bucket[j].object),
            normal: bucket[i].normal.toArray().map(function (n) { return Math.round(n * 1000) / 1000; }),
            d: Math.round(bucket[i].d * 1000) / 1000,
            overlap: Math.round(Math.min(overlapU, overlapV) * 1000) / 1000,
            mitigated: mitigated,
            offsetA: sigA,
            offsetB: sigB
          };
          if (conflicts.length < maxConflicts) conflicts.push(conflict);
          if (!mitigated && unmitigatedConflicts.length < 20) unmitigatedConflicts.push(conflict);
        }
        if (comparisons > 400000) break;
      }
      if (comparisons > 400000) break;
    }

    return {
      meshesChecked: meshCount,
      trianglesChecked: triangleCount,
      buckets: bucketKeys.length,
      trianglesCompared: comparisons,
      coplanarPairs: pairCount,
      mitigatedPairs: mitigatedCount,
      unmitigatedPairs: unmitigatedCount,
      materialCount: materialCount,
      materialsWithPolygonOffset: materialOffsetCount,
      materialsWithoutPolygonOffset: materialsWithoutOffset,
      conflicts: conflicts,
      unmitigatedConflicts: unmitigatedConflicts
    };
  };

  NTK.World = World;
})();
