/* =========================================================
   Nutztierkosmos · game controller, mission logic, platform API
   Classic script on purpose: works in a sandboxed iframe without
   allow-same-origin (no ES-module CORS requirements).
   ========================================================= */
(function () {
  'use strict';

  var D = window.NTK_DATA;
  var NTK = window.NTK = window.NTK || {};
  var $ = function (id) { return document.getElementById(id); };
  var HAS_PARENT = window.parent && window.parent !== window;

  function formatNumber(value, digits) {
    return Number(value).toFixed(digits == null ? 1 : digits).replace('.', ',');
  }

  function formatDuration(ms) {
    var total = Math.max(0, Math.floor(ms / 1000));
    var h = Math.floor(total / 3600);
    var m = Math.floor((total % 3600) / 60);
    var s = total % 60;
    if (h > 0) return h + ':' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
    return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
  }

  function safeName(value) {
    var name = String(value == null ? '' : value).replace(/\s+/g, ' ').trim().slice(0, 40);
    return name || D.meta.defaultPlayer;
  }

  function seededRandom(seed) {
    var state = (Number(seed) || 1) >>> 0;
    return function () {
      state = (state * 1664525 + 1013904223) >>> 0;
      return state / 4294967296;
    };
  }

  function hexToRgba(hex, alpha) {
    var value = String(hex || '#c56b47').replace('#', '');
    if (value.length === 3) {
      value = value.split('').map(function (c) { return c + c; }).join('');
    }
    if (value.length !== 6) value = 'c56b47';
    var r = parseInt(value.slice(0, 2), 16);
    var g = parseInt(value.slice(2, 4), 16);
    var b = parseInt(value.slice(4, 6), 16);
    return 'rgba(' + r + ', ' + g + ', ' + b + ', ' + (alpha == null ? 1 : alpha) + ')';
  }

  function cowNeedIcon(need) {
    var value = String(need || '').toLowerCase();
    if (value.indexOf('schatten') >= 0) return 'i-shade';
    if (value.indexOf('wasser') >= 0) return 'i-droplet';
    if (value.indexOf('ruhe') >= 0) return 'i-leaf';
    return 'i-cow';
  }

  function cowSignIcon(sign) {
    var value = String(sign || '').toLowerCase();
    if (value.indexOf('atm') >= 0) return 'i-wind';
    if (value.indexOf('schatten') >= 0 || value.indexOf('rückzug') >= 0) return 'i-shade';
    if (value.indexOf('wasser') >= 0 || value.indexOf('tränk') >= 0 || value.indexOf('durst') >= 0) return 'i-droplet';
    if (value.indexOf('fress') >= 0 || value.indexOf('futter') >= 0 || value.indexOf('wiederkäu') >= 0) return 'i-leaf';
    if (value.indexOf('unruhe') >= 0 || value.indexOf('wechsel') >= 0 || value.indexOf('aktiv') >= 0) return 'i-spark';
    if (value.indexOf('temperatur') >= 0 || value.indexOf('hitze') >= 0) return 'i-sun';
    return 'i-eye';
  }

  function cowPortraitSvg(data) {
    var random = seededRandom(data.patternSeed || 1);
    var base = data.color || '#f6f1e6';
    var pattern = data.pattern || '#2f2f2a';
    var safeId = String(data.id || 'kuh').replace(/[^a-z0-9_-]/gi, '');
    var clipId = 'cow-head-' + safeId;
    var spots = '';
    for (var i = 0; i < 4; i += 1) {
      var cx = 44 + random() * 32;
      var cy = 47 + random() * 30;
      var rx = 4 + random() * 7;
      var ry = 4 + random() * 6;
      var rotation = Math.round(random() * 180 - 90);
      spots += '<ellipse cx="' + cx.toFixed(1) + '" cy="' + cy.toFixed(1) + '" rx="' + rx.toFixed(1) + '" ry="' + ry.toFixed(1) + '" fill="' + pattern + '" opacity="0.92" transform="rotate(' + rotation + ' ' + cx.toFixed(1) + ' ' + cy.toFixed(1) + ')"/>';
    }
    return [
      '<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Porträt von ' + data.name + '">',
      '<defs><clipPath id="' + clipId + '"><ellipse cx="60" cy="64" rx="35" ry="31"/></clipPath></defs>',
      '<rect width="120" height="120" rx="28" fill="#fffdf8" opacity="0.5"/>',
      '<ellipse cx="25" cy="56" rx="14" ry="9" fill="' + base + '" stroke="' + pattern + '" stroke-width="3" transform="rotate(-20 25 56)"/>',
      '<ellipse cx="95" cy="56" rx="14" ry="9" fill="' + base + '" stroke="' + pattern + '" stroke-width="3" transform="rotate(20 95 56)"/>',
      '<path d="M33 43 Q25 27 39 23" fill="none" stroke="#e7d6b4" stroke-width="5" stroke-linecap="round"/>',
      '<path d="M87 43 Q95 27 81 23" fill="none" stroke="#e7d6b4" stroke-width="5" stroke-linecap="round"/>',
      '<ellipse cx="60" cy="64" rx="35" ry="31" fill="' + base + '" stroke="' + pattern + '" stroke-width="3"/>',
      '<g clip-path="url(#' + clipId + ')">' + spots + '</g>',
      '<ellipse cx="47" cy="60" rx="4.4" ry="5.4" fill="#20201d"/>',
      '<ellipse cx="73" cy="60" rx="4.4" ry="5.4" fill="#20201d"/>',
      '<circle cx="48.5" cy="58" r="1.5" fill="#ffffff"/>',
      '<circle cx="74.5" cy="58" r="1.5" fill="#ffffff"/>',
      '<ellipse cx="60" cy="83" rx="19" ry="12.5" fill="#d89a8c"/>',
      '<ellipse cx="53" cy="81" rx="3" ry="4" fill="#774b43"/>',
      '<ellipse cx="67" cy="81" rx="3" ry="4" fill="#774b43"/>',
      '<ellipse cx="60" cy="36" rx="11" ry="7" fill="' + base + '" stroke="' + pattern + '" stroke-width="2"/>',
      '<path d="M48 91 Q60 100 72 91" fill="none" stroke="#4d3b2c" stroke-width="5" stroke-linecap="round"/>',
      '<circle cx="60" cy="98" r="5.5" fill="#e8b95e"/>',
      '<circle cx="60" cy="98" r="1.6" fill="#a96f1e"/>',
      '<rect x="17" y="50" width="10" height="7" rx="2" fill="#f2c14e" transform="rotate(-18 22 53)"/>',
      '</svg>'
    ].join('');
  }

  var platform = {
    ready: false,
    send: function (type, payload) {
      if (!HAS_PARENT) return;
      try {
        window.parent.postMessage({
          source: 'ntk-game',
          type: type,
          payload: payload || {}
        }, '*');
      } catch (err) {
        // The surrounding platform may have been removed; the standalone
        // game must keep working regardless.
      }
    }
  };

  var game = {
    world: null,
    mode: 'intro',
    phaseIndex: 0,
    observed: {},
    followup: {},
    tempDone: false,
    humidityDone: false,
    measures: { shade: false, water: false, ventilation: false },
    score: 0,
    platformMax: D.meta.maxPoints,
    startedAt: 0,
    completedAt: 0,
    completed: false,
    completedSent: false,
    startedAtWall: 0,
    playerName: D.meta.defaultPlayer,
    currentModal: null,
    terminalDom: null,
    terminalWasNear: false,
    touchSprint: false,
    pauseOpen: false,
    localPaused: false,
    platformPaused: false,
    lastFocused: null,
    nearest: null,
    lastPromptKey: '',
    keys: {},
    joystick: { active: false, x: 0, y: 0, pointerId: null },
    isTouch: false,
    soundOn: true,
    musicOn: true,
    musicLevel: 0.15,
    reducedMotion: false,
    unlocked: null,
    newEntries: null,
    audio: null,
    lastFrame: 0,
    locationTimer: 0,
    lastLocation: '',
    toastTimers: [],
    pendingReset: false,
    booted: false,
    elapsedPaused: 0,

    /* -------------------------------------------------------
       Boot
       ------------------------------------------------------- */

    boot: function () {
      this.cacheDom();
      this.audio = new NTK.AudioEngine();
      this.refreshTouchMode();
      this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      document.body.classList.toggle('reduced-motion', this.reducedMotion);
      this.unlocked = new Set(['mission']);
      this.newEntries = new Set();
      this.applyPlayerName(this.playerName);
      this.bindUi();
      this.bindKeyboard();
      this.updateSoundUi();
      this.updateMotionUi();
      this.updateTouchSprintUi();
      this.updateJournalCounter();
      this.updateScoreDisplay();
      window.addEventListener('resize', this.onResize.bind(this));
      window.addEventListener('blur', this.clearInput.bind(this));
      document.addEventListener('visibilitychange', this.onVisibility.bind(this));
      window.addEventListener('error', function () {
        platform.send('LOG', { level: 'error', message: 'Unerwarteter Fehler im Spiel.' });
      });

      if (window.ResizeObserver && $('scene')) {
        try {
          this.resizeObserver = new ResizeObserver(this.onResize.bind(this));
          this.resizeObserver.observe($('scene'));
        } catch (err) {}
      }

      var self = this;
      // Give the loading screen a paint before constructing geometry.
      window.setTimeout(function () {
        try {
          self.world = new NTK.World($('scene'));
          self.world.renderer.domElement.tabIndex = -1;
          self.world.reducedMotion = self.reducedMotion;
          self.bindTerminalControls();
          self.world.sync(self.getWorldState());
          self.world.render();
          self.finishBoot();
        } catch (err) {
          window.__NTK_FATAL__ = String(err && err.stack ? err.stack : err);
          if (window.console && console.error) console.error('NTK fatal:', err);
          self.showFatal();
        }
      }, 60);
    },

    cacheDom: function () {
      var ids = [
        'app', 'scene', 'loadingScreen', 'hudTop','scoreValue', 'scoreMax',
        'playerAvatar', 'playerName', 'soundBtn', 'journalBtn', 'menuBtn', 'missionPanel',
        'missionPlayerName', 'missionStepBadge', 'phaseKicker', 'phaseTitle', 'phaseText', 'taskList',
        'missionProgressBar', 'missionProgressText', 'journalInline', 'locationChip',
        'locationText', 'interactionPrompt', 'promptText', 'toastHost', 'desktopHint',
        'mobileControls', 'mobileSprint', 'joystick', 'joystickKnob', 'mobileInteract', 'introOverlay',
        'introAvatar', 'introPlayerName', 'startBtn', 'journalOverlay', 'journalClose',
        'journalCount', 'journalHeadline', 'journalSubline', 'journalRing', 'journalEntries',
        'journalDone', 'measureOverlay', 'measureClose', 'measureTemp', 'tempValue',
        'tempAction', 'measureHumidity', 'humValue', 'humAction', 'thiPanel', 'thiValue',
        'thiBadge', 'thiMarker', 'thiText', 'measureDone', 'cowOverlay', 'cowPortrait',
        'cowKicker', 'cowTitle', 'cowClose', 'cowTags', 'cowObservation', 'cowPanels',
        'cowMetrics', 'cowScience', 'cowScoreHint', 'cowDone',
        'cowProfileStats', 'cowSensitivityLabel', 'cowSensitivityDots', 'cowProfileHint',
        'cowBehavior', 'cowSigns', 'cowScienceExtra', 'debriefOverlay',
        'debriefTitle', 'debriefLead', 'debriefScore', 'debriefMax', 'debriefDuration',
        'debriefScores', 'debriefCows', 'debriefExplore', 'restartBtn', 'pauseOverlay',
        'pauseTitle', 'pauseClose', 'pauseLead', 'pauseSound', 'musicToggle', 'musicVolume', 'musicVolumeLabel', 'motionToggle', 'pauseRestart',
        'pauseResume', 'completePill', 'completePillBtn', 'fatalError',
        'debugToggle', 'debugPanel', 'debugClose', 'debugRecord', 'debugCopy', 'debugStatus', 'debugOutput'
      ];
      var cache = {};
      ids.forEach(function (id) { cache[id] = $(id); });
      this.el = cache;
      this.scorePill = document.querySelector('.score-pill');
    },

    finishBoot: function () {
      this.booted = true;
      platform.send('READY', {});
      this.sendState('intro');
      this.updateJournalCounter();
      this.updateScoreDisplay();
      this.showIntro(true);
      this.startLoop();
      if (this.pendingReset) {
        this.pendingReset = false;
        this.resetGame('platform');
      }
      if (this.platformPaused) {
        this.refreshPauseUi();
      }
    },

    showIntro: function (animate) {
      this.el.introOverlay.hidden = false;
      this.el.loadingScreen.classList.add('is-gone');
      var self = this;
      try { this.el.startBtn.focus({ preventScroll: true }); } catch (err) {}
      window.setTimeout(function () {
        if (self.el.loadingScreen.classList.contains('is-gone')) {
          self.el.loadingScreen.hidden = true;
          self.el.loadingScreen.style.display = 'none';
        }
        if (self.mode === 'intro') {
          try { self.el.startBtn.focus({ preventScroll: true }); } catch (err) {}
        }
      }, 620);
      if (this.world) this.world.render();
    },

    showFatal: function () {
      this.el.loadingScreen.hidden = true;
      this.el.introOverlay.hidden = true;
      this.el.fatalError.hidden = false;
      platform.send('LOG', { level: 'error', message: '3D-Szene konnte nicht initialisiert werden.' });
    },

    startLoop: function () {
      var self = this;
      this.lastFrame = performance.now();
      function frame(now) {
        var dt = Math.min(0.06, Math.max(0, (now - self.lastFrame) / 1000));
        self.lastFrame = now;
        if (self.world) {
          if (!self.pauseOpen) {
            var allowSim = !self.currentModal;
            self.updateMovementInput();
            self.world.update(dt, allowSim);
            self.updatePrompt();
            self.updateLocation(dt);
            self.audio.update(dt);
          }
          self.world.render();
        }
        requestAnimationFrame(frame);
      }
      requestAnimationFrame(frame);
    },

    /* -------------------------------------------------------
       Player / platform API
       ------------------------------------------------------- */

    applyPlayerName: function (name) {
      var clean = safeName(name);
      this.playerName = clean;
      if (!this.el) return;
      this.el.playerName.textContent = clean;
      this.el.introPlayerName.textContent = clean;
      this.el.missionPlayerName.textContent = clean;
      var initial = Array.from(clean)[0] || 'F';
      initial = initial.toUpperCase();
      this.el.playerAvatar.textContent = initial;
      this.el.introAvatar.textContent = initial;
    },

    applyInit: function (payload) {
      payload = payload || {};
      if (payload.player && typeof payload.player.name === 'string') {
        this.applyPlayerName(payload.player.name);
      }
      if (payload.game && Number.isFinite(Number(payload.game.maxPoints)) && Number(payload.game.maxPoints) > 0) {
        var max = Math.round(Number(payload.game.maxPoints));
        if (max >= 1 && max <= 1000000) this.platformMax = max;
      }
      this.updateScoreDisplay();
      if (this.completed) {
        this.el.debriefScore.textContent = this.reportedScore();
        this.el.debriefMax.textContent = String(this.platformMax);
        if (this.currentModal === this.el.debriefOverlay) this.populateDebrief();
      }
      platform.send('READY', {});
      if (this.mode !== 'intro') this.sendScore();
      this.sendState(this.mode === 'complete' ? 'complete' : (this.pauseOpen ? 'paused' : this.mode));
    },

    sendScore: function () {
      if (!this.booted) return;
      platform.send('SCORE', {
        points: this.reportedScore(),
        maxPoints: this.platformMax
      });
    },

    sendState: function (state) {
      platform.send('STATE', { state: state });
    },

    reportedScore: function () {
      return Math.round((Math.max(0, Math.min(1000, this.score)) / 1000) * this.platformMax);
    },

    addScore: function (points) {
      this.score = Math.max(0, Math.min(1000, this.score + points));
      this.updateScoreDisplay();
      this.sendScore();
      if (this.scorePill) {
        this.scorePill.classList.remove('is-bumping');
        void this.scorePill.offsetWidth;
        this.scorePill.classList.add('is-bumping');
        var self = this;
        window.setTimeout(function () { self.scorePill.classList.remove('is-bumping'); }, 560);
      }
    },

    updateScoreDisplay: function () {
      if (!this.el) return;
      var points = this.reportedScore();
      this.el.scoreValue.textContent = String(points);
      this.el.scoreMax.textContent = String(this.platformMax);
      if (this.scorePill) {
        this.scorePill.setAttribute('aria-label', points + ' von ' + this.platformMax + ' Punkten');
      }
    },

    setPlatformPaused: function (paused) {
      this.platformPaused = !!paused;
      if (!this.booted) return;
      if (this.platformPaused && this.mode === 'intro') {
        return;
      }
      this.refreshPauseUi();
    },

    requestReset: function () {
      if (!this.booted) {
        this.pendingReset = true;
        return;
      }
      this.resetGame('platform');
    },

    applyPlatformReset: function () {
      this.requestReset();
    },

    /* -------------------------------------------------------
       UI wiring
       ------------------------------------------------------- */

    bindUi: function () {
      var self = this;

      this.el.startBtn.addEventListener('click', function () { self.startGame(); });
      this.el.soundBtn.addEventListener('click', function () { self.toggleSound(); });
      this.el.journalBtn.addEventListener('click', function () { self.openJournal(); });
      this.el.journalInline.addEventListener('click', function () { self.openJournal(); });
      this.el.menuBtn.addEventListener('click', function () { self.openPauseMenu(); });
      this.el.journalClose.addEventListener('click', function () { self.closeJournal(); });
      this.el.journalDone.addEventListener('click', function () { self.closeJournal(); });
      this.el.measureClose.addEventListener('click', function () { self.closeMeasure(); });
      this.el.measureDone.addEventListener('click', function () { self.closeMeasure(); });
      this.el.measureTemp.addEventListener('click', function () { self.takeMeasurement('temp'); });
      this.el.measureHumidity.addEventListener('click', function () { self.takeMeasurement('humidity'); });
      this.el.cowClose.addEventListener('click', function () { self.closeCow(); });
      this.el.cowDone.addEventListener('click', function () { self.closeCow(); });
      this.bindCowTabs();
      this.bindCowWindow();
      this.bindDebugLog();
      this.el.debriefExplore.addEventListener('click', function () { self.closeDebrief(); });
      this.el.restartBtn.addEventListener('click', function () { self.resetGame('restart'); });
      this.el.completePillBtn.addEventListener('click', function () { self.openDebriefAgain(); });
      this.el.pauseClose.addEventListener('click', function () { self.closePauseMenu(); });
      this.el.pauseResume.addEventListener('click', function () { self.closePauseMenu(); });
      this.el.pauseRestart.addEventListener('click', function () { self.resetGame('restart'); });
      this.el.pauseSound.addEventListener('click', function () { self.toggleSound(); });
      this.el.motionToggle.addEventListener('click', function () { self.toggleMotion(); });
      this.el.musicToggle.addEventListener('click', function () {
        self.musicOn = !self.musicOn;
        if (self.audio) self.audio.setMusicEnabled(self.musicOn);
        self.updatePauseButtons();
      });
      this.el.musicVolume.addEventListener('input', function () {
        self.musicLevel = Math.max(0, Math.min(1, Number(self.el.musicVolume.value) / 100));
        if (self.audio) self.audio.setMusicLevel(self.musicLevel);
        self.updatePauseButtons();
      });
      this.el.mobileInteract.addEventListener('click', function () { self.interact(); });
      this.el.mobileSprint.addEventListener('click', function () { self.toggleTouchSprint(); });

      [['journalOverlay', 'closeJournal'], ['measureOverlay', 'closeMeasure'], ['cowOverlay', 'closeCow']].forEach(function (pair) {
        var overlay = self.el[pair[0]];
        overlay.addEventListener('mousedown', function (event) {
          if (event.target === overlay) {
            if (pair[0] === 'measureOverlay' && !(self.tempDone && self.humidityDone)) {
              self.closeMeasure();
            } else {
              self[pair[1]]();
            }
          }
        });
      });

      this.bindJoystick();
    },

    bindCowTabs: function () {
      var self = this;
      this.cowTabs = Array.prototype.slice.call(document.querySelectorAll('.cow-tab'));
      this.cowPanels = Array.prototype.slice.call(document.querySelectorAll('.cow-panel'));
      if (!this.cowTabs.length) return;

      this.cowTabs.forEach(function (tab) {
        tab.addEventListener('click', function () {
          self.setCowTab(tab.getAttribute('data-cow-tab'));
        });
      });

      var tabbar = document.querySelector('.cow-tabbar');
      if (tabbar) {
        tabbar.addEventListener('keydown', function (event) {
          var keys = ['ArrowRight', 'ArrowLeft', 'Home', 'End'];
          if (keys.indexOf(event.key) < 0) return;
          event.preventDefault();
          var current = self.cowTabs.findIndex(function (tab) {
            return tab.getAttribute('aria-selected') === 'true';
          });
          if (current < 0) current = 0;
          var next = current;
          if (event.key === 'ArrowRight') next = (current + 1) % self.cowTabs.length;
          else if (event.key === 'ArrowLeft') next = (current - 1 + self.cowTabs.length) % self.cowTabs.length;
          else if (event.key === 'Home') next = 0;
          else if (event.key === 'End') next = self.cowTabs.length - 1;
          var target = self.cowTabs[next];
          self.setCowTab(target.getAttribute('data-cow-tab'));
          target.focus();
        });
      }
    },

    setCowTab: function (name) {
      if (!this.cowTabs || !this.cowTabs.length) return;
      this.cowTabs.forEach(function (tab) {
        var active = tab.getAttribute('data-cow-tab') === name;
        tab.classList.toggle('is-active', active);
        tab.setAttribute('aria-selected', active ? 'true' : 'false');
        tab.tabIndex = active ? 0 : -1;
      });
      this.cowPanels.forEach(function (panel) {
        var active = panel.id === ('cowPanel' + name.charAt(0).toUpperCase() + name.slice(1));
        panel.hidden = !active;
        panel.classList.toggle('is-active', active);
      });
    },

    resetCowWindowPosition: function () {
      var overlay = this.el.cowOverlay;
      if (!overlay) return;
      var card = overlay.querySelector('.cow-card');
      if (!card) return;
      card.style.position = 'absolute';
      card.style.margin = '0';
      card.style.left = '0px';
      card.style.top = '0px';
      var maxLeft = Math.max(8, overlay.clientWidth - card.offsetWidth - 8);
      var maxTop = Math.max(8, overlay.clientHeight - card.offsetHeight - 8);
      var left = Math.max(8, Math.min(maxLeft, (overlay.clientWidth - card.offsetWidth) / 2));
      var top = Math.max(8, Math.min(maxTop, (overlay.clientHeight - card.offsetHeight) / 2));
      card.style.left = left + 'px';
      card.style.top = top + 'px';
    },

    bindCowWindow: function () {
      var self = this;
      var overlay = this.el.cowOverlay;
      if (!overlay) return;
      var card = overlay.querySelector('.cow-card');
      var head = card && card.querySelector('.cow-card-head');
      if (!head) return;

      var dragging = false;
      var pointerId = null;
      var startX = 0;
      var startY = 0;
      var startLeft = 0;
      var startTop = 0;

      var onMove = function (event) {
        if (!dragging || event.pointerId !== pointerId) return;
        var dx = event.clientX - startX;
        var dy = event.clientY - startY;
        var maxLeft = Math.max(8, overlay.clientWidth - card.offsetWidth - 8);
        var maxTop = Math.max(8, overlay.clientHeight - card.offsetHeight - 8);
        card.style.left = Math.max(8, Math.min(maxLeft, startLeft + dx)) + 'px';
        card.style.top = Math.max(8, Math.min(maxTop, startTop + dy)) + 'px';
        event.preventDefault();
      };

      var onUp = function (event) {
        if (!dragging) return;
        dragging = false;
        head.classList.remove('is-dragging');
        document.body.classList.remove('cow-dragging');
        try { head.releasePointerCapture(pointerId); } catch (err) {}
        pointerId = null;
        if (event) event.preventDefault();
      };

      head.addEventListener('pointerdown', function (event) {
        if (event.target.closest('button')) return;
        if (typeof event.button === 'number' && event.button !== 0) return;
        dragging = true;
        pointerId = event.pointerId;
        startX = event.clientX;
        startY = event.clientY;
        startLeft = parseFloat(card.style.left) || 0;
        startTop = parseFloat(card.style.top) || 0;
        head.classList.add('is-dragging');
        document.body.classList.add('cow-dragging');
        try { head.setPointerCapture(pointerId); } catch (err) {}
        event.preventDefault();
      });
      head.addEventListener('pointermove', onMove);
      head.addEventListener('pointerup', onUp);
      head.addEventListener('pointercancel', onUp);

      window.addEventListener('resize', function () {
        if (self.currentModal !== overlay) return;
        self.resetCowWindowPosition();
      });
    },

    bindDebugLog: function () {
      var self = this;
      if (!this.el.debugToggle) return;
      this.el.debugToggle.addEventListener('click', function () { self.toggleDebugPanel(); });
      this.el.debugClose.addEventListener('click', function () { self.toggleDebugPanel(false); });
      this.el.debugRecord.addEventListener('click', function () { self.startPositionLog(); });
      this.el.debugCopy.addEventListener('click', function () { self.copyPositionLog(); });
    },

    toggleDebugPanel: function (force) {
      if (!this.el.debugPanel) return;
      var open = typeof force === 'boolean' ? force : this.el.debugPanel.hidden;
      this.el.debugPanel.hidden = !open;
      this.el.debugToggle.setAttribute('aria-expanded', String(open));
    },

    startPositionLog: function () {
      if (this.logTimer) return;
      var self = this;
      this.logSamples = [];
      this.logStart = performance.now();
      this.el.debugStatus.textContent = 'Zeichne 5 s auf – bewege dich jetzt.';
      this.captureLogSample();
      var ticks = 0;
      this.logTimer = window.setInterval(function () {
        ticks += 1;
        self.captureLogSample();
        if (ticks >= 5) {
          window.clearInterval(self.logTimer);
          self.logTimer = null;
          self.finishPositionLog();
        }
      }, 1000);
    },

    captureLogSample: function () {
      var w = this.world;
      if (!w) return;
      var p = w.player.position;
      var c = w.camera.position;
      this.logSamples.push({
        t: (performance.now() - this.logStart) / 1000,
        player: { x: p.x, y: p.y, z: p.z, yaw: w.player.rotation.y, speed: w.playerSpeed },
        camera: { x: c.x, y: c.y, z: c.z, yaw: w.cameraYaw, pitch: w.cameraPitch, distance: w.cameraDistance },
        mode: w.terminalFocus ? 'terminal' : 'free'
      });
    },

    finishPositionLog: function () {
      this.el.debugOutput.value = this.formatPositionLog();
      this.el.debugStatus.textContent = this.logSamples.length + ' Werte aufgezeichnet · jetzt kopieren.';
    },

    formatPositionLog: function () {
      return (this.logSamples || []).map(function (s) {
        return 't=' + s.t.toFixed(2) + 's' +
          ' | player x=' + s.player.x.toFixed(3) + ' y=' + s.player.y.toFixed(3) + ' z=' + s.player.z.toFixed(3) +
          ' yaw=' + s.player.yaw.toFixed(3) + ' speed=' + s.player.speed.toFixed(2) +
          ' | camera x=' + s.camera.x.toFixed(3) + ' y=' + s.camera.y.toFixed(3) + ' z=' + s.camera.z.toFixed(3) +
          ' yaw=' + s.camera.yaw.toFixed(3) + ' pitch=' + s.camera.pitch.toFixed(3) + ' dist=' + s.camera.distance.toFixed(2) +
          ' | mode=' + s.mode;
      }).join('\n');
    },

    copyPositionLog: function () {
      var text = this.el.debugOutput.value;
      if (!text) {
        this.el.debugStatus.textContent = 'Noch keine Aufzeichnung.';
        return;
      }
      var self = this;
      var fallback = function () {
        try {
          self.el.debugOutput.focus();
          self.el.debugOutput.select();
          var ok = document.execCommand('copy');
          self.el.debugStatus.textContent = ok
            ? 'In die Zwischenablage kopiert.'
            : 'Kopieren blockiert – Text ist markiert (Strg+C).';
        } catch (err) {
          self.el.debugStatus.textContent = 'Kopieren blockiert – Text ist markiert (Strg+C).';
        }
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function () {
          self.el.debugStatus.textContent = 'In die Zwischenablage kopiert.';
        }, fallback);
      } else {
        fallback();
      }
    },

    bindJoystick: function () {
      var self = this;
      var joystick = this.el.joystick;
      var knob = this.el.joystickKnob;
      if (!joystick) return;

      function update(clientX, clientY) {
        var rect = joystick.getBoundingClientRect();
        var cx = rect.left + rect.width / 2;
        var cy = rect.top + rect.height / 2;
        var dx = clientX - cx;
        var dy = clientY - cy;
        var max = rect.width * 0.34;
        var len = Math.sqrt(dx * dx + dy * dy);
        if (len > max) {
          dx = (dx / len) * max;
          dy = (dy / len) * max;
        }
        knob.style.transform = 'translate(calc(-50% + ' + dx + 'px), calc(-50% + ' + dy + 'px))';
        self.joystick.x = dx / max;
        self.joystick.y = dy / max;
      }

      joystick.addEventListener('pointerdown', function (e) {
        if (self.currentModal || self.pauseOpen || self.mode === 'intro') return;
        self.joystick.active = true;
        self.joystick.pointerId = e.pointerId;
        joystick.classList.add('is-active');
        joystick.setPointerCapture(e.pointerId);
        update(e.clientX, e.clientY);
        e.preventDefault();
      });

      joystick.addEventListener('pointermove', function (e) {
        if (!self.joystick.active || e.pointerId !== self.joystick.pointerId) return;
        update(e.clientX, e.clientY);
        e.preventDefault();
      });

      function end(e) {
        if (!self.joystick.active) return;
        if (e && e.pointerId != null && e.pointerId !== self.joystick.pointerId) return;
        self.joystick.active = false;
        self.joystick.x = 0;
        self.joystick.y = 0;
        self.joystick.pointerId = null;
        joystick.classList.remove('is-active');
        knob.style.transform = 'translate(-50%, -50%)';
      }
      joystick.addEventListener('pointerup', end);
      joystick.addEventListener('pointercancel', end);
      joystick.addEventListener('lostpointercapture', end);
    },

    bindTerminalControls: function () {
      if (!this.world || !this.world.terminalEl) {
        this.terminalDom = null;
        return;
      }
      var root = this.world.terminalEl;
      this.terminalDom = {
        root: root,
        tempValue: root.querySelector('#terminalTempValue'),
        humValue: root.querySelector('#terminalHumValue'),
        tempBtn: root.querySelector('#terminalTempBtn'),
        humBtn: root.querySelector('#terminalHumBtn'),
        thiValue: root.querySelector('#terminalThiValue'),
        thiBadge: root.querySelector('#terminalThiBadge'),
        thiMarker: root.querySelector('#terminalThiMarker'),
        thiText: root.querySelector('#terminalThiText'),
        hint: root.querySelector('#terminalHint'),
        status: root.querySelector('#terminalStatus')
      };
      var self = this;
      this.terminalDom.tempBtn.addEventListener('click', function () {
        self.takeMeasurement('temp');
      });
      this.terminalDom.humBtn.addEventListener('click', function () {
        self.takeMeasurement('humidity');
      });
    },

    toggleTouchSprint: function () {
      this.touchSprint = !this.touchSprint;
      this.updateTouchSprintUi();
      if (this.world) this.world.setSprint(this.touchSprint);
    },

    updateTouchSprintUi: function () {
      if (!this.el || !this.el.mobileSprint) return;
      this.el.mobileSprint.classList.toggle('is-active', this.touchSprint);
      this.el.mobileSprint.setAttribute('aria-pressed', String(this.touchSprint));
      this.el.mobileSprint.setAttribute('aria-label', this.touchSprint ? 'Rennen ausschalten' : 'Rennen einschalten');
    },

    bindKeyboard: function () {
      var self = this;
      var moveCodes = ['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'];

      window.addEventListener('keydown', function (event) {
        if (event.code === 'Tab') {
          self.trapFocus(event);
          return;
        }

        if (event.code === 'Escape') {
          if (self.world && self.world.terminalFocus) {
            self.world.closeTerminal();
            self.updatePrompt();
            event.preventDefault();
            return;
          }
          if (self.pauseOpen) {
            if (!self.platformPaused) self.closePauseMenu();
            event.preventDefault();
            return;
          }
          if (self.currentModal) {
            self.closeTopModal();
            event.preventDefault();
            return;
          }
          if (self.mode === 'playing' || self.mode === 'complete') {
            self.openPauseMenu();
            event.preventDefault();
          }
          return;
        }

        if (self.currentModal || self.pauseOpen) {
          if (event.code === 'KeyJ' && self.currentModal === self.el.journalOverlay) {
            self.closeJournal();
            event.preventDefault();
          }
          return;
        }

        if (self.mode === 'intro') {
          if ((event.code === 'Enter' || event.code === 'Space') && document.activeElement !== self.el.startBtn) {
            self.startGame();
            event.preventDefault();
          }
          return;
        }

        if (event.code === 'ShiftLeft' || event.code === 'ShiftRight') {
          self.keys[event.code] = true;
          if (self.world) self.world.setSprint(true);
          return;
        }
        if (event.code === 'KeyE' && !event.repeat) {
          self.interact();
          event.preventDefault();
          return;
        }
        if (event.code === 'KeyJ' && !event.repeat && !(self.world && self.world.terminalFocus)) {
          self.openJournal();
          event.preventDefault();
          return;
        }

        if (moveCodes.indexOf(event.code) >= 0) {
          self.keys[event.code] = true;
          event.preventDefault();
        }
      });

      window.addEventListener('keyup', function (event) {
        if (moveCodes.indexOf(event.code) >= 0 || event.code === 'ShiftLeft' || event.code === 'ShiftRight') {
          self.keys[event.code] = false;
          if (event.code === 'ShiftLeft' || event.code === 'ShiftRight') {
            if (self.world) self.world.setSprint(!!(self.keys.ShiftLeft || self.keys.ShiftRight || self.touchSprint));
          }
          if (moveCodes.indexOf(event.code) >= 0) event.preventDefault();
        }
      });
    },

    trapFocus: function (event) {
      var overlay = this.pauseOpen ? this.el.pauseOverlay : this.currentModal;
      if (!overlay || overlay.hidden) return;
      var focusables = Array.prototype.slice.call(overlay.querySelectorAll(
        'button:not([disabled]):not([hidden]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
      )).filter(function (el) { return el.offsetParent !== null || el.getClientRects().length; });
      if (!focusables.length) return;
      var first = focusables[0];
      var last = focusables[focusables.length - 1];
      var active = document.activeElement;
      if (!overlay.contains(active)) {
        event.preventDefault();
        first.focus();
        return;
      }
      if (event.shiftKey && active === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && active === last) {
        event.preventDefault();
        first.focus();
      }
    },

    clearInput: function () {
      this.keys = {};
      this.touchSprint = false;
      this.updateTouchSprintUi();
      this.joystick.x = 0;
      this.joystick.y = 0;
      this.joystick.active = false;
      if (this.el) {
        this.el.joystick.classList.remove('is-active');
        this.el.joystickKnob.style.transform = 'translate(-50%, -50%)';
      }
      if (this.world) {
        this.world.setSprint(false);
        this.world.setMoveInput(0, 0);
      }
    },

    updateMovementInput: function () {
      if (!this.world) return;
      if (this.world.terminalFocus) {
        this.world.setMoveInput(0, 0);
        this.world.setSprint(false);
        return;
      }
      if (this.currentModal || this.pauseOpen || this.mode === 'intro') {
        this.world.setMoveInput(0, 0);
        return;
      }
      var k = this.keys;
      var forward = (k.KeyW || k.ArrowUp ? 1 : 0) - (k.KeyS || k.ArrowDown ? 1 : 0);
      var right = (k.KeyD || k.ArrowRight ? 1 : 0) - (k.KeyA || k.ArrowLeft ? 1 : 0);
      if (this.joystick.active) {
        right += this.joystick.x;
        forward += -this.joystick.y;
      }
      var len = Math.sqrt(forward * forward + right * right);
      if (len > 1) {
        forward /= len;
        right /= len;
      }
      var sprint = !!(this.keys.ShiftLeft || this.keys.ShiftRight || this.touchSprint);
      this.world.setSprint(sprint);
      this.world.setMoveInput(right, forward);
    },

    refreshInputBlock: function () {
      if (!this.world) return;
      var blocked = this.mode === 'intro' || !!this.currentModal || this.pauseOpen;
      this.world.setUiBlocked(blocked);
      if (blocked) this.hidePrompt();
      else this.updatePrompt();
    },

    /* -------------------------------------------------------
       Game flow
       ------------------------------------------------------- */

    startGame: function () {
      if (this.mode !== 'intro' || !this.world) return;
      this.mode = 'playing';
      this.phaseIndex = 0;
      this.startedAt = performance.now();
      this.completed = false;
      this.completedSent = false;
      this.audio.init();
      this.audio.resume();
      this.audio.setMuted(!this.soundOn);
      this.audio.setReduced(this.reducedMotion);
      this.audio.sfx('open');
      this.el.introOverlay.hidden = true;
      this.el.hudTop.hidden = false;
      this.el.missionPanel.hidden = false;
      this.el.completePill.hidden = true;
      this.el.desktopHint.hidden = this.isTouch;
      this.el.mobileControls.hidden = !this.isTouch;
      this.el.locationChip.hidden = false;
      this.world.setIntro(false);
      this.world.sync(this.getWorldState());
      this.refreshInputBlock();
      this.updateMissionUI();
      this.updateScoreDisplay();
      this.updateSoundUi();
      this.updateLocation(1);
      this.sendScore();
      this.sendState('playing');
      this.showToast('Auftrag gestartet', 'Beobachte drei Kühe auf der Weide. Achte auf Atmung, Unruhe und Rückzugsorte.', 'eye', 0);
      var self = this;
      window.setTimeout(function () {
        if (self.mode === 'playing' && !self.currentModal && !self.pauseOpen) {
          self.showToast('Erster Hinweis', D.tips[0], 'info', 0);
        }
      }, 5200);
      if (this.isTouch) {
        window.setTimeout(function () {
          if (self.mode === 'playing' && !self.currentModal && !self.pauseOpen) {
            self.showToast('Touch-Steuerung', 'Analog-Pad links bewegt dich. Rechts unten: Interagieren und Rennen. Die Kamera bleibt fest von vorne.', 'info', 0);
          }
        }, 3000);
      }
      if (this.platformPaused) this.refreshPauseUi();
      if (!this.pauseOpen && this.world && this.world.renderer) {
        try { this.world.renderer.domElement.focus({ preventScroll: true }); } catch (err) {}
      }
    },

    resetGame: function (reason) {
      this.clearInput();
      this.closeEveryOverlay();
      this.toastTimers.forEach(function (timer) { window.clearTimeout(timer); });
      this.toastTimers = [];
      this.el.toastHost.innerHTML = '';
      this.mode = 'intro';
      this.phaseIndex = 0;
      this.observed = {};
      this.followup = {};
      this.tempDone = false;
      this.humidityDone = false;
      this.measures = { shade: false, water: false, ventilation: false };
      this.score = 0;
      this.startedAt = 0;
      this.completedAt = 0;
      this.completed = false;
      this.completedSent = false;
      this.currentModal = null;
      this.touchSprint = false;
      this.pauseOpen = false;
      this.localPaused = false;
      this.platformPaused = false;
      this.nearest = null;
      this.lastPromptKey = '';
      this.unlocked = new Set(['mission']);
      this.newEntries = new Set();
      this.el.hudTop.hidden = true;
      this.el.missionPanel.hidden = true;
      this.el.completePill.hidden = true;
      this.el.locationChip.hidden = true;
      this.el.mobileControls.hidden = true;
      this.el.desktopHint.hidden = true;
      this.el.introOverlay.hidden = false;
      this.el.loadingScreen.hidden = true;
      this.el.loadingScreen.style.display = 'none';
      document.body.classList.remove('pause-open');
      if (this.world) {
        this.world.reset();
        this.world.setUiBlocked(true);
        this.world.setIntro(true);
        this.world.sync({ phase: 'intro', observed: {}, followup: {}, measures: {}, tempDone: false, humidityDone: false });
        this.world.render();
      }
      this.audio.setFan(false);
      this.audio.setStress(1);
      this.audio.pause();
      this.updateScoreDisplay();
      this.updateJournalCounter();
      this.updateTouchSprintUi();
      this.updateMissionUI();
      this.updatePauseButtons();
      this.el.measureDone.disabled = true;
      this.el.tempValue.textContent = '—';
      this.el.humValue.textContent = '—';
      this.el.tempAction.textContent = 'Messen';
      this.el.humAction.textContent = 'Messen';
      this.el.measureTemp.disabled = false;
      this.el.measureHumidity.disabled = false;
      this.el.measureTemp.classList.remove('is-done');
      this.el.measureHumidity.classList.remove('is-done');
      this.el.thiPanel.classList.add('is-locked');
      this.el.thiValue.textContent = '—';
      this.el.thiBadge.textContent = 'noch keine Messung';
      this.el.thiBadge.className = 'thi-badge';
      this.el.thiMarker.style.left = '50%';
      this.el.thiText.textContent = 'Miss Temperatur und Luftfeuchte, um die kombinierte Wärmebelastung einzuschätzen.';
      this.sendScore();
      this.sendState('intro');
      this.refreshInputBlock();
      var self = this;
      window.setTimeout(function () {
        if (self.mode === 'intro') {
          try { self.el.startBtn.focus({ preventScroll: true }); } catch (err) {}
        }
      }, 60);
    },

    getWorldState: function () {
      var phase = this.mode === 'complete' ? 'complete' : (this.mode === 'intro' ? 'intro' : D.phases[this.phaseIndex].id);
      return {
        phase: phase,
        observed: this.observed,
        followup: this.followup,
        tempDone: this.tempDone,
        humidityDone: this.humidityDone,
        measures: this.measures
      };
    },

    syncWorld: function () {
      if (!this.world) return;
      this.world.sync(this.getWorldState());
      this.renderTerminalMeasure();
    },

    advancePhases: function () {
      var changed = false;
      var guard = 0;
      while (guard < 6) {
        guard += 1;
        if (this.phaseIndex === 0 && this.countObserved() >= 3) {
          this.phaseIndex = 1;
          changed = true;
          continue;
        }
        if (this.phaseIndex === 1 && this.tempDone && this.humidityDone) {
          this.phaseIndex = 2;
          changed = true;
          continue;
        }
        if (this.phaseIndex === 2 && this.countMeasures() >= 3) {
          this.phaseIndex = 3;
          changed = true;
          continue;
        }
        if (this.phaseIndex === 3 && this.countFollowup() >= 3) {
          this.phaseIndex = 4;
          changed = true;
          continue;
        }
        break;
      }
      if (changed) {
        this.syncWorld();
        this.updateMissionUI();
        this.sendState('playing');
        this.audio.sfx('success');
        var phase = D.phases[this.phaseIndex];
        var info = this.phaseToast(this.phaseIndex);
        this.showToast(info.title, info.message, info.icon, 0);
      }
    },

    phaseToast: function (index) {
      if (index === 1) return { title: 'Jetzt untersuchen', message: 'Die Wetterstation steht am Weideeingang. Bediene das Display direkt am Terminal.', icon: 'thermometer' };
      if (index === 2) return { title: 'Jetzt handeln', message: 'Drei Maßnahmen stehen bereit: Schatten, Wasser und Luftbewegung.', icon: 'shade' };
      if (index === 3) return { title: 'Wirkung prüfen', message: 'Beobachte drei der Kühe erneut und vergleiche ihr Verhalten.', icon: 'eye' };
      if (index === 4) return { title: 'Daten auswerten', message: 'Gehe zur Forschungsstation südlich der Weide und schließe die Auswertung ab.', icon: 'spark' };
      return { title: 'Weiter', message: '', icon: 'info' };
    },

    countObserved: function () {
      return Object.keys(this.observed).filter(function (id) { return this.observed[id]; }, this).length;
    },

    countFollowup: function () {
      return Object.keys(this.followup).filter(function (id) { return this.followup[id]; }, this).length;
    },

    countMeasures: function () {
      return Object.keys(this.measures).filter(function (id) { return this.measures[id]; }, this).length;
    },

    interactionLabel: function (nearest) {
      if (!nearest) return '';
      if (nearest.id.indexOf('cow:') === 0) {
        var cow = nearest.marker.cow;
        var action = nearest.marker.label === 'Vergleichen' ? 'vergleichen' : 'beobachten';
        return cow.data.name + ' ' + action;
      }
      if (nearest.id === 'weather') {
        return this.world && this.world.terminalFocus ? 'Wetterstation verlassen' : 'Wetterstation bedienen (E)';
      }
      if (nearest.id === 'build:shade') return 'Schattensegel aufstellen';
      if (nearest.id === 'build:water') return 'Zusätzliche Tränke aufstellen';
      if (nearest.id === 'build:ventilation') return 'Ventilatoren einschalten';
      if (nearest.id === 'analysis') return 'Forschung auswerten';
      return nearest.label || 'Interagieren';
    },

    updatePrompt: function () {
      if (!this.world) return;
      if (this.world.terminalFocus) {
        var focusPrompt = this.el.interactionPrompt;
        this.nearest = null;
        if (this.lastPromptKey !== 'terminal-focus') {
          this.lastPromptKey = 'terminal-focus';
          this.el.promptText.textContent = 'Wetterstation verlassen (E)';
          focusPrompt.hidden = false;
          focusPrompt.classList.add('is-strong');
        }
        if (this.el.mobileInteract) {
          this.el.mobileInteract.classList.add('is-available');
          this.el.mobileInteract.setAttribute('aria-disabled', 'false');
          var focusLabel = this.el.mobileInteract.querySelector('span');
          if (focusLabel) focusLabel.textContent = 'Verlassen';
          this.el.mobileInteract.setAttribute('aria-label', 'Wetterstation verlassen');
        }
        return;
      }
      var terminalNear = !!(this.world.terminalNear && this.world.terminalAvailable);
      if (terminalNear !== this.terminalWasNear) {
        this.terminalWasNear = terminalNear;
        if (terminalNear) this.renderTerminalMeasure();
      }
      var canPrompt = (this.mode === 'playing') && !this.currentModal && !this.pauseOpen;
      var nearest = canPrompt ? this.world.getNearestInteraction() : null;
      this.nearest = nearest;
      var key = nearest ? nearest.id + '|' + nearest.marker.label : '';
      var prompt = this.el.interactionPrompt;
      if (!nearest) {
        prompt.hidden = true;
        this.lastPromptKey = '';
        if (this.el.mobileInteract) {
          this.el.mobileInteract.classList.remove('is-available');
          this.el.mobileInteract.setAttribute('aria-disabled', 'true');
          var idleLabel = this.el.mobileInteract.querySelector('span');
          if (idleLabel) idleLabel.textContent = 'Interagieren';
          this.el.mobileInteract.setAttribute('aria-label', 'Interagieren');
        }
        return;
      }
      if (this.el.mobileInteract) {
        this.el.mobileInteract.classList.add('is-available');
        this.el.mobileInteract.setAttribute('aria-disabled', 'false');
        var mobileLabel = this.el.mobileInteract.querySelector('span');
        if (mobileLabel) mobileLabel.textContent = this.mobileActionLabel(nearest);
        this.el.mobileInteract.setAttribute('aria-label', this.interactionLabel(nearest));
      }
      if (key !== this.lastPromptKey) {
        this.lastPromptKey = key;
        this.el.promptText.textContent = this.interactionLabel(nearest);
        prompt.hidden = false;
        prompt.classList.add('is-strong');
      }
    },

    mobileActionLabel: function (nearest) {
      if (!nearest) return 'Interagieren';
      if (nearest.id.indexOf('cow:') === 0) return nearest.marker.label === 'Vergleichen' ? 'Vergleichen' : 'Beobachten';
      if (nearest.id === 'weather') return 'Messen';
      if (nearest.id === 'build:shade') return 'Schatten';
      if (nearest.id === 'build:water') return 'Tränke';
      if (nearest.id === 'build:ventilation') return 'Lüftung';
      if (nearest.id === 'analysis') return 'Auswerten';
      return 'Interagieren';
    },

    hidePrompt: function () {
      this.nearest = null;
      this.lastPromptKey = '';
      this.el.interactionPrompt.hidden = true;
      this.el.mobileInteract.classList.remove('is-available');
      this.el.mobileInteract.setAttribute('aria-disabled', 'true');
      var label = this.el.mobileInteract.querySelector('span');
      if (label) label.textContent = 'Interagieren';
      this.el.mobileInteract.setAttribute('aria-label', 'Interagieren');
    },

    interact: function () {
      if (!this.world || this.mode !== 'playing' || this.currentModal || this.pauseOpen) return;
      if (this.world.terminalFocus) {
        this.world.closeTerminal();
        this.updatePrompt();
        return;
      }
      var nearest = this.world.getNearestInteraction();
      if (!nearest) return;
      if (nearest.id.indexOf('cow:') === 0) {
        this.onCowInteraction(nearest.marker.cow);
        return;
      }
      if (nearest.id === 'weather') {
        if (this.phaseIndex !== 1) return;
        if (this.world.terminalAvailable) {
          this.world.openTerminal();
          this.renderTerminalMeasure();
          this.updatePrompt();
        } else {
          this.openMeasure();
        }
        return;
      }
      if (nearest.id === 'build:shade' && this.phaseIndex === 2 && !this.measures.shade) {
        this.buildMeasure('shade');
        return;
      }
      if (nearest.id === 'build:water' && this.phaseIndex === 2 && !this.measures.water) {
        this.buildMeasure('water');
        return;
      }
      if (nearest.id === 'build:ventilation' && this.phaseIndex === 2 && !this.measures.ventilation) {
        this.buildMeasure('ventilation');
        return;
      }
      if (nearest.id === 'analysis' && this.phaseIndex === 4 && this.mode === 'playing') {
        this.completeMission();
      }
    },

    onCowInteraction: function (cow) {
      if (!cow) return;
      if (this.phaseIndex === 0 && !this.observed[cow.data.id]) {
        this.observed[cow.data.id] = true;
        this.addScore(D.score.observation);
        if (this.countObserved() === 1) this.unlockJournal('heat-signs');
        if (this.countObserved() === 2) this.unlockJournal('individual');
        this.syncWorld();
        this.updateMissionUI();
        this.audio.sfx('observe');
        this.audio.moo(0.85);
        this.audio.cowbell(0.4);
        this.openCowModal(cow, false);
        return;
      }
      if (this.phaseIndex === 3 && this.observed[cow.data.id] && !this.followup[cow.data.id]) {
        this.followup[cow.data.id] = true;
        this.addScore(D.score.followUp);
        this.syncWorld();
        this.updateMissionUI();
        this.audio.sfx('observe');
        this.audio.moo(0.85);
        this.audio.cowbell(0.4);
        this.openCowModal(cow, true);
      }
    },

    buildMeasure: function (id) {
      var measure = D.measures[id];
      if (!measure || this.measures[id] || this.phaseIndex !== 2) return;
      this.measures[id] = true;
      this.addScore(measure.score);
      this.unlockJournal(measure.journalId);
      this.syncWorld();
      this.updateMissionUI();
      this.audio.sfx('build');
      if (id === 'ventilation') this.audio.setFan(true);
      // Every measure calms the herd audibly.
      var done = (this.measures.shade ? 1 : 0) + (this.measures.water ? 1 : 0) + (this.measures.ventilation ? 1 : 0);
      this.audio.setStress(1 - done / 3);
      this.showToast(measure.title + ' umgesetzt', measure.toast, measure.icon, measure.score);
      this.advancePhases();
      this.updatePrompt();
    },

    /* -------------------------------------------------------
       Modal mechanics
       ------------------------------------------------------- */

    openModal: function (overlay, focusEl) {
      if (!overlay) return;
      this.lastFocused = document.activeElement;
      this.currentModal = overlay;
      overlay.hidden = false;
      this.refreshInputBlock();
      var self = this;
      window.setTimeout(function () {
        if (!focusEl) return;
        try { focusEl.focus({ preventScroll: true }); } catch (err) {}
      }, 40);
    },

    closeModalBase: function (overlay) {
      if (!overlay) return;
      overlay.hidden = true;
      if (this.currentModal === overlay) this.currentModal = null;
      this.refreshInputBlock();
      if (this.lastFocused && document.contains(this.lastFocused) && this.lastFocused.offsetParent !== null) {
        try { this.lastFocused.focus({ preventScroll: true }); } catch (err) {}
      }
    },

    closeTopModal: function () {
      if (this.currentModal === this.el.journalOverlay) this.closeJournal();
      else if (this.currentModal === this.el.measureOverlay) this.closeMeasure();
      else if (this.currentModal === this.el.cowOverlay) this.closeCow();
      else if (this.currentModal === this.el.debriefOverlay) this.closeDebrief();
      else if (this.currentModal === this.el.pauseOverlay) this.closePauseMenu();
    },

    closeEveryOverlay: function () {
      document.body.classList.remove('terminal-focus');
      [this.el.journalOverlay, this.el.measureOverlay, this.el.cowOverlay, this.el.debriefOverlay, this.el.pauseOverlay].forEach(function (overlay) {
        if (overlay) overlay.hidden = true;
      });
      this.currentModal = null;
      this.pauseOpen = false;
    },

    /* -------------------------------------------------------
       Journal
       ------------------------------------------------------- */

    unlockJournal: function (id) {
      if (!id || this.unlocked.has(id)) return;
      this.unlocked.add(id);
      this.newEntries.add(id);
      this.updateJournalCounter();
      if (this.currentModal === this.el.journalOverlay) this.renderJournal();
    },

    updateJournalCounter: function () {
      if (!this.el) return;
      var count = this.unlocked ? this.unlocked.size : 0;
      var total = D.journal.length;
      var pct = Math.round((count / total) * 100);
      this.el.journalCount.textContent = String(count);
      this.el.journalRing.style.setProperty('--journal-progress', pct + '%');
      var headline = 'Deine Forschung beginnt';
      if (count >= total) headline = 'Forschung komplett';
      else if (count >= 6) headline = 'Fast vollständig';
      else if (count >= 4) headline = 'Zusammenhänge erkennen';
      else if (count >= 2) headline = 'Erste Spuren';
      this.el.journalHeadline.textContent = headline;
      this.el.journalSubline.textContent = count >= total
        ? 'Alle Einträge entdeckt. Du kannst deine Erkenntnisse jederzeit nachlesen.'
        : 'Beobachte die Herde, miss das Klima und dokumentiere, was du herausfindest.';
    },

    openJournal: function () {
      if (!this.world || this.mode === 'intro' || this.currentModal || this.pauseOpen) return;
      this.renderJournal();
      this.audio.sfx('open');
      this.openModal(this.el.journalOverlay, this.el.journalClose);
    },

    renderJournal: function () {
      var self = this;
      var html = D.journal.map(function (entry) {
        if (!self.unlocked.has(entry.id)) {
          return '<article class="journal-entry is-locked">' +
            '<div class="journal-entry-icon"><svg><use href="#i-info"/></svg></div>' +
            '<div><span class="journal-entry-kicker">Noch nicht entdeckt</span><h3>???</h3>' +
            '<p>Beobachte, miss und handle, um diese Seite freizuschalten.</p></div></article>';
        }
        var points = entry.points.map(function (point) { return '<li>' + point + '</li>'; }).join('');
        var isNew = self.newEntries.has(entry.id) ? ' is-new' : '';
        return '<article class="journal-entry' + isNew + '">' +
          '<div class="journal-entry-icon"><svg><use href="#i-' + entry.icon + '"/></svg></div>' +
          '<div><span class="journal-entry-kicker">' + entry.kicker + '</span>' +
          '<h3>' + entry.title + '</h3><p>' + entry.summary + '</p>' +
          (points ? '<ul>' + points + '</ul>' : '') +
          '<span class="entry-source">' + entry.source + '</span></div></article>';
      }).join('');
      this.el.journalEntries.innerHTML = html;
      this.updateJournalCounter();
    },

    closeJournal: function () {
      if (this.currentModal !== this.el.journalOverlay) return;
      this.newEntries.clear();
      this.closeModalBase(this.el.journalOverlay);
      this.audio.sfx('tab');
      this.updatePrompt();
    },

    /* -------------------------------------------------------
       Cow observation
       ------------------------------------------------------- */

    openCowModal: function (cow, isFollowup) {
      var data = cow.data;
      var accent = data.pattern || '#c56b47';

      this.el.cowOverlay.style.setProperty('--cow-accent', accent);
      this.el.cowOverlay.style.setProperty('--cow-accent-soft', hexToRgba(accent, 0.14));
      this.el.cowOverlay.style.setProperty('--cow-base', data.color || '#f6f1e6');
      this.el.cowPortrait.innerHTML = cowPortraitSvg(data);

      this.el.cowKicker.textContent = isFollowup ? 'Vergleich · nach den Maßnahmen' : 'Beobachtung · Kuhweide';
      this.el.cowTitle.textContent = data.name;
      this.el.cowTags.innerHTML = data.tags.map(function (tag) {
        return '<span class="cow-tag">' + tag + '</span>';
      }).join('');

      // Profile tab: small illustrated facts instead of a wall of text.
      var profileFacts = [
        { icon: 'i-cow', label: 'Rasse', value: data.breed },
        { icon: 'i-info', label: 'Alter', value: data.age },
        { icon: 'i-droplet', label: 'Laktation', value: data.lactation },
        { icon: cowNeedIcon(data.need), label: 'Wichtiges Bedürfnis', value: data.need }
      ];
      this.el.cowProfileStats.innerHTML = profileFacts.map(function (fact) {
        return '<div class="cow-stat">' +
          '<span class="cow-stat-icon"><svg aria-hidden="true"><use href="#' + fact.icon + '"/></svg></span>' +
          '<span><small>' + fact.label + '</small><strong>' + fact.value + '</strong></span>' +
          '</div>';
      }).join('');

      var dots = '';
      for (var i = 1; i <= 5; i += 1) dots += '<i class="' + (i <= data.sensitivity ? 'is-on' : '') + '"></i>';
      this.el.cowSensitivityDots.innerHTML = dots;
      this.el.cowSensitivityLabel.textContent = data.sensitivityLabel;
      this.el.cowProfileHint.textContent = 'Dieselbe Hitze kann bei jeder Kuh anders ankommen. Beobachte das Tier, nicht nur den Stallwert.';

      // Behavior tab: observation text + visual comparison on follow-up.
      var observationLabel = isFollowup ? 'Vergleich nach den Maßnahmen' : 'Erste Beobachtung';
      var observationText = isFollowup ? data.after : data.before;
      this.el.cowObservation.innerHTML = '<span class="obs-label">' + observationLabel + '</span><p></p>';
      this.el.cowObservation.querySelector('p').textContent = observationText;

      if (isFollowup) {
        this.el.cowBehavior.innerHTML =
          '<div class="cow-flow">' +
            '<div class="flow-card"><small>Vor den Maßnahmen</small><strong>' + data.metric.before + '</strong></div>' +
            '<span class="flow-arrow" aria-hidden="true"><svg><use href="#i-arrow"/></svg></span>' +
            '<div class="flow-card is-after"><small>Danach</small><strong>' + data.metric.after + '</strong></div>' +
          '</div>' +
          '<div class="flow-caption">' + data.metric.label + '</div>';
      } else {
        this.el.cowBehavior.innerHTML =
          '<p class="cow-panel-hint">Beobachtungsfokus: Achte auf Atmung, Aufenthaltsort und Futteraufnahme. Vergleiche die Kuh mit ihrem Normalverhalten.</p>';
      }

      // Climate tab: metric cards + heat signs drawn as small chips.
      var metricValue = isFollowup
        ? data.metric.before + ' → ' + data.metric.after
        : data.metric.before;
      this.el.cowMetrics.innerHTML =
        '<div class="cow-metric is-wide"><span>' + data.metric.label + '</span><strong>' + metricValue + '</strong></div>';
      this.el.cowSigns.innerHTML = data.signs.map(function (sign) {
        return '<span class="cow-sign-chip"><svg aria-hidden="true"><use href="#' + cowSignIcon(sign) + '"/></svg>' + sign + '</span>';
      }).join('');

      // Science tab: why it matters, plus the FBN context.
      this.el.cowScience.textContent = data.science;
      this.el.cowScienceExtra.innerHTML =
        '<div class="cow-fact-card"><span class="cow-panel-label">FBN-Bezug</span><p>Am FBN wird untersucht, wie Klima, Haltung und Fütterung das Wohlbefinden von Nutztieren beeinflussen.</p></div>' +
        '<div class="cow-fact-card"><span class="cow-panel-label">Merksatz</span><p>Jede Kuh reagiert individuell. Beobachte das Tier – nicht nur den Stallwert.</p></div>';

      this.el.cowScoreHint.textContent = isFollowup
        ? 'Vergleich notiert · +' + Math.round(D.score.followUp / 1000 * this.platformMax) + ' Punkte'
        : 'Erste Beobachtung notiert · +' + Math.round(D.score.observation / 1000 * this.platformMax) + ' Punkte';
      this.el.cowDone.textContent = isFollowup ? 'Vergleich abschließen' : 'Beobachtung notieren';

      this.setCowTab('behavior');
      this.openModal(this.el.cowOverlay, this.el.cowDone);
      this.resetCowWindowPosition();
      var self = this;
      window.requestAnimationFrame(function () {
        if (self.currentModal === self.el.cowOverlay) self.resetCowWindowPosition();
      });
    },

    closeCow: function () {
      if (this.currentModal !== this.el.cowOverlay) return;
      this.closeModalBase(this.el.cowOverlay);
      this.advancePhases();
      this.updatePrompt();
    },

    /* -------------------------------------------------------
       Measurements
       ------------------------------------------------------- */

    openMeasure: function () {
      if (this.phaseIndex !== 1) return;
      if (this.world && this.world.terminalAvailable) {
        this.world.openTerminal();
        this.renderTerminalMeasure();
        return;
      }
      this.renderMeasure();
      this.audio.sfx('open');
      var focus = (!this.tempDone) ? this.el.measureTemp : (!this.humidityDone ? this.el.measureHumidity : this.el.measureDone);
      this.openModal(this.el.measureOverlay, focus);
    },

    takeMeasurement: function (which) {
      var directTerminal = !!(this.world && this.world.terminalAvailable && this.world.terminalFocus);
      var fallbackModal = this.currentModal === this.el.measureOverlay;
      if (!directTerminal && !fallbackModal) return;
      if (this.phaseIndex !== 1) return;
      if (which === 'temp') {
        if (this.tempDone) return;
        this.tempDone = true;
        this.addScore(D.score.measurement);
        this.audio.sfx('measure');
        this.animateValue(this.el.tempValue, 0, D.measurement.temperature, 700, function (v) { return formatNumber(v, 1) + '°C'; });
      } else {
        if (this.humidityDone) return;
        this.humidityDone = true;
        this.addScore(D.score.measurement);
        this.audio.sfx('measure');
        this.animateValue(this.el.humValue, 0, D.measurement.humidity, 700, function (v) { return formatNumber(v, 0) + '%'; });
      }
      this.renderMeasure();
      this.syncWorld();
      this.updateMissionUI();
      if (this.tempDone && this.humidityDone) {
        this.unlockJournal('thi');
        this.audio.sfx('success');
        if (directTerminal) {
          this.advancePhases();
          this.renderTerminalMeasure();
        } else {
          var self = this;
          window.setTimeout(function () {
            if (self.currentModal === self.el.measureOverlay) {
              self.el.measureDone.focus();
            }
          }, 480);
        }
      }
    },

    renderMeasure: function () {
      var temp = this.tempDone;
      var hum = this.humidityDone;
      this.el.measureTemp.classList.toggle('is-done', temp);
      this.el.measureHumidity.classList.toggle('is-done', hum);
      this.el.measureTemp.disabled = temp;
      this.el.measureHumidity.disabled = hum;
      if (temp) {
        this.el.tempValue.textContent = formatNumber(D.measurement.temperature, 1) + ' °C';
        this.el.tempAction.textContent = 'Gemessen';
      } else {
        this.el.tempValue.textContent = '—';
        this.el.tempAction.textContent = 'Messen';
      }
      if (hum) {
        this.el.humValue.textContent = formatNumber(D.measurement.humidity, 0) + ' %';
        this.el.humAction.textContent = 'Gemessen';
      } else {
        this.el.humValue.textContent = '—';
        this.el.humAction.textContent = 'Messen';
      }
      if (temp && hum) {
        this.el.thiPanel.classList.remove('is-locked');
        this.el.thiValue.textContent = formatNumber(D.measurement.thi, 1);
        this.el.thiBadge.textContent = D.measurement.classification;
        this.el.thiBadge.className = 'thi-badge is-severe';
        var pct = Math.max(4, Math.min(96, ((D.measurement.thi - 60) / 32) * 100));
        this.el.thiMarker.style.left = pct + '%';
        this.el.thiText.textContent = 'THI ' + formatNumber(D.measurement.thi, 1) + ' auf der sonnigen Weide: starke Hitzebelastung. Ab etwa 68 beginnt bei laktierenden Milchkühen eine relevante Belastung. Individuelle Unterschiede bleiben wichtig.';
        this.el.measureDone.disabled = false;
        this.el.measureDone.textContent = 'Messung abschließen';
      } else {
        this.el.thiPanel.classList.add('is-locked');
        this.el.thiValue.textContent = '—';
        this.el.thiBadge.textContent = 'noch keine Messung';
        this.el.thiBadge.className = 'thi-badge';
        this.el.thiMarker.style.left = '50%';
        this.el.thiText.textContent = 'Miss Temperatur und Luftfeuchte, um die kombinierte Wärmebelastung einzuschätzen.';
        this.el.measureDone.disabled = true;
        this.el.measureDone.textContent = 'Zurück zur Weide';
      }
      this.renderTerminalMeasure();
    },

    renderTerminalMeasure: function () {
      var t = this.terminalDom;
      if (!t) return;
      var temp = this.tempDone;
      var hum = this.humidityDone;
      var both = temp && hum;
      var measurePhase = this.phaseIndex === 1;

      t.tempValue.textContent = temp ? (formatNumber(D.measurement.temperature, 1) + '°C') : '--,-°C';
      t.humValue.textContent = hum ? (formatNumber(D.measurement.humidity, 0) + '%') : '--%';
      t.tempBtn.disabled = temp || !measurePhase;
      t.humBtn.disabled = hum || !measurePhase;
      t.tempBtn.classList.toggle('is-done', temp);
      t.humBtn.classList.toggle('is-done', hum);
      t.tempBtn.textContent = temp ? '[ GEMESSEN ]' : (!measurePhase ? '[ GESPERRT ]' : '[ TEMP. MESSEN ]');
      t.humBtn.textContent = hum ? '[ GEMESSEN ]' : (!measurePhase ? '[ GESPERRT ]' : '[ FEUCHTE MESSEN ]');

      if (both) {
        t.thiValue.textContent = formatNumber(D.measurement.thi, 1);
        t.thiBadge.textContent = 'STARKE HITZEBELASTUNG';
        t.thiBadge.classList.add('is-severe');
        var pct = Math.max(4, Math.min(96, ((D.measurement.thi - 60) / 32) * 100));
        t.thiMarker.style.left = pct + '%';
        t.thiMarker.classList.add('is-active');
        t.thiText.textContent = 'THI 84,5 auf der sonnigen Weide: starke Hitzebelastung. Ab etwa 68 beginnt bei laktierenden Milchkühen eine relevante Belastung. Individuelle Unterschiede bleiben wichtig.';
        t.hint.textContent = 'MESSUNG VOLLSTÄNDIG · E ZUM VERLASSEN';
        t.status.textContent = 'MESSUNG OK';
      } else if (!measurePhase) {
        t.thiValue.textContent = 'N/A';
        t.thiBadge.textContent = 'KEINE MESSUNG';
        t.thiBadge.classList.remove('is-severe');
        t.thiMarker.style.left = '50%';
        t.thiMarker.classList.remove('is-active');
        t.thiText.textContent = 'Temperatur und Luftfeuchte ergeben zusammen ein vollständiges Bild.';
        t.hint.textContent = 'TERMINAL GESPERRT · E ZUM VERLASSEN';
        t.status.textContent = 'GESPERRT';
      } else {
        t.thiValue.textContent = 'N/A';
        t.thiBadge.textContent = 'KEINE MESSUNG';
        t.thiBadge.classList.remove('is-severe');
        t.thiMarker.style.left = '50%';
        t.thiMarker.classList.remove('is-active');
        t.thiText.textContent = 'Temperatur und Luftfeuchte ergeben zusammen ein vollständiges Bild.';
        t.hint.textContent = temp ? 'LUFTFEUCHTE NOCH MESSEN' : (hum ? 'LUFTTEMPERATUR NOCH MESSEN' : 'BEREIT · KLICKEN ZUM MESSEN · E ZUM VERLASSEN');
        t.status.textContent = 'ONLINE';
      }
    },

    animateValue: function (el, from, to, duration, formatter) {
      if (this.reducedMotion) {
        el.textContent = formatter(to);
        return;
      }
      var start = performance.now();
      function step(now) {
        var t = Math.min(1, (now - start) / duration);
        var eased = 1 - Math.pow(1 - t, 3);
        el.textContent = formatter(from + (to - from) * eased);
        if (t < 1) requestAnimationFrame(step);
      }
      requestAnimationFrame(step);
    },

    closeMeasure: function () {
      if (this.currentModal !== this.el.measureOverlay) return;
      var complete = this.tempDone && this.humidityDone;
      this.closeModalBase(this.el.measureOverlay);
      this.advancePhases();
      if (complete) {
        this.showToast('Klima gemessen', 'Starke Wärmebelastung. Jetzt helfen Schatten, Wasser und Luftbewegung.', 'thermometer', 0);
      }
      this.updatePrompt();
    },

    /* -------------------------------------------------------
       Mission UI
       ------------------------------------------------------- */

    taskCount: function (taskId) {
      if (taskId === 'observe') return this.countObserved();
      if (taskId === 'temp') return this.tempDone ? 1 : 0;
      if (taskId === 'humidity') return this.humidityDone ? 1 : 0;
      if (taskId === 'shade') return this.measures.shade ? 1 : 0;
      if (taskId === 'water') return this.measures.water ? 1 : 0;
      if (taskId === 'ventilation') return this.measures.ventilation ? 1 : 0;
      if (taskId === 'followup') return this.countFollowup();
      if (taskId === 'analysis') return this.mode === 'complete' ? 1 : 0;
      return 0;
    },

    missionProgress: function () {
      if (this.mode === 'complete') return 100;
      var p = 0;
      p += (Math.min(3, this.countObserved()) / 3) * 25;
      p += ((this.tempDone ? 1 : 0) + (this.humidityDone ? 1 : 0)) / 2 * 15;
      p += (this.countMeasures() / 3) * 30;
      p += (Math.min(3, this.countFollowup()) / 3) * 20;
      p += this.mode === 'complete' ? 10 : 0;
      return Math.round(p);
    },

    updateMissionUI: function () {
      if (!this.el) return;
      if (this.mode === 'intro') return;
      if (this.mode === 'complete') {
        this.el.missionStepBadge.textContent = '5 / 5';
        this.el.phaseKicker.textContent = 'Abgeschlossen';
        this.el.phaseTitle.textContent = 'Hitze verstanden.';
        this.el.phaseText.textContent = 'Du hast beobachtet, gemessen, gehandelt und die Wirkung überprüft.';
        this.el.taskList.innerHTML = '<li class="task-item is-done"><span class="task-check"><svg><use href="#i-check"/></svg></span><span class="task-copy">Forschung ausgewertet<small>Deine Erkenntnisse stehen im Journal.</small></span></li>';
        this.el.missionProgressBar.style.width = '100%';
        this.el.missionProgressText.textContent = '100 %';
        return;
      }
      var phase = D.phases[this.phaseIndex];
      this.el.missionStepBadge.textContent = (this.phaseIndex + 1) + ' / 5';
      this.el.phaseKicker.textContent = phase.kicker;
      this.el.phaseTitle.textContent = phase.title;
      this.el.phaseText.textContent = phase.text;
      var firstOpen = true;
      var html = '';
      phase.tasks.forEach(function (task) {
        var count = this.taskCount(task.id);
        var done = count >= task.target;
        var isCurrent = !done && firstOpen;
        if (isCurrent) firstOpen = false;
        var countText = task.target > 1 ? ' · ' + Math.min(count, task.target) + '/' + task.target : '';
        html += '<li class="task-item' + (done ? ' is-done' : '') + (isCurrent ? ' is-current' : '') + '">' +
          '<span class="task-check"><svg><use href="#i-check"/></svg></span>' +
          '<span class="task-copy">' + task.label + countText + '<small>' + task.detail + '</small></span></li>';
      }, this);
      this.el.taskList.innerHTML = html;
      var progress = this.missionProgress();
      this.el.missionProgressBar.style.width = progress + '%';
      this.el.missionProgressText.textContent = progress + ' %';
    },

    updateLocation: function (dt) {
      if (!this.world || this.mode === 'intro') return;
      this.locationTimer -= dt;
      if (this.locationTimer > 0) return;
      this.locationTimer = 0.28;
      var location = this.world.getLocation();
      if (location !== this.lastLocation) {
        this.lastLocation = location;
        this.el.locationText.textContent = location;
        this.el.locationChip.hidden = false;
      }
    },

    /* -------------------------------------------------------
       Completion & debrief
       ------------------------------------------------------- */

    completeMission: function () {
      if (this.mode !== 'playing' || this.phaseIndex !== 4 || this.completed) return;
      this.completed = true;
      this.mode = 'complete';
      this.addScore(D.score.analysis);
      this.unlockJournal('debrief');
      this.syncWorld();
      this.updateMissionUI();
      this.updatePrompt();
      this.durationMs = Math.round(performance.now() - this.startedAt);
      this.completedAt = performance.now();
      this.sendComplete();
      this.sendState('complete');
      this.audio.sfx('complete');
      this.populateDebrief();
      this.openModal(this.el.debriefOverlay, this.el.debriefExplore);
      this.el.completePill.hidden = true;
    },

    sendComplete: function () {
      if (this.completedSent) return;
      this.completedSent = true;
      platform.send('COMPLETE', {
        points: this.reportedScore(),
        maxPoints: this.platformMax,
        durationMs: Math.max(0, Math.round(this.durationMs || 0))
      });
    },

    populateDebrief: function () {
      var display = function (n) { return Math.round((n / 1000) * this.platformMax); }.bind(this);
      this.el.debriefLead.textContent = this.playerName + ', du hast die Zeichen der Herde gelesen und die Weide an einem heißen Tag sicherer gemacht.';
      this.el.debriefScore.textContent = String(this.reportedScore());
      this.el.debriefMax.textContent = String(this.platformMax);
      this.el.debriefDuration.textContent = 'Dauer ' + formatDuration(this.durationMs || 0);
      this.el.debriefScores.innerHTML = D.score.breakdown.map(function (row) {
        return '<div class="score-line"><span>' + row.label + '</span><b>+' + display(row.value) + '</b></div>';
      }).join('') + '<div class="score-line is-total"><span>Gesamt</span><b>' + this.reportedScore() + ' / ' + this.platformMax + '</b></div>';

      var observedCows = D.cows.filter(function (cow) { return this.observed[cow.id]; }, this);
      if (!observedCows.length) observedCows = D.cows.slice(0, 3);
      this.el.debriefCows.innerHTML = observedCows.map(function (cow) {
        return '<article class="cow-result-card"><div class="cow-result-name">' + cow.name + '<span>reagiert</span></div>' +
          '<div class="cow-result-flow"><span><b>' + cow.metric.before + '</b><br>' + cow.metric.label + '</span>' +
          '<svg><use href="#i-arrow"/></svg>' +
          '<span><b>' + cow.metric.after + '</b><br>nach den Maßnahmen</span></div>' +
          '<div class="cow-result-signs">' + cow.signs.join(' · ') + '</div></article>';
      }).join('');
    },

    closeDebrief: function () {
      if (this.currentModal !== this.el.debriefOverlay) return;
      this.closeModalBase(this.el.debriefOverlay);
      this.el.completePill.hidden = false;
      this.refreshInputBlock();
      this.updatePrompt();
    },

    openDebriefAgain: function () {
      if (!this.completed || this.currentModal || this.pauseOpen) return;
      this.populateDebrief();
      this.openModal(this.el.debriefOverlay, this.el.debriefExplore);
      this.el.completePill.hidden = true;
    },

    /* -------------------------------------------------------
       Pause
       ------------------------------------------------------- */

    openPauseMenu: function (byPlatform) {
      if (this.mode === 'intro') return;
      if (byPlatform) this.platformPaused = true;
      else this.localPaused = true;
      this.refreshPauseUi();
    },

    closePauseMenu: function () {
      if (this.platformPaused) return;
      this.localPaused = false;
      this.refreshPauseUi();
      this.audio.sfx('tab');
    },

    refreshPauseUi: function () {
      var shouldPause = (this.localPaused || this.platformPaused) && this.mode !== 'intro';
      var wasOpen = this.pauseOpen;
      this.pauseOpen = shouldPause;
      if (!this.booted) return;
      if (shouldPause) {
        this.el.pauseOverlay.hidden = false;
        document.body.classList.add('pause-open');
        this.el.pauseLead.textContent = this.platformPaused
          ? 'Die Lernplattform hat das Spiel pausiert. Deine Forschung wartet.'
          : 'Die Weide wartet. Atme kurz durch.';
        this.el.pauseClose.hidden = this.platformPaused;
        this.el.pauseResume.hidden = this.platformPaused;
        this.el.pauseTitle.textContent = 'Pause';
        this.audio.pause();
        this.refreshInputBlock();
        this.updatePauseButtons();
        if (!wasOpen) {
          this.sendState('paused');
          var focus = this.platformPaused ? this.el.pauseRestart : this.el.pauseResume;
          var self = this;
          window.setTimeout(function () {
            if (self.pauseOpen) {
              try { focus.focus({ preventScroll: true }); } catch (err) {}
            }
          }, 50);
        }
      } else {
        this.el.pauseOverlay.hidden = true;
        document.body.classList.remove('pause-open');
        this.audio.resume();
        this.refreshInputBlock();
        this.updatePauseButtons();
        this.sendState(this.mode === 'complete' ? 'complete' : 'playing');
        if (this.mode === 'complete' && this.completed) this.el.completePill.hidden = false;
        var self = this;
        window.setTimeout(function () {
          if (self.pauseOpen) return;
          if (self.currentModal) {
            var target = self.currentModal.querySelector('button:not([disabled]):not([hidden])');
            if (target) target.focus({ preventScroll: true });
          } else if (self.world && self.world.renderer) {
            try { self.world.renderer.domElement.focus({ preventScroll: true }); } catch (err) {}
          }
        }, 40);
      }
    },

    updatePauseButtons: function () {
      if (!this.el) return;
      this.el.pauseSound.setAttribute('aria-pressed', String(this.soundOn));
      this.el.motionToggle.setAttribute('aria-pressed', String(this.reducedMotion));
      this.el.musicToggle.setAttribute('aria-pressed', String(this.musicOn));
      this.el.musicVolume.disabled = !this.musicOn;
      this.el.musicVolume.value = String(Math.round(this.musicLevel * 100));
      this.el.musicVolumeLabel.textContent = this.musicOn ? Math.round(this.musicLevel * 100) + ' %' : 'aus';
      var soundUse = this.el.pauseSound.querySelector('use');
      if (soundUse) soundUse.setAttribute('href', this.soundOn ? '#i-sound' : '#i-mute');
    },

    /* -------------------------------------------------------
       Sound & motion
       ------------------------------------------------------- */

    toggleSound: function () {
      this.soundOn = !this.soundOn;
      if (this.audio) {
        if (this.soundOn) {
          this.audio.setMuted(false);
          this.audio.sfx('click');
        } else {
          this.audio.sfx('click');
          this.audio.setMuted(true);
        }
      }
      this.updateSoundUi();
    },

    updateSoundUi: function () {
      if (!this.el) return;
      this.el.soundBtn.setAttribute('aria-pressed', String(this.soundOn));
      this.el.soundBtn.setAttribute('aria-label', this.soundOn ? 'Ton ausschalten' : 'Ton einschalten');
      var use = this.el.soundBtn.querySelector('use');
      if (use) use.setAttribute('href', this.soundOn ? '#i-sound' : '#i-mute');
      this.updatePauseButtons();
    },

    toggleMotion: function () {
      this.reducedMotion = !this.reducedMotion;
      document.body.classList.toggle('reduced-motion', this.reducedMotion);
      if (this.world) this.world.reducedMotion = this.reducedMotion;
      if (this.audio) this.audio.setReduced(this.reducedMotion);
      this.updateMotionUi();
    },

    updateMotionUi: function () {
      if (!this.el) return;
      this.el.motionToggle.setAttribute('aria-pressed', String(this.reducedMotion));
    },

    /* -------------------------------------------------------
       Toasts
       ------------------------------------------------------- */

    showToast: function (title, message, icon, points) {
      if (!this.el || !this.el.toastHost) return;
      var host = this.el.toastHost;
      if (host.children.length >= 3) {
        var first = host.firstElementChild;
        if (first) first.remove();
      }
      var toast = document.createElement('div');
      toast.className = 'toast' + (icon === 'droplet' ? ' toast--water' : '') + (icon === 'info' || icon === 'eye' ? ' toast--science' : '');
      toast.setAttribute('role', 'status');
      var iconWrap = document.createElement('span');
      iconWrap.className = 'toast-icon';
      iconWrap.innerHTML = '<svg><use href="#i-' + (icon || 'leaf') + '"/></svg>';
      var copy = document.createElement('span');
      copy.className = 'toast-copy';
      var strong = document.createElement('b');
      strong.textContent = title;
      var span = document.createElement('span');
      span.textContent = message || '';
      copy.appendChild(strong);
      copy.appendChild(span);
      toast.appendChild(iconWrap);
      toast.appendChild(copy);
      if (points) {
        var pointsEl = document.createElement('span');
        pointsEl.className = 'toast-points';
        pointsEl.textContent = '+' + Math.round((points / 1000) * this.platformMax);
        toast.appendChild(pointsEl);
      }
      host.appendChild(toast);
      var self = this;
      var timer = window.setTimeout(function () {
        toast.classList.add('is-leaving');
        var removeTimer = window.setTimeout(function () {
          if (toast.parentNode) toast.parentNode.removeChild(toast);
        }, 380);
        self.toastTimers.push(removeTimer);
      }, points ? 5000 : 6200);
      this.toastTimers.push(timer);
    },

    /* -------------------------------------------------------
       Misc
       ------------------------------------------------------- */

    refreshTouchMode: function () {
      var touch = window.matchMedia('(pointer: coarse)').matches || window.innerWidth <= 760;
      if (touch === this.isTouch) return;
      this.isTouch = touch;
      if (this.world && this.mode !== 'intro' && this.el) {
        this.el.desktopHint.hidden = touch;
        this.el.mobileControls.hidden = !touch;
      }
    },

    onResize: function () {
      this.refreshTouchMode();
      if (this.world) this.world.resize();
    },

    onVisibility: function () {
      this.clearInput();
      if (document.hidden && this.mode === 'playing' && !this.pauseOpen && !this.platformPaused) {
        this.openPauseMenu(false);
      }
      this.lastFrame = performance.now();
    }
  };

  // Platform listener is installed immediately so INIT is never missed.
  window.addEventListener('message', function (event) {
    var data = event.data;
    if (typeof data === 'string') {
      try { data = JSON.parse(data); } catch (err) { return; }
    }
    if (!data || data.source !== 'ntk-platform' || typeof data.type !== 'string') return;
    var payload = data.payload || {};
    if (data.type === 'INIT') {
      game.applyInit(payload);
    } else if (data.type === 'PAUSE') {
      game.setPlatformPaused(true);
    } else if (data.type === 'RESUME') {
      game.setPlatformPaused(false);
    } else if (data.type === 'RESET') {
      game.requestReset();
    }
  });

  // Exposed for diagnostics and automated quality checks; no privileged access.
  NTK.game = game;
  NTK.auditZFighting = function (options) {
    if (!game.world) return null;
    return game.world.auditZFighting(options);
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { game.boot(); });
  } else {
    game.boot();
  }
})();
