/* ============================================================
   Der Wohlfühlstall · Spielablauf, Oberfläche, Plattform-API
   ============================================================ */
(function () {
  'use strict';
  var NTK = window.NTK = window.NTK || {};
  var D = NTK.DATA;
  var G = NTK.GRID;

  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function hex(n) { return '#' + ('000000' + n.toString(16)).slice(-6); }
  var t = NTK.t;
  function emo(name) { return '<img class="emo" src="img/emoji/' + name + '.svg" alt="" draggable="false">'; }

  /* ---------- platform bridge (postMessage API v1) ---------- */
  function post(type, payload) {
    try {
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({ source: 'ntk-game', type: type, payload: payload || {} }, '*');
      }
    } catch (err) { /* standalone */ }
  }

  var game = {
    mode: 'intro',            // intro | play | done
    paused: false,
    playerName: NTK.t('defaultName'),
    hasPlayerName: false,
    platformMax: D.maxPoints,
    score: 0,
    parts: { obs: 0, build: 0, layout: 0 },
    caseIndex: -1,
    step: 'wait',             // wait | observe | build | settle | card
    phase: 'cases',           // cases | check | free
    tries: 0,
    wrong: {},
    unlocked: {},
    fresh: {},
    cards: [],
    elapsed: 0,
    completed: false,
    openPigId: null,
    nextGrunt: 6,
    labels: {},
    toastTimer: 0
  };
  NTK.game = game;

  /* ---------- scoring ---------- */
  game.platformPoints = function () {
    return Math.round(this.score * this.platformMax / D.maxPoints);
  };
  game.sendScore = function () {
    $('scoreValue').textContent = this.platformPoints();
    $('scoreMax').textContent = this.platformMax;
    post('SCORE', { points: this.platformPoints(), maxPoints: this.platformMax });
  };
  game.addScore = function (points, part) {
    this.parts[part] += points;
    this.score = Math.min(D.maxPoints, this.parts.obs + this.parts.build + this.parts.layout);
    this.sendScore();
  };

  /* ---------- layout rules ---------- */
  function gap(a, b) {
    if (!a || !b) return 99;
    var gx = Math.max(0, a.c - (b.c + b.w), b.c - (a.c + a.w));
    var gz = Math.max(0, a.r - (b.r + b.h), b.r - (a.r + a.h));
    return Math.max(gx, gz);
  }
  game.checkRules = function () {
    var r = this.world.rects();
    var slatGap = r.bed ? Math.max(0, G.SLAT_FROM - (r.bed.c + r.bed.w)) : 0;
    return {
      dry: !!r.bed && gap(r.bed, r.shower) >= 1 && gap(r.bed, r.drinker) >= 1 && slatGap >= 1,
      drain: !!r.shower && r.shower.c >= G.SLAT_FROM,
      feed: !!r.feeder2 && gap(r.feeder, r.feeder2) >= 3,
      calm: !!r.niche && gap(r.niche, r.feeder) >= 2 && gap(r.niche, r.feeder2) >= 2 && gap(r.niche, r.toy) >= 2,
      sleep: !!r.bed && gap(r.bed, r.rooting) >= 1 && gap(r.bed, r.toy) >= 1
    };
  };

  /* ---------- UI: toast ---------- */
  game.toast = function (key, vars, seconds) {
    this.toastMsg = { key: key, vars: vars || null };
    this.renderToast();
    $('toast').hidden = false;
    this.toastTimer = seconds || 3.2;
  };

  game.renderToast = function () {
    var m = this.toastMsg;
    if (!m) return;
    var vars = {}, k;
    for (k in (m.vars || {})) vars[k] = m.vars[k];
    if (vars.itemId) vars.item = D.items[vars.itemId].name;
    $('toast').textContent = t(m.key, vars);
  };

  /* ---------- UI: task panel ---------- */
  game.renderTask = function () {
    var el = $('task');
    var c = D.cases[this.caseIndex];
    var pig = c ? this.pigDef(c.pig) : null;
    var solved = this.cards.length;
    var html = '';
    if (this.phase === 'check') {
      var res = this.checkRules();
      var okCount = 0;
      html += '<p class="kicker">' + esc(t('checkKicker')) + '</p><h2>' + esc(t('checkTitle')) + '</h2>' +
        '<p>' + esc(t('checkHint')) + '</p><ul class="rules">';
      D.rules.forEach(function (rule) {
        var ok = res[rule.id];
        if (ok) okCount += 1;
        html += '<li class="' + (ok ? 'ok' : '') + '"><span class="mark" aria-hidden="true">' + (ok ? '✓' : '·') + '</span>' +
          '<span><b>' + esc(rule.title) + '</b><small>' + esc(ok ? rule.ok : rule.tip) + '</small></span></li>';
      });
      html += '</ul><button class="btn-primary" id="finishBtn" type="button">' + esc(t('finish', { ok: okCount, n: D.rules.length })) + '</button>';
    } else if (this.phase === 'free') {
      html += '<p class="kicker">' + esc(t('doneKicker')) + '</p><h2>' + esc(t('doneTitle')) + '</h2><p>' + esc(t('doneText')) + '</p>' +
        '<button class="btn-primary" id="showResult" type="button">' + esc(t('showResult')) + '</button>';
    } else {
      var caseOf = t('caseOf', { i: this.caseIndex + 1, n: D.cases.length });
      if (this.step === 'wait') {
        html += '<p class="kicker">' + esc(solved ? t('caseSolved', { n: solved }) : t('arriving')) + '</p><h2>' + esc(t('watchTitle')) + '</h2>' +
          '<p>' + esc(solved ? t('watchAfter') : t('watchFirst')) + '</p>';
      } else if (this.step === 'observe') {
        html += '<p class="kicker">' + esc(caseOf + ' · ' + t('observing')) + '</p><h2>' + esc(c.title) + '</h2>' +
          '<p>' + esc(t('somethingWrong', { name: pig.name })) + '</p>' +
          '<button class="btn-primary" id="taskObserve" type="button">' + esc(t('observePig', { name: pig.name })) + '</button>';
      } else if (this.step === 'build') {
        var item = D.items[c.item];
        html += '<p class="kicker">' + esc(caseOf + ' · ' + t('furnishing')) + '</p><h2>' + esc(item.name) + '</h2>' +
          '<p>' + esc(c.build) + '</p>' +
          '<button class="btn-primary" id="taskBuild" type="button">' + esc(t('placeItem', { item: item.name })) + '</button>';
      } else {
        html += '<p class="kicker">' + esc(caseOf) + '</p><h2>' + esc(t('letsSee')) + '</h2>' +
          '<p>' + esc(t('howReact', { name: pig.name })) + '</p>';
      }
      html += '<div class="hearts" aria-hidden="true">';
      for (var i = 0; i < D.cases.length; i += 1) html += '<span class="' + (i < solved ? 'on' : '') + '"></span>';
      html += '</div><p class="hearts-label">' + esc(t('wellbeing', { ok: solved, n: D.cases.length })) + '</p>';
    }
    el.innerHTML = html;
    var self = this;
    if ($('taskObserve')) $('taskObserve').onclick = function () { self.openPig(c.pig); };
    if ($('taskBuild')) $('taskBuild').onclick = function () { self.startPlacement(c.item); };
    if ($('finishBtn')) $('finishBtn').onclick = function () { self.finish(); };
    if ($('showResult')) $('showResult').onclick = function () { self.showOutro(); };
  };

  /* ---------- UI: toolbar ---------- */
  game.renderTools = function () {
    var el = $('tools'), self = this, html = '';
    var placing = this.world.placing ? this.world.placing.id : null;
    D.toolOrder.forEach(function (id) {
      var def = D.items[id];
      var open = !!self.unlocked[id];
      var it = self.world.items[id];
      var placed = it && it.placed;
      var cls = 'tool' + (self.fresh[id] ? ' new' : '') + (placing === id ? ' active' : '');
      html += '<button class="' + cls + '" type="button" data-tool="' + id + '"' + (open ? '' : ' disabled') +
        ' aria-label="' + esc(open ? t(placed ? 'toolMove' : 'placeItem', { item: def.name }) : t('notFound')) + '" title="' + esc(open ? def.hint : t('notFound')) + '">' +
        '<span class="ico" aria-hidden="true">' + emo(open ? def.icon : 'unknown') + '</span>' +
        '<span>' + esc(open ? (def.short || def.name) : '???') + '</span>' +
        (open ? '<span class="state">' + (self.fresh[id] ? esc(t('isNew')) : placed ? esc(t('placed')) : '') + '</span>' : '') +
        '</button>';
    });
    el.innerHTML = html;
    Array.prototype.forEach.call(el.querySelectorAll('.state'), function (s) { if (!s.textContent) s.remove(); });
    Array.prototype.forEach.call(el.querySelectorAll('button[data-tool]'), function (b) {
      b.onclick = function () { self.startPlacement(b.getAttribute('data-tool')); };
    });
  };

  /* ---------- placement ---------- */
  game.startPlacement = function (id) {
    if (this.mode === 'intro' || this.paused || !this.unlocked[id]) return;
    if (this.step === 'settle') { this.toast('toastWait'); return; }
    if (this.world.placing && this.world.placing.id === id) { this.world.cancelPlacement(); this.renderTools(); return; }
    $('journalModal').hidden = true;
    if (window.innerWidth < 700) this.closePig();
    else if (!$('pigWin').hidden) { this.pigTab = 'cam'; this.renderPig(); }
    this.world.beginPlacement(id);
    this.audio.sfx('pick');
    this.renderTools();
  };

  game.onPlacementMove = function (pl) {
    var bar = $('placeBar');
    document.body.classList.toggle('is-placing', !!pl);
    $('scene').classList.toggle('placing', !!pl);
    if (!pl) { bar.hidden = true; return; }
    bar.hidden = false;
    $('placeText').textContent = t(pl.ok ? 'tapField' : 'noRoomHere', { item: D.items[pl.id].name });
    $('placeOk').disabled = !pl.ok;
  };

  game.onPlaced = function (id) {
    var c = D.cases[this.caseIndex], self = this;
    this.audio.sfx('place');
    delete this.fresh[id];
    if (this.phase === 'cases' && this.step === 'build' && c && id === c.item) {
      this.addScore(D.points.build, 'build');
      this.step = 'settle';
      this.world.setProblem(null);
      this.world.caseStage = this.caseIndex + 1;
      var index = this.caseIndex;
      this.world.direct(c.pig, id, function () { self.showCard(index); });
      this.toast('toastNoticed', { name: this.pigDef(c.pig).name });
    }
    this.renderTools();
    this.renderTask();
    if (!$('pigWin').hidden) { this.pigTab = 'cam'; this.renderPig(); }
    post('STATE', { state: this.snapshot() });
  };

  /* ---------- cases ---------- */
  game.pigDef = function (id) {
    for (var i = 0; i < D.pigs.length; i += 1) if (D.pigs[i].id === id) return D.pigs[i];
    return null;
  };

  game.activateCase = function (i) {
    if (this.mode !== 'play' || this.phase !== 'cases') return;
    var c = D.cases[i];
    this.caseIndex = i;
    this.step = 'observe';
    this.tries = 0;
    this.wrong = {};
    this.world.caseStage = i;
    this.world.setProblem({ pigId: c.pig, kind: c.behaviour });
    this.audio.sfx('case');
    this.whyIndex = null;
    this.toast('toastCase', { name: this.pigDef(c.pig).name }, 4);
    this.renderTask();
    if (!$('pigWin').hidden) this.renderPig();
    post('STATE', { state: this.snapshot() });
  };

  game.isCasePig = function (id) {
    var c = D.cases[this.caseIndex];
    return this.phase === 'cases' && !!c && c.pig === id && (this.step === 'observe' || this.step === 'build');
  };

  game.openPig = function (id, tab) {
    if (this.mode === 'intro' || this.paused) return;
    this.openPigId = id;
    this.pigTab = tab || 'cam';
    this.audio.sfx('click');
    $('pigWin').hidden = false;
    this.renderPig();
    this.placeWindow();
  };

  game.closePig = function () {
    $('pigWin').hidden = true;
    this.openPigId = null;
    this.world.followPig = null;
    this.world.followRect = null;
  };

  // Keeps the window inside the screen; first opening picks a free corner.
  game.placeWindow = function () {
    var win = $('pigWin');
    var w = win.offsetWidth, h = win.offsetHeight;
    if (!this.winPos) {
      // Wide screens: below the task panel, where only meadow is covered.
      var wide = window.innerWidth >= 900 && window.innerWidth > window.innerHeight;
      var task = $('task').getBoundingClientRect();
      this.winPos = wide
        ? { x: 12, y: Math.max(8, Math.min(task.bottom + 10, window.innerHeight - h - 10)) }
        : { x: (window.innerWidth - w) / 2, y: 58 };
    }
    this.winPos.x = Math.max(4, Math.min(window.innerWidth - w - 4, this.winPos.x));
    this.winPos.y = Math.max(4, Math.min(Math.max(4, window.innerHeight - 60), this.winPos.y));
    win.style.transform = 'translate(' + Math.round(this.winPos.x) + 'px,' + Math.round(this.winPos.y) + 'px)';
  };

  game.bindWindowDrag = function () {
    var self = this, bar = $('pigBar'), drag = null;
    bar.addEventListener('pointerdown', function (e) {
      if (e.target.closest('button')) return;
      drag = { x: e.clientX - self.winPos.x, y: e.clientY - self.winPos.y };
      try { bar.setPointerCapture(e.pointerId); } catch (err) { /* not critical */ }
      e.preventDefault();
    });
    bar.addEventListener('pointermove', function (e) {
      if (!drag) return;
      self.winPos.x = e.clientX - drag.x;
      self.winPos.y = e.clientY - drag.y;
      self.placeWindow();
    });
    function end() { drag = null; }
    bar.addEventListener('pointerup', end);
    bar.addEventListener('pointercancel', end);
    // Keyboard: arrow keys move the window while the title bar has focus.
    bar.tabIndex = 0;
    bar.addEventListener('keydown', function (e) {
      var m = { ArrowLeft: [-24, 0], ArrowRight: [24, 0], ArrowUp: [0, -24], ArrowDown: [0, 24] }[e.key];
      if (!m) return;
      self.winPos.x += m[0]; self.winPos.y += m[1];
      self.placeWindow();
      e.preventDefault(); e.stopPropagation();
    });
  };

  game.renderPig = function () {
    var id = this.openPigId, def = this.pigDef(id), self = this;
    if (!def) return;
    var c = D.cases[this.caseIndex];
    var isCase = this.isCasePig(id);
    if (this.pigTab === 'case' && !isCase) this.pigTab = 'cam';
    var tab = this.pigTab;
    $('pigTitle').textContent = def.name;
    $('pigTrait').textContent = def.trait;
    $('pigFace').style.background = hex(def.color);

    var tabs = [{ id: 'cam', icon: 'video', label: t('tabCam') }, { id: 'info', icon: 'pigface', label: t('tabInfo') }];
    if (isCase) tabs.push({ id: 'case', icon: 'magnifier', label: t('tabCase'), dot: this.step === 'observe' && tab !== 'case' });
    $('pigTabs').innerHTML = tabs.map(function (tb) {
      return '<button class="win-tab" type="button" role="tab" data-tab="' + tb.id + '" aria-selected="' + (tb.id === tab) + '">' +
        emo(tb.icon) + '<span>' + esc(tb.label) + '</span>' + (tb.dot ? '<i class="dot" aria-hidden="true"></i>' : '') + '</button>';
    }).join('');
    Array.prototype.forEach.call($('pigTabs').querySelectorAll('[data-tab]'), function (b) {
      b.onclick = function () { self.pigTab = b.getAttribute('data-tab'); self.audio.sfx('click'); self.renderPig(); $('pigTabs').querySelector('[aria-selected="true"]').focus(); };
    });

    var html = '';
    if (tab === 'cam') {
      html = '<div class="cam" id="pigCam" aria-hidden="true"><span class="rec"><i></i>' + esc(t('live')) + '</span></div>' +
        '<p class="cam-caption">' + emo('eyes') + '<span id="pigNow"></span></p>';
      if (isCase && this.step === 'observe') html += '<button class="btn-primary" id="toCase" type="button">' + esc(t('whatMissing', { name: def.name })) + '</button>';
      if (isCase && this.step === 'build') html += '<button class="btn-primary" id="pigBuild" type="button">' + esc(t('placeItem', { item: D.items[c.item].name })) + '</button>';
    } else if (tab === 'info') {
      html = '<p class="win-about">' + esc(def.about) + '</p><p class="likes-title">' + esc(t('likes', { name: def.name })) + '</p><div class="likes">';
      def.likes.forEach(function (itemId) {
        var known = self.unlocked[itemId];
        html += '<span class="like' + (known ? '' : ' unknown') + '">' + emo(known ? D.items[itemId].icon : 'unknown') +
          (known ? esc(D.items[itemId].short || D.items[itemId].name) : esc(t('unknownYet'))) + '</span>';
      });
      html += '</div>';
    } else {
      html = '<ul class="obs">';
      c.observations.forEach(function (o) { html += '<li>' + emo(o.icon) + '<span>' + esc(o.text) + '</span></li>'; });
      html += '</ul>';
      if (this.step === 'observe') {
        html += '<p class="question">' + esc(c.question) + '</p><div class="options">';
        c.options.forEach(function (o, k) {
          html += '<button class="option" type="button" data-opt="' + k + '"' + (self.wrong[k] ? ' disabled' : '') + '>' + emo(o.icon) + '<span>' + esc(o.text) + '</span></button>';
        });
        html += '</div>';
        if (this.whyIndex != null && c.options[this.whyIndex]) html += '<p class="feedback" role="status">' + esc(c.options[this.whyIndex].why) + '</p>';
      } else {
        var right = c.options.filter(function (o) { return o.ok; })[0];
        html += '<div class="options"><button class="option right" type="button" disabled>' + emo('check') + '<span>' + esc(right.text) + '</span></button></div>' +
          '<p class="feedback good" role="status">' + esc(c.solved) + '</p>' +
          '<button class="btn-primary" id="pigBuild" type="button">' + emo(D.items[c.item].icon) + ' ' + esc(t('placeItem', { item: D.items[c.item].name })) + '</button>';
      }
    }
    var body = $('pigBody');
    body.className = 'win-body' + (tab === 'cam' ? '' : ' solid');
    body.innerHTML = html;
    this.world.followPig = tab === 'cam' ? id : null;
    this.pigNowText = null;
    Array.prototype.forEach.call(body.querySelectorAll('[data-opt]'), function (b) {
      b.onclick = function () { self.answer(Number(b.getAttribute('data-opt'))); };
    });
    if ($('toCase')) $('toCase').onclick = function () { self.pigTab = 'case'; self.renderPig(); var o = $('pigBody').querySelector('.option'); if (o) o.focus(); };
    if ($('pigBuild')) $('pigBuild').onclick = function () { self.startPlacement(c.item); };
    this.placeWindow();
  };

  // Called every frame: live caption and the screen rectangle of the camera opening.
  game.updatePigWindow = function () {
    var cam = $('pigCam');
    if ($('pigWin').hidden || !cam || !this.openPigId) { this.world.followRect = null; return; }
    var r = cam.getBoundingClientRect();
    this.world.followRect = { x: Math.round(r.left), y: Math.round(r.top), w: Math.round(r.width), h: Math.round(r.height) };
    var a = this.world.activity(this.openPigId);
    var text = this.pigDef(this.openPigId).name + ' ' + (a.key ? t(a.key) : NTK.tAct(a.label, a.vars));
    if (text !== this.pigNowText && $('pigNow')) { this.pigNowText = text; $('pigNow').textContent = text; }
  };

  game.answer = function (k) {
    var c = D.cases[this.caseIndex];
    var o = c.options[k];
    if (this.step !== 'observe' || !o) return;
    if (o.ok) {
      var pts = this.tries === 0 ? D.points.first : this.tries === 1 ? D.points.second : D.points.later;
      this.addScore(pts, 'obs');
      this.step = 'build';
      this.whyIndex = null;
      this.unlocked[c.item] = true;
      this.fresh[c.item] = true;
      this.audio.sfx('good');
      this.renderPig();
      this.renderTools();
      this.renderTask();
      if ($('pigBuild')) $('pigBuild').focus();
    } else {
      this.tries += 1;
      this.wrong[k] = true;
      this.audio.sfx('wrong');
      this.whyIndex = k;
      this.renderPig();
      var next = $('pigBody').querySelector('.option:not(:disabled)');
      if (next) next.focus();
    }
  };

  game.showCard = function (index) {
    if (this.mode !== 'play' || this.caseIndex !== index || this.step !== 'settle') return;
    var c = D.cases[index], self = this;
    this.step = 'card';
    this.cards.push(index);
    this.closeOverlays();
    if (this.world.placing) this.world.cancelPlacement();
    this.cardIndex = index;
    this.renderCard();
    $('cardModal').hidden = false;
    $('journalCount').textContent = this.cards.length;
    this.audio.sfx('card');
    $('cardNext').focus();
    this.renderTask();
  };

  game.renderCard = function () {
    var index = this.cardIndex, c = D.cases[index], self = this;
    if (!c) return;
    $('cardBody').innerHTML = '<span class="gain">' + esc(t('cardCount', { i: this.cards.length, n: D.cases.length })) + '</span>' +
      '<img class="pic" src="img/emoji/' + c.card.icon + '.svg" alt="">' +
      '<h2 id="cardTitle">' + esc(c.card.title) + '</h2>' +
      '<p class="text">' + esc(c.card.text) + '</p>' +
      '<details><summary>' + esc(t('moreInfo')) + '</summary><p class="extra">' + esc(c.card.extra) + '</p></details>' +
      '<div class="actions"><button class="btn-primary" id="cardNext" type="button">' + esc(t(index < D.cases.length - 1 ? 'next' : 'toCheck')) + '</button></div>';
    $('cardNext').onclick = function () { self.closeCard(); };
  };

  game.closeCard = function () {
    var self = this, index = this.caseIndex;
    $('cardModal').hidden = true;
    if (index < D.cases.length - 1) {
      this.step = 'wait';
      this.renderTask();
      this.world.after(3.5, function () { self.activateCase(index + 1); });
    } else {
      this.phase = 'check';
      this.step = 'wait';
      this.toast('toastAllSolved', null, 4);
      this.renderTask();
    }
    this.renderTools();
  };

  /* ---------- finish ---------- */
  game.finish = function () {
    if (this.completed || this.phase !== 'check') return;
    if (this.world.placing) this.world.cancelPlacement();
    var res = this.checkRules(), ok = 0;
    D.rules.forEach(function (rule) { if (res[rule.id]) ok += 1; });
    this.rulesOk = ok;
    this.addScore(ok * D.points.rule, 'layout');
    this.completed = true;
    this.mode = 'done';
    this.phase = 'free';
    post('COMPLETE', { points: this.platformPoints(), maxPoints: this.platformMax, durationMs: Math.round(this.elapsed * 1000) });
    post('STATE', { state: this.snapshot() });
    this.audio.sfx('finish');
    this.world.pigs.forEach(function (p) { p.say('heart', 4); });
    this.renderTask();
    this.showOutro();
  };

  game.showOutro = function () {
    var self = this;
    var pts = this.score;
    var stars = pts >= 900 ? 3 : pts >= 700 ? 2 : 1;
    var mins = Math.floor(this.elapsed / 60), secs = Math.floor(this.elapsed % 60);
    var html = '<p class="kicker">' + esc(t('outroKicker')) + '</p>' +
      '<h2 id="outroTitle">' + esc(t('wellDone', { name: this.playerName })) + '</h2>' +
      '<p class="stars" aria-label="' + esc(t('starsAria', { n: stars })) + '">' + '★★★'.slice(0, stars) + '<span class="off">' + '★★★'.slice(stars) + '</span></p>' +
      '<p class="result">' + this.platformPoints() + ' <small>' + esc(t('resultSub', { max: this.platformMax, time: mins + ':' + (secs < 10 ? '0' : '') + secs })) + '</small></p>' +
      '<ul class="breakdown">' +
      '<li><span>' + esc(t('partObs')) + '</span><b>' + this.parts.obs + ' / ' + (D.cases.length * D.points.first) + '</b></li>' +
      '<li><span>' + esc(t('partBuild')) + '</span><b>' + this.parts.build + ' / ' + (D.cases.length * D.points.build) + '</b></li>' +
      '<li><span>' + esc(t('partRules', { ok: this.rulesOk, n: D.rules.length })) + '</span><b>' + this.parts.layout + ' / ' + (D.rules.length * D.points.rule) + '</b></li>' +
      '</ul>' +
      '<p class="lead small">' + esc(t('outroText', { n: this.cards.length })) + '</p>' +
      '<div class="actions"><button class="btn-primary" id="outroWatch" type="button">' + esc(t('watchPigs')) + '</button>' +
      '<button class="btn-ghost" id="outroAgain" type="button">' + esc(t('again')) + '</button></div>';
    $('outroBody').innerHTML = html;
    $('outro').hidden = false;
    $('outroWatch').onclick = function () { $('outro').hidden = true; };
    $('outroAgain').onclick = function () { self.reset(); };
    $('outroWatch').focus();
  };

  game.renderJournal = function () {
    var html = '';
    this.cards.forEach(function (i) {
      var card = D.cases[i].card;
      html += '<details><summary>' + emo(card.icon) + ' ' + esc(card.title) + '</summary><p>' + esc(card.text) + '</p><p>' + esc(card.extra) + '</p></details>';
    });
    if (!html) html = '<p class="empty">' + esc(t('journalEmpty')) + '</p>';
    $('journalBody').innerHTML = html;
  };

  /* ---------- overlays, pause, reset ---------- */
  game.closeOverlays = function () {
    this.closePig();
    $('journalModal').hidden = true;
  };

  game.anyOverlay = function () {
    return ['intro', 'cardModal', 'journalModal', 'pauseModal', 'outro'].some(function (id) { return !$(id).hidden; });
  };

  game.setPaused = function (paused) {
    if (this.mode === 'intro') { this.paused = false; return; }
    this.paused = !!paused;
    $('pauseModal').hidden = !this.paused;
    if (this.paused) this.closePig();
    if (this.paused) {
      if (this.world.placing) this.world.cancelPlacement();
      this.audio.pause();
      $('resumeBtn').focus();
    } else {
      this.audio.resume();
    }
  };

  game.updateSettings = function () {
    var a = this.audio;
    $('soundBtn').setAttribute('aria-pressed', String(!a.muted));
    $('setSound').setAttribute('aria-pressed', String(!a.muted));
    $('setMusic').setAttribute('aria-pressed', String(a.musicOn));
    $('setVolume').disabled = !a.musicOn;
    $('setVolume').value = String(Math.round(a.musicLevel * 100));
    $('volumeLabel').textContent = a.musicOn ? Math.round(a.musicLevel * 100) + ' %' : t('off');
  };

  game.snapshot = function () {
    return { mode: this.mode, phase: this.phase, 'case': this.caseIndex + 1, step: this.step, score: this.platformPoints() };
  };

  game.setPlayer = function (name) {
    name = String(name || '').trim().slice(0, 40);
    this.hasPlayerName = !!name;
    if (!name) name = t('defaultName');
    this.playerName = name;
    var initial = name.charAt(0).toUpperCase();
    $('playerName').textContent = name;
    $('introName').textContent = name;
    $('playerAvatar').textContent = initial;
    $('introAvatar').textContent = initial;
  };

  game.reset = function () {
    this.closePig();
    this.world.reset();
    this.world.timers = [];
    this.mode = 'intro';
    this.paused = false;
    this.score = 0;
    this.parts = { obs: 0, build: 0, layout: 0 };
    this.caseIndex = -1;
    this.step = 'wait';
    this.phase = 'cases';
    this.unlocked = {}; this.fresh = {}; this.cards = []; this.wrong = {};
    this.elapsed = 0;
    this.completed = false;
    this.audio.resume();
    ['cardModal', 'journalModal', 'pauseModal', 'outro', 'toast', 'placeBar'].forEach(function (id) { $(id).hidden = true; });
    ['hud', 'task', 'tools'].forEach(function (id) { $(id).hidden = true; });
    $('intro').hidden = false;
    $('journalCount').textContent = '0';
    this.sendScore();
    post('STATE', { state: this.snapshot() });
    $('startBtn').focus();
  };

  game.start = function () {
    var self = this;
    this.audio.init();
    this.audio.requestMusic();
    this.mode = 'play';
    $('intro').hidden = true;
    ['hud', 'task', 'tools'].forEach(function (id) { $(id).hidden = false; });
    this.renderTask();
    this.renderTools();
    this.sendScore();
    this.toast('toastWelcome', { name: this.playerName }, 3);
    this.world.after(6, function () { self.activateCase(0); });
    post('STATE', { state: this.snapshot() });
  };

  /* ---------- language ---------- */
  // Static markup: data-i18n (text), data-i18n-aria (aria-label), data-i18n-title (title).
  game.applyStatic = function () {
    document.documentElement.lang = NTK.locale;
    document.title = t('docTitle');
    Array.prototype.forEach.call(document.querySelectorAll('[data-i18n]'), function (el) { el.textContent = t(el.getAttribute('data-i18n')); });
    Array.prototype.forEach.call(document.querySelectorAll('[data-i18n-aria]'), function (el) { el.setAttribute('aria-label', t(el.getAttribute('data-i18n-aria'))); });
    Array.prototype.forEach.call(document.querySelectorAll('[data-i18n-title]'), function (el) { el.setAttribute('title', t(el.getAttribute('data-i18n-title'))); });
  };

  // Switches every visible text at once; the game state stays untouched.
  game.setLocale = function (locale) {
    locale = locale === 'en' ? 'en' : 'de';
    if (locale === NTK.locale) return;
    NTK.localize(locale);
    this.applyStatic();
    if (!this.hasPlayerName) this.setPlayer('');
    if (!this.world) return;
    var focused = document.activeElement && document.activeElement.id;
    this.renderTask();
    this.renderTools();
    if (!$('pigWin').hidden) this.renderPig();
    if (!$('cardModal').hidden) this.renderCard();
    if (!$('journalModal').hidden) this.renderJournal();
    if (!$('outro').hidden) this.showOutro();
    this.updateSettings();
    if (!$('toast').hidden) this.renderToast();
    if (this.world.placing) this.onPlacementMove(this.world.placing);
    for (var id in this.labels) this.labels[id].el.setAttribute('aria-label', t('observePig', { name: this.labels[id].name }));
    if (focused && $(focused)) $(focused).focus();
    post('LOG', { level: 'info', message: 'locale ' + locale });
  };

  /* ---------- labels ---------- */
  game.buildLabels = function () {
    var self = this, host = $('labels');
    this.world.pigs.forEach(function (p) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'pig-label';
      b.innerHTML = '<span class="emote" aria-hidden="true"></span><span class="tag">' + esc(p.def.name) + '<span class="badge" aria-hidden="true">?</span></span>';
      b.setAttribute('aria-label', t('observePig', { name: p.def.name }));
      b.onclick = function () { self.openPig(p.id); };
      host.appendChild(b);
      self.labels[p.id] = { el: b, name: p.def.name, emote: b.querySelector('.emote'), text: '' };
    });
  };

  game.updateLabels = function () {
    var c = D.cases[this.caseIndex];
    var alertId = (this.mode === 'play' && this.phase === 'cases' && c && this.step === 'observe') ? c.pig : null;
    var show = this.mode !== 'intro';
    var win = $('pigWin').hidden ? null : $('pigWin').getBoundingClientRect();
    for (var i = 0; i < this.world.pigs.length; i += 1) {
      var p = this.world.pigs[i], l = this.labels[p.id];
      var s = this.world.screenPos(p);
      var covered = win && s.x > win.left - 30 && s.x < win.right + 30 && s.y > win.top - 4 && s.y < win.bottom + 50;
      l.el.style.display = show && !covered ? '' : 'none';
      l.el.style.transform = 'translate(' + Math.round(s.x) + 'px,' + Math.round(s.y) + 'px) translate(-50%,-100%)';
      l.el.classList.toggle('alert', alertId === p.id);
      var text = p.emote ? p.emote.text : '';
      if (text !== l.text) {
        l.text = text;
        l.emote.innerHTML = text ? emo(text) : '';
        l.emote.classList.toggle('on', !!text);
      }
    }
  };

  /* ---------- loop ---------- */
  var last = 0;
  function frame(now) {
    window.requestAnimationFrame(frame);
    var dt = Math.min(0.05, (now - last) / 1000 || 0);
    last = now;
    if (!game.paused) {
      game.world.update(dt);
      game.audio.update(dt);
      if (game.mode === 'play') game.elapsed += dt;
      if (game.mode !== 'intro') {
        game.nextGrunt -= dt;
        if (game.nextGrunt <= 0) { game.nextGrunt = 5 + Math.random() * 8; game.audio.sfx('grunt'); }
      }
      if (game.toastTimer > 0) {
        game.toastTimer -= dt;
        if (game.toastTimer <= 0) $('toast').hidden = true;
      }
    }
    game.updatePigWindow();
    game.updateLabels();
    game.world.render();
  }

  /* ---------- boot ---------- */
  function boot() {
    game.audio = new NTK.AudioEngine();
    game.world = new NTK.World($('scene'));
    var w = game.world;
    w.onPigClick = function (id) { game.openPig(id); };
    w.onItemClick = function (id) { if (!D.items[id].fixed) game.startPlacement(id); else game.toast('toastFixed', { itemId: id }); };
    w.onPlaced = function (id) { game.onPlaced(id); };
    w.onPlacementMove = function (pl) { game.onPlacementMove(pl); };
    w.onSound = function (name) { game.audio.sfx(name); };
    game.buildLabels();
    game.winPos = null;
    $('pigX').onclick = function () { game.closePig(); };
    game.setPlayer('');
    game.applyStatic();

    $('startBtn').onclick = function () { game.start(); };
    $('placeOk').onclick = function () { if (!w.confirmPlacement()) game.toast('toastNoRoom'); };
    $('placeCancel').onclick = function () { w.cancelPlacement(); game.renderTools(); };
    $('journalBtn').onclick = function () { game.closeOverlays(); if (w.placing) w.cancelPlacement(); game.renderJournal(); $('journalModal').hidden = false; $('journalClose').focus(); };
    $('journalClose').onclick = function () { game.closeOverlays(); };
    $('menuBtn').onclick = function () { game.setPaused(true); };
    $('resumeBtn').onclick = function () { game.setPaused(false); };
    $('restartBtn').onclick = function () { game.reset(); };
    function toggleSound() { game.audio.init(); game.audio.setMuted(!game.audio.muted); game.updateSettings(); }
    $('soundBtn').onclick = toggleSound;
    $('setSound').onclick = toggleSound;
    $('setMusic').onclick = function () { game.audio.setMusic(!game.audio.musicOn); game.updateSettings(); };
    $('setVolume').oninput = function () { game.audio.setMusic(game.audio.musicOn, Number($('setVolume').value) / 100); game.updateSettings(); };
    game.updateSettings();

    window.addEventListener('resize', function () { w.resize(); if (!$('pigWin').hidden) game.placeWindow(); });
    game.bindWindowDrag();
    window.addEventListener('keydown', function (e) {
      var key = e.key;
      if (w.placing && !game.paused) {
        var moves = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };
        if (moves[key]) { w.nudge(moves[key][0], moves[key][1]); e.preventDefault(); return; }
        if (key === 'Enter' || key === ' ') {
          if (!w.confirmPlacement()) game.toast('toastNoRoom');
          e.preventDefault();
          return;
        }
        if (key === 'Escape') { w.cancelPlacement(); game.renderTools(); e.preventDefault(); return; }
      }
      if (key === 'Escape') {
        if (!$('pigWin').hidden || !$('journalModal').hidden) { game.closeOverlays(); return; }
        if (!$('cardModal').hidden || !$('outro').hidden || game.mode === 'intro') return;
        game.setPaused(!game.paused);
      }
    });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden && game.mode === 'play' && !game.paused) game.setPaused(true);
    });

    window.addEventListener('message', function (e) {
      var d = e.data;
      if (!d || d.source !== 'ntk-platform' || typeof d.type !== 'string') return;
      var p = d.payload || {};
      switch (d.type) {
        case 'INIT':
          if (p.player && p.player.name) game.setPlayer(p.player.name);
          if (p.locale) game.setLocale(p.locale);
          if (p.game && Number(p.game.maxPoints) > 0) game.platformMax = Math.round(Number(p.game.maxPoints));
          $('scoreMax').textContent = game.platformMax;
          $('scoreValue').textContent = game.platformPoints();
          post('READY', {});
          break;
        case 'LOCALE': if (p.locale) game.setLocale(p.locale); break;
        case 'PAUSE': game.setPaused(true); break;
        case 'RESUME': game.setPaused(false); break;
        case 'RESET': game.reset(); break;
      }
    });

    game.booted = true;
    window.requestAnimationFrame(frame);
    post('READY', {});
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
