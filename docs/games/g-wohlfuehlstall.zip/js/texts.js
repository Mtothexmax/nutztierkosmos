/* ============================================================
   Der Wohlfühlstall · Texte in Deutsch und Englisch
   NTK.TEXTS = { de: {...}, en: {...} }
   NTK.t(key, vars)     Text der Oberfläche in der aktuellen Sprache
   NTK.localize(locale) setzt die Sprache und füllt NTK.DATA
   ============================================================ */
(function () {
  'use strict';
  var NTK = window.NTK = window.NTK || {};

  var de = {
    ui: {
      docTitle: 'Nutztierkosmos · Der Wohlfühlstall',
      defaultName: 'Forscher:in',
      pigsAria: 'Schweine', scoreAria: 'Punkte', playerTitle: 'Spieler:in',
      journalBtn: 'Wissen', soundAria: 'Ton an oder aus', menuAria: 'Menü und Pause', toolsAria: 'Einrichtung',
      placeOk: 'Hier hinstellen', placeCancel: 'Abbrechen',
      introKicker: 'Forschungsauftrag · Schwein', introTitle: 'Der Wohlfühlstall',
      introLead: 'Vier Schweine, vier Charaktere – und eine ziemlich kahle Bucht. Schau genau hin, finde heraus, was den Tieren fehlt, und richte ihren Stall Schritt für Schritt ein.',
      welcomeTeam: 'Willkommen im Forschungsteam',
      step1: 'Beobachten', step1Sub: 'Was tut das Tier?',
      step2: 'Verstehen', step2Sub: 'Was fehlt ihm?',
      step3: 'Einrichten', step3Sub: 'Was hilft wirklich?',
      start: 'Zum Stall',
      introMeta: 'ca. 8–10 Minuten · Maus, Touch oder Tastatur · ganz ohne Zeitdruck',
      howto: 'So wird gespielt',
      howto1: 'Tippe ein Schwein an, um es zu beobachten.',
      howto2: 'Wähle unten ein Einrichtungsteil und setze es auf ein Feld. Stehende Teile kannst du antippen und umstellen.',
      howto3: 'Ziehen dreht die Ansicht, das Mausrad zoomt.',
      howto4: 'Tastatur: Tab wechselt, Pfeiltasten verschieben, Enter bestätigt, Esc bricht ab.',
      winDrag: 'Ziehen zum Verschieben', winClose: 'Fenster schließen',
      journalKicker: 'Deine Sammlung', journalTitle: 'Wissenskarten', close: 'Schließen',
      journalEmpty: 'Noch keine Karten. Löse den ersten Fall, um deine Sammlung zu beginnen.',
      pauseKicker: 'Pause', pauseTitle: 'Kurz durchatmen', pauseLead: 'Die Schweine warten auf dich.',
      resume: 'Weiter', sound: 'Ton', music: 'Musik', volume: 'Musiklautstärke', off: 'aus', restart: 'Neu beginnen',

      checkKicker: 'Stall-Check', checkTitle: 'Passt alles zusammen?', checkHint: 'Tippe Einrichtung an, um sie umzustellen.',
      finish: 'Stall abschließen ({ok} von {n})',
      doneKicker: 'Geschafft', doneTitle: 'Dein Wohlfühlstall', doneText: 'Schau den Schweinen ruhig noch eine Weile zu.',
      showResult: 'Ergebnis ansehen',
      caseSolved: 'Fall {n} gelöst', arriving: 'Ankommen', watchTitle: 'Schau der Gruppe zu',
      watchAfter: 'Die Schweine nehmen das Neue an. Gleich fällt dir wieder etwas auf.',
      watchFirst: 'Lerne die vier kennen: Tippe ein Schwein an, um mehr zu erfahren.',
      caseOf: 'Fall {i} von {n}', observing: 'Beobachten', furnishing: 'Einrichten',
      somethingWrong: 'Bei {name} stimmt etwas nicht. Schau genau hin.',
      observePig: '{name} beobachten', placeItem: '{item} platzieren',
      letsSee: 'Mal sehen …', howReact: 'Wie reagiert {name} auf die Veränderung?',
      wellbeing: 'Wohlbefinden der Gruppe: {ok} von {n}',
      toolMove: '{item} umstellen', notFound: 'Noch nicht entdeckt', isNew: 'neu', placed: 'steht',
      tapField: '{item}: Feld antippen oder Enter', noRoomHere: '{item}: Hier ist kein Platz',
      tabCam: 'Kamera', tabInfo: 'Steckbrief', tabCase: 'Was fehlt?', live: 'LIVE',
      whatMissing: 'Was fehlt {name}?', likes: 'Das mag {name}', unknownYet: 'noch unbekannt',
      cardCount: 'Wissenskarte {i} von {n}', moreInfo: 'Noch mehr wissen', next: 'Weiter', toCheck: 'Zum Stall-Check',
      outroKicker: 'Forschungsauftrag abgeschlossen', wellDone: 'Gut gemacht, {name}!',
      starsAria: '{n} von 3 Sternen', resultSub: 'von {max} Punkten · {time} min',
      partObs: 'Verhalten richtig gedeutet', partBuild: 'Stall eingerichtet', partRules: 'Stall-Check: {ok} von {n} Regeln',
      outroText: 'Du hast gesehen: Verhalten verrät, was ein Tier braucht – und jedes Schwein ist ein bisschen anders. Deine {n} Wissenskarten findest du oben unter „Wissen“.',
      watchPigs: 'Den Schweinen zuschauen', again: 'Nochmal spielen',

      toastWait: 'Einen Moment – schau erst, was passiert.',
      toastNoticed: '{name} hat es schon bemerkt …',
      toastCase: 'Dir fällt etwas auf: {name} verhält sich ungewöhnlich.',
      toastAllSolved: 'Alle sechs Fälle gelöst. Jetzt der Feinschliff!',
      toastWelcome: 'Willkommen im Stall, {name}!',
      toastNoRoom: 'Hier ist kein Platz.',
      toastFixed: '{item}: fest eingebaut.',
      actMoving: 'ist unterwegs', actIdle: 'schaut sich um'
    },
    act: null,   // German activity texts are the source strings in world.js
    pigs: {
      emma: { trait: 'neugierig', about: 'Untersucht alles Neue zuerst – mit dem Rüssel.' },
      bruno: { trait: 'vorsichtig', about: 'Hält Abstand und schaut erst zu. Steht im Rang weit unten.' },
      lotte: { trait: 'gesellig', about: 'Liegt am liebsten dicht bei den anderen.' },
      frieda: { trait: 'lebhaft', about: 'Viel unterwegs – und danach sehr müde.' }
    },
    items: {
      feeder: { name: 'Trog' },
      drinker: { name: 'Tränke' },
      rooting: { name: 'Wühlbereich', hint: 'Stroh zum Wühlen, Kauen und Erkunden' },
      feeder2: { name: 'Zweiter Trog', hint: 'Ein weiterer Fressplatz' },
      shower: { name: 'Schweinedusche', short: 'Dusche', hint: 'Feiner Wasserregen zum Abkühlen' },
      bed: { name: 'Strohbett', hint: 'Weich und trocken zum Liegen' },
      niche: { name: 'Rückzugsnische', short: 'Nische', hint: 'Sichtschutz für ruhige Minuten' },
      toy: { name: 'Spielbalken', hint: 'Holz und Seil zum Kauen und Ziehen' }
    },
    cases: [
      {
        title: 'Emma und die Gitterstange',
        observations: ['Beißt in die Gitterstange', 'Knabbert an Schwänzen und Ohren', 'Nichts zum Wühlen da'],
        question: 'Was fehlt Emma?',
        options: [
          { text: 'Mehr Futter im Trog', why: 'Der Trog ist gut gefüllt und Emma frisst normal. Hunger ist es nicht.' },
          { text: 'Etwas zum Wühlen und Erkunden' },
          { text: 'Sie will die anderen ärgern', why: 'Schweine beißen nicht aus Bosheit. Das Knabbern ist umgelenktes Erkunden: Der Rüssel sucht Arbeit.' }
        ],
        solved: 'Genau. Emmas Rüssel braucht eine Aufgabe.',
        build: 'Stelle einen Wühlbereich mit Stroh in die Bucht.',
        card: {
          title: 'Der Rüssel braucht Arbeit',
          text: 'Schweine erkunden ihre Welt mit dem Rüssel. Im Freien verbringen sie den größten Teil ihrer aktiven Zeit mit Wühlen, Schnüffeln und Kauen. Fehlt dafür Material, richtet sich das Verhalten auf Stangen – oder auf die Schwänze der anderen.',
          extra: 'Schwanzbeißen hat mehrere Ursachen. Fehlende Beschäftigung ist eine der wichtigsten.'
        }
      },
      {
        title: 'Bruno kommt zu kurz',
        observations: ['Dreht vor dem Trog wieder ab', 'Wartet mit gesenktem Kopf', 'Am Trog ist nur wenig Platz'],
        question: 'Was würde Bruno helfen?',
        options: [
          { text: 'Ein weiterer Fressplatz mit Abstand' },
          { text: 'Nichts – er hat keinen Hunger', why: 'Bruno läuft immer wieder Richtung Trog. Er möchte fressen, traut sich aber nicht.' },
          { text: 'Ein anderes Futter', why: 'Am Futter liegt es nicht, die anderen fressen es gern. Bruno wird verdrängt.' }
        ],
        solved: 'Richtig. Bruno braucht einen Platz, an dem ihn niemand wegschiebt.',
        build: 'Stelle einen zweiten Trog auf – am besten nicht direkt neben den ersten.',
        card: {
          title: 'Rangordnung am Trog',
          text: 'In jeder Schweinegruppe gibt es eine Rangordnung. Ranghohe Tiere fressen zuerst, rangniedere weichen aus. Gibt es zu wenige Fressplätze, fressen vorsichtige Tiere unter Stress oder bekommen zu wenig ab.',
          extra: 'Aus der Forschung: Am FBN haben Schweine gelernt, auf einen eigenen Namen zu hören und einzeln zum Futter zu kommen. So entsteht kein Gedränge.'
        }
      },
      {
        title: 'Lotte liegt abseits',
        observations: ['Mittag: liegt ausgestreckt, weit weg', 'Atmet sehr schnell', 'Sucht den kühlsten Boden'],
        question: 'Was braucht Lotte jetzt?',
        options: [
          { text: 'Mehr Stroh zum Einkuscheln', why: 'Stroh wärmt. Bei Hitze würde das alles nur schlimmer machen.' },
          { text: 'Ruhe – sie will allein sein', why: 'Lotte ist sonst die Geselligste. Sie hält Abstand, weil Körperkontakt wärmt.' },
          { text: 'Eine Möglichkeit, sich abzukühlen' }
        ],
        solved: 'Ja. Lotte ist zu warm – und sie kann nicht schwitzen.',
        build: 'Baue eine Schweinedusche ein. Wo kann das Wasser gut ablaufen?',
        card: {
          title: 'Schweine können nicht schwitzen',
          text: 'Schweine haben kaum Schweißdrüsen, die sie kühlen könnten. Wird es warm, legen sie sich ausgestreckt auf kühlen Boden, halten Abstand zueinander und atmen schneller.',
          extra: 'Draußen suhlen sie sich im Schlamm: Das Verdunsten kühlt, und die Schlammschicht schützt die Haut vor Sonne und Insekten.'
        }
      },
      {
        title: 'Frieda findet keine Ruhe',
        observations: ['Legt sich hin, steht wieder auf', 'Probiert immer neue Stellen', 'Boden ist hart und feucht'],
        question: 'Was fehlt Frieda?',
        options: [
          { text: 'Mehr Bewegung', why: 'Frieda war den ganzen Vormittag unterwegs. Sie ist müde, findet aber keinen guten Platz.' },
          { text: 'Ein weicher, trockener Liegeplatz' },
          { text: 'Dunkelheit zum Schlafen', why: 'Schweine dösen auch am hellen Tag. Das Licht stört Frieda nicht – der Untergrund schon.' }
        ],
        solved: 'Stimmt. Frieda will schlafen, aber nicht auf hartem, nassem Boden.',
        build: 'Richte ein Strohbett ein. Achte darauf, dass es dort trocken bleibt.',
        card: {
          title: 'Ordnung im Schweinestall',
          text: 'Schweine ruhen einen großen Teil des Tages – am liebsten weich, trocken und gemeinsam. Haben sie genug Platz und eine klare Struktur, trennen sie selbst zwischen Liegen, Fressen und Koten.',
          extra: 'Ihr Schlafplatz bleibt dann sauber. Schweine sind von Natur aus reinliche Tiere.'
        }
      },
      {
        title: 'Bruno schreckt auf',
        observations: ['Zuckt zusammen, wenn jemand kommt', 'Flüchtet quer durch die Bucht', 'Ist überall im Blick der anderen'],
        question: 'Was würde Bruno helfen?',
        options: [
          { text: 'Ein Rückzugsort mit Sichtschutz' },
          { text: 'Abwarten – er gewöhnt sich daran', why: 'Wer nicht ausweichen kann, bleibt dauerhaft angespannt. Abwarten allein löst das nicht.' },
          { text: 'Eine eigene Bucht nur für Bruno', why: 'Schweine sind soziale Tiere. Allein zu sein wäre für Bruno noch belastender.' }
        ],
        solved: 'Genau. Bruno braucht einen Ort, an dem er aus dem Blick ist.',
        build: 'Stelle eine Rückzugsnische auf – möglichst abseits vom Trubel.',
        card: {
          title: 'Ausweichen können',
          text: 'Tiere einer Art sind nicht alle gleich: Manche Schweine sind forsch, andere vorsichtig. Für vorsichtige und rangniedere Tiere ist es wichtig, anderen aus dem Weg gehen zu können.',
          extra: 'Trennwände und Nischen unterbrechen den Blickkontakt. Das senkt Stress, und Streit endet schneller.'
        }
      },
      {
        title: 'Emma langweilt sich wieder',
        observations: ['Schnüffelt nur kurz am Stroh', 'Knabbert wieder an den anderen', 'Stroh liegt seit Tagen gleich da'],
        question: 'Was braucht Emma?',
        options: [
          { text: 'Das Stroh wieder wegnehmen', why: 'Dann hätte Emma gar nichts mehr. Sie braucht nicht weniger, sondern etwas anderes.' },
          { text: 'Nichts – sie hat doch Stroh', why: 'Emmas Knabbern zeigt das Gegenteil: Ihr Erkundungsdrang ist nicht gestillt.' },
          { text: 'Abwechslung: Neues zum Kauen' }
        ],
        solved: 'Richtig. Für ein neugieriges Schwein wird Gewohntes schnell langweilig.',
        build: 'Hänge einen Spielbalken mit Seil auf.',
        card: {
          title: 'Neu ist spannend',
          text: 'Beschäftigungsmaterial wird uninteressant, wenn es sich nie verändert. Gut ist Material, das Schweine kauen, bewühlen, verändern und zum Teil fressen können – etwa Stroh, Heu, weiches Holz oder Naturseile.',
          extra: 'Wer regelmäßig wechselt oder frisch nachlegt, hält die Neugier wach.'
        }
      }
    ],
    rules: {
      dry: { title: 'Trockener Liegeplatz', ok: 'Das Strohbett liegt abseits von Wasser und Spaltenboden.', tip: 'Das Strohbett grenzt an eine nasse Stelle (Dusche, Tränke oder Spaltenboden). Schweine liegen gern trocken.' },
      drain: { title: 'Dusche über dem Spaltenboden', ok: 'Das Duschwasser läuft durch die Spalten ab.', tip: 'Die Dusche steht auf dem festen Boden. Über dem Spaltenboden (rechts) kann das Wasser ablaufen.' },
      feed: { title: 'Fressplätze mit Abstand', ok: 'Zwischen den Trögen ist genug Platz zum Ausweichen.', tip: 'Die beiden Tröge stehen zu dicht beieinander. Mit mindestens drei Feldern Abstand kann Bruno in Ruhe fressen.' },
      calm: { title: 'Ruhiger Rückzug', ok: 'Die Nische liegt abseits von Trog und Spielbalken.', tip: 'Die Rückzugsnische steht zu nah an einem Trog oder am Spielbalken. Dort ist zu viel los.' },
      sleep: { title: 'Toben stört nicht beim Schlafen', ok: 'Wühlbereich und Spielbalken liegen nicht direkt am Strohbett.', tip: 'Wühlbereich oder Spielbalken grenzen ans Strohbett. Wer döst, wird dort ständig gestört.' }
    }
  };

  var en = {
    ui: {
      docTitle: 'Nutztierkosmos · The Happy Pig Pen',
      defaultName: 'Researcher',
      pigsAria: 'Pigs', scoreAria: 'Points', playerTitle: 'Player',
      journalBtn: 'Facts', soundAria: 'Sound on or off', menuAria: 'Menu and pause', toolsAria: 'Furnishings',
      placeOk: 'Place here', placeCancel: 'Cancel',
      introKicker: 'Research mission · Pigs', introTitle: 'The Happy Pig Pen',
      introLead: 'Four pigs, four characters – and a rather bare pen. Watch closely, work out what the animals are missing, and furnish their pen step by step.',
      welcomeTeam: 'Welcome to the research team',
      step1: 'Observe', step1Sub: 'What is the animal doing?',
      step2: 'Understand', step2Sub: 'What is it missing?',
      step3: 'Furnish', step3Sub: 'What really helps?',
      start: 'Go to the pen',
      introMeta: 'approx. 8–10 minutes · mouse, touch or keyboard · no time pressure',
      howto: 'How to play',
      howto1: 'Tap a pig to observe it.',
      howto2: 'Pick a furnishing below and place it on a tile. Tap a placed item to move it.',
      howto3: 'Drag to rotate the view, use the mouse wheel to zoom.',
      howto4: 'Keyboard: Tab switches, arrow keys move, Enter confirms, Esc cancels.',
      winDrag: 'Drag to move', winClose: 'Close window',
      journalKicker: 'Your collection', journalTitle: 'Fact cards', close: 'Close',
      journalEmpty: 'No cards yet. Solve the first case to start your collection.',
      pauseKicker: 'Pause', pauseTitle: 'Take a breath', pauseLead: 'The pigs are waiting for you.',
      resume: 'Continue', sound: 'Sound', music: 'Music', volume: 'Music volume', off: 'off', restart: 'Start over',

      checkKicker: 'Pen check', checkTitle: 'Does it all fit together?', checkHint: 'Tap a furnishing to move it.',
      finish: 'Finish the pen ({ok} of {n})',
      doneKicker: 'Done', doneTitle: 'Your happy pig pen', doneText: 'Feel free to watch the pigs a little longer.',
      showResult: 'View result',
      caseSolved: 'Case {n} solved', arriving: 'Settling in', watchTitle: 'Watch the group',
      watchAfter: 'The pigs are taking to the new addition. You will soon notice something else.',
      watchFirst: 'Get to know the four: tap a pig to learn more.',
      caseOf: 'Case {i} of {n}', observing: 'Observe', furnishing: 'Furnish',
      somethingWrong: 'Something is not right with {name}. Watch closely.',
      observePig: 'Observe {name}', placeItem: 'Place {item}',
      letsSee: 'Let’s see …', howReact: 'How does {name} react to the change?',
      wellbeing: 'Group well-being: {ok} of {n}',
      toolMove: 'Move {item}', notFound: 'Not discovered yet', isNew: 'new', placed: 'placed',
      tapField: '{item}: tap a tile or press Enter', noRoomHere: '{item}: no room here',
      tabCam: 'Camera', tabInfo: 'Profile', tabCase: 'Missing?', live: 'LIVE',
      whatMissing: 'What is {name} missing?', likes: '{name} likes', unknownYet: 'not known yet',
      cardCount: 'Fact card {i} of {n}', moreInfo: 'Learn more', next: 'Continue', toCheck: 'Go to the pen check',
      outroKicker: 'Research mission complete', wellDone: 'Well done, {name}!',
      starsAria: '{n} of 3 stars', resultSub: 'of {max} points · {time} min',
      partObs: 'Behaviour read correctly', partBuild: 'Pen furnished', partRules: 'Pen check: {ok} of {n} rules',
      outroText: 'You have seen that behaviour reveals what an animal needs – and every pig is a little different. You will find your {n} fact cards under “Facts” at the top.',
      watchPigs: 'Watch the pigs', again: 'Play again',

      toastWait: 'Just a moment – see what happens first.',
      toastNoticed: '{name} has already noticed …',
      toastCase: 'You notice something: {name} is behaving unusually.',
      toastAllSolved: 'All six cases solved. Now for the finishing touches!',
      toastWelcome: 'Welcome to the pen, {name}!',
      toastNoRoom: 'There is no room here.',
      toastFixed: '{item}: permanently installed.',
      actMoving: 'is on the move', actIdle: 'is looking around'
    },
    /* Activity texts: German source string from world.js -> English */
    act: {
      'frisst am Trog': 'is eating at the trough',
      'frisst am zweiten Trog': 'is eating at the second trough',
      'trinkt an der Tränke': 'is drinking at the drinker',
      'wühlt im Stroh': 'is rooting in the straw',
      'döst im Strohbett': 'is dozing in the straw bed',
      'steht unter der Dusche': 'is standing under the shower',
      'ruht in der Nische': 'is resting in the retreat',
      'zieht am Spielbalken': 'is tugging at the play beam',
      'läuft durch die Bucht': 'is walking around the pen',
      'knabbert an {name}': 'is nibbling at {name}',
      'weicht aus': 'is moving out of the way',
      'beißt in die Gitterstange': 'is biting the fence bar',
      'schnüffelt lustlos am Stroh': 'sniffs at the straw without interest',
      'traut sich nicht an den Trog': 'does not dare to go to the trough',
      'wartet mit gesenktem Kopf in der Ecke': 'is waiting in the corner, head down',
      'liegt ausgestreckt und atmet schnell': 'is lying stretched out, breathing fast',
      'sucht einen Liegeplatz': 'is looking for a place to lie down',
      'steht angespannt da': 'is standing there tensely',
      'flüchtet': 'is running away',
      'döst auf dem Boden': 'is dozing on the floor'
    },
    pigs: {
      emma: { trait: 'curious', about: 'Checks out anything new first – with her snout.' },
      bruno: { trait: 'cautious', about: 'Keeps his distance and watches first. Ranks low in the group.' },
      lotte: { trait: 'sociable', about: 'Likes to lie close to the others.' },
      frieda: { trait: 'lively', about: 'Always on the go – and very tired afterwards.' }
    },
    items: {
      feeder: { name: 'Trough' },
      drinker: { name: 'Drinker' },
      rooting: { name: 'Rooting area', hint: 'Straw for rooting, chewing and exploring' },
      feeder2: { name: 'Second trough', hint: 'One more feeding place' },
      shower: { name: 'Pig shower', short: 'Shower', hint: 'A fine spray of water for cooling down' },
      bed: { name: 'Straw bed', hint: 'Soft and dry for lying down' },
      niche: { name: 'Retreat', hint: 'A screen for quiet minutes' },
      toy: { name: 'Play beam', hint: 'Wood and rope for chewing and tugging' }
    },
    cases: [
      {
        title: 'Emma and the fence bar',
        observations: ['Bites the fence bar', 'Nibbles at tails and ears', 'Nothing to root in'],
        question: 'What is Emma missing?',
        options: [
          { text: 'More feed in the trough', why: 'The trough is well filled and Emma eats normally. It is not hunger.' },
          { text: 'Something to root in and explore' },
          { text: 'She wants to annoy the others', why: 'Pigs do not bite out of spite. The nibbling is redirected exploring: the snout is looking for work.' }
        ],
        solved: 'Exactly. Emma’s snout needs a job.',
        build: 'Put a rooting area with straw in the pen.',
        card: {
          title: 'The snout needs work',
          text: 'Pigs explore their world with their snout. Outdoors they spend most of their active time rooting, sniffing and chewing. If there is no material for this, the behaviour turns to bars – or to the tails of the others.',
          extra: 'Tail biting has several causes. A lack of things to do is one of the most important.'
        }
      },
      {
        title: 'Bruno misses out',
        observations: ['Turns away before the trough', 'Waits with his head down', 'Little space at the trough'],
        question: 'What would help Bruno?',
        options: [
          { text: 'Another feeding place further away' },
          { text: 'Nothing – he is not hungry', why: 'Bruno keeps walking towards the trough. He wants to eat but does not dare.' },
          { text: 'A different feed', why: 'The feed is not the problem – the others like it. Bruno is being pushed away.' }
        ],
        solved: 'Right. Bruno needs a place where nobody pushes him away.',
        build: 'Set up a second trough – ideally not right next to the first one.',
        card: {
          title: 'Rank at the trough',
          text: 'Every group of pigs has a rank order. High-ranking animals eat first, low-ranking ones give way. If there are too few feeding places, cautious animals eat under stress or do not get enough.',
          extra: 'From research: at the FBN, pigs learned to respond to their own name and come to the feed one at a time. That prevents crowding.'
        }
      },
      {
        title: 'Lotte lies apart',
        observations: ['Midday: lies stretched out, far away', 'Breathes very fast', 'Seeks the coolest floor'],
        question: 'What does Lotte need now?',
        options: [
          { text: 'More straw to snuggle into', why: 'Straw keeps you warm. In the heat it would only make things worse.' },
          { text: 'Quiet – she wants to be alone', why: 'Lotte is usually the most sociable. She keeps her distance because body contact is warm.' },
          { text: 'A way to cool down' }
        ],
        solved: 'Yes. Lotte is too warm – and she cannot sweat.',
        build: 'Install a pig shower. Where can the water drain away well?',
        card: {
          title: 'Pigs cannot sweat',
          text: 'Pigs have hardly any sweat glands that could cool them. When it gets warm, they lie stretched out on a cool floor, keep apart from each other and breathe faster.',
          extra: 'Outdoors they wallow in mud: evaporation cools them, and the layer of mud protects the skin from sun and insects.'
        }
      },
      {
        title: 'Frieda cannot settle',
        observations: ['Lies down, gets up again', 'Keeps trying new spots', 'The floor is hard and damp'],
        question: 'What is Frieda missing?',
        options: [
          { text: 'More exercise', why: 'Frieda has been on the move all morning. She is tired but cannot find a good spot.' },
          { text: 'A soft, dry place to lie' },
          { text: 'Darkness for sleeping', why: 'Pigs also doze in broad daylight. The light does not bother Frieda – the floor does.' }
        ],
        solved: 'Correct. Frieda wants to sleep, but not on a hard, wet floor.',
        build: 'Set up a straw bed. Make sure it stays dry there.',
        card: {
          title: 'Order in the pig pen',
          text: 'Pigs rest for a large part of the day – preferably soft, dry and together. If they have enough space and a clear layout, they separate lying, feeding and dunging areas themselves.',
          extra: 'Their sleeping place then stays clean. Pigs are clean animals by nature.'
        }
      },
      {
        title: 'Bruno gets startled',
        observations: ['Flinches when someone comes near', 'Flees right across the pen', 'Always in view of the others'],
        question: 'What would help Bruno?',
        options: [
          { text: 'A retreat with a visual screen' },
          { text: 'Wait – he will get used to it', why: 'An animal that cannot get out of the way stays tense. Waiting alone does not solve that.' },
          { text: 'A pen of his own, just for Bruno', why: 'Pigs are social animals. Being alone would be even more stressful for Bruno.' }
        ],
        solved: 'Exactly. Bruno needs a place where he is out of sight.',
        build: 'Set up a retreat – as far from the bustle as possible.',
        card: {
          title: 'Being able to get away',
          text: 'Animals of one species are not all alike: some pigs are bold, others cautious. For cautious and low-ranking animals it is important to be able to avoid others.',
          extra: 'Partitions and niches break eye contact. That lowers stress, and fights end sooner.'
        }
      },
      {
        title: 'Emma is bored again',
        observations: ['Only sniffs briefly at the straw', 'Nibbles at the others again', 'Straw unchanged for days'],
        question: 'What does Emma need?',
        options: [
          { text: 'Take the straw away again', why: 'Then Emma would have nothing at all. She does not need less, she needs something different.' },
          { text: 'Nothing – she has straw', why: 'Emma’s nibbling shows the opposite: her urge to explore is not satisfied.' },
          { text: 'Variety: something new to chew' }
        ],
        solved: 'Right. For a curious pig, familiar things quickly become boring.',
        build: 'Hang up a play beam with a rope.',
        card: {
          title: 'New is exciting',
          text: 'Enrichment material becomes uninteresting if it never changes. Good material is something pigs can chew, root in, change and partly eat – such as straw, hay, soft wood or natural ropes.',
          extra: 'Changing it regularly or topping it up keeps their curiosity alive.'
        }
      }
    ],
    rules: {
      dry: { title: 'A dry place to lie', ok: 'The straw bed is away from water and the slatted floor.', tip: 'The straw bed is next to a wet spot (shower, drinker or slatted floor). Pigs like to lie dry.' },
      drain: { title: 'Shower above the slatted floor', ok: 'The shower water drains through the slats.', tip: 'The shower is on the solid floor. Above the slatted floor (right) the water can drain away.' },
      feed: { title: 'Feeding places apart', ok: 'There is enough room between the troughs to get out of the way.', tip: 'The two troughs are too close together. With at least three tiles between them, Bruno can eat in peace.' },
      calm: { title: 'A quiet retreat', ok: 'The retreat is away from the troughs and the play beam.', tip: 'The retreat is too close to a trough or the play beam. It is too busy there.' },
      sleep: { title: 'Play does not disturb sleep', ok: 'Rooting area and play beam are not right next to the straw bed.', tip: 'The rooting area or play beam is next to the straw bed. Anyone dozing there keeps being disturbed.' }
    }
  };

  NTK.TEXTS = { de: de, en: en };
  NTK.locale = 'de';

  function fill(text, vars) {
    if (!vars) return text;
    return text.replace(/\{(\w+)\}/g, function (m, k) { return vars[k] != null ? vars[k] : m; });
  }

  /* Interface text in the current language; German is the fallback. */
  NTK.t = function (key, vars) {
    var ui = NTK.TEXTS[NTK.locale].ui;
    var text = ui[key] != null ? ui[key] : de.ui[key];
    return fill(text != null ? text : key, vars);
  };

  /* Activity of a pig: world.js supplies the German source text. */
  NTK.tAct = function (label, vars) {
    var map = NTK.TEXTS[NTK.locale].act;
    return fill(map && map[label] != null ? map[label] : label, vars);
  };

  /* Sets the language and writes all content texts into NTK.DATA. */
  NTK.localize = function (locale) {
    locale = locale === 'en' ? 'en' : 'de';
    NTK.locale = locale;
    var T = NTK.TEXTS[locale], D = NTK.DATA;
    D.pigs.forEach(function (p) { p.trait = T.pigs[p.id].trait; p.about = T.pigs[p.id].about; });
    Object.keys(D.items).forEach(function (id) {
      D.items[id].name = T.items[id].name;
      D.items[id].short = T.items[id].short || null;
      D.items[id].hint = T.items[id].hint || '';
    });
    D.cases.forEach(function (c, i) {
      var t = T.cases[i];
      c.title = t.title; c.question = t.question; c.solved = t.solved; c.build = t.build;
      c.observations.forEach(function (o, k) { o.text = t.observations[k]; });
      c.options.forEach(function (o, k) { o.text = t.options[k].text; o.why = t.options[k].why || ''; });
      c.card.title = t.card.title; c.card.text = t.card.text; c.card.extra = t.card.extra;
    });
    D.rules.forEach(function (r) { r.title = T.rules[r.id].title; r.ok = T.rules[r.id].ok; r.tip = T.rules[r.id].tip; });
    return locale;
  };

  NTK.localize('de');
})();
