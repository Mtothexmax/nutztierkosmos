/* ============================================================
   Der Wohlfühlstall · Klang
   Hofgeräusche und Rückmeldungen werden live erzeugt.
   Die Hintergrundmusik (audio/musik.m4a) wird erst nachgeladen,
   wenn das Spiel schon läuft. Bis dahin – und falls sie nicht
   lädt – spielt eine leise erzeugte Zupfmelodie.
   ============================================================ */
(function () {
  'use strict';
  var NTK = window.NTK = window.NTK || {};

  var SCALE = [0, 2, 4, 7, 9];            // Dur-Pentatonik
  var ROOTS = [0, -3, 5, 7];              // C, A, F, G

  function AudioEngine() {
    this.ctx = null;
    this.muted = false;
    this.musicOn = true;
    this.musicLevel = 0.15;
    this.musicEl = null;
    this.filePlaying = false;
    this.musicRequested = false;
    this.suspended = false;
    this.nextNote = 1.5;
    this.nextBird = 3;
    this.nextRoot = 0;
    this.root = 0;
    this.step = 0;
  }

  AudioEngine.prototype.init = function () {
    if (this.ctx) { if (this.ctx.state === 'suspended' && !this.suspended) this.ctx.resume().catch(function () {}); return; }
    var Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    try {
      var ctx = this.ctx = new Ctx();
      this.master = ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.7;
      this.master.connect(ctx.destination);
      this.sfxBus = ctx.createGain(); this.sfxBus.gain.value = 0.5; this.sfxBus.connect(this.master);
      this.ambBus = ctx.createGain(); this.ambBus.gain.value = 0.5; this.ambBus.connect(this.master);
      this.musicBus = ctx.createGain(); this.musicBus.gain.value = this.musicGain(); this.musicBus.connect(this.master);
      // soft echo for the plucked notes
      var delay = ctx.createDelay(1); delay.delayTime.value = 0.36;
      var fb = ctx.createGain(); fb.gain.value = 0.3;
      var wet = ctx.createGain(); wet.gain.value = 0.35;
      this.musicIn = ctx.createGain();
      this.musicIn.connect(this.musicBus);
      this.musicIn.connect(delay); delay.connect(fb); fb.connect(delay); delay.connect(wet); wet.connect(this.musicBus);
      this.makeAir();
      this.makePad();
    } catch (err) { this.ctx = null; }
  };

  AudioEngine.prototype.musicGain = function () {
    // The generated melody only fills in while the recorded music is not playing.
    return this.musicOn && !this.filePlaying ? this.musicLevel * 2.2 : 0;
  };

  AudioEngine.prototype.makeAir = function () {
    var ctx = this.ctx;
    var len = ctx.sampleRate * 4;
    var buf = ctx.createBuffer(1, len, ctx.sampleRate);
    var data = buf.getChannelData(0), last = 0;
    for (var i = 0; i < len; i += 1) { last = last * 0.98 + (Math.random() * 2 - 1) * 0.02; data[i] = last * 2.4; }
    var src = ctx.createBufferSource(); src.buffer = buf; src.loop = true;
    var lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 520;
    var g = ctx.createGain(); g.gain.value = 0.05;
    src.connect(lp); lp.connect(g); g.connect(this.ambBus);
    src.start();
  };

  AudioEngine.prototype.makePad = function () {
    var ctx = this.ctx;
    this.pad = [];
    var g = ctx.createGain(); g.gain.value = 0.05;
    var lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 700;
    g.connect(lp); lp.connect(this.musicBus);
    for (var i = 0; i < 3; i += 1) {
      var o = ctx.createOscillator(); o.type = i === 2 ? 'triangle' : 'sine';
      o.frequency.value = 130.81;
      o.connect(g); o.start();
      this.pad.push(o);
    }
    this.tunePad(0);
  };

  function freq(semis) { return 261.63 * Math.pow(2, semis / 12); }

  AudioEngine.prototype.tunePad = function (root) {
    if (!this.pad) return;
    var t = this.ctx.currentTime;
    var notes = [root - 12, root - 5, root + 4 - 12];
    for (var i = 0; i < 3; i += 1) this.pad[i].frequency.setTargetAtTime(freq(notes[i]), t, 1.2);
  };

  AudioEngine.prototype.tone = function (f, dur, vol, type, when, bus) {
    var ctx = this.ctx;
    if (!ctx) return;
    var t = (when || 0) + ctx.currentTime + 0.01;
    var o = ctx.createOscillator(); o.type = type || 'sine'; o.frequency.value = f;
    var g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(bus || this.sfxBus);
    o.start(t); o.stop(t + dur + 0.05);
    return o;
  };

  AudioEngine.prototype.update = function (dt) {
    if (!this.ctx || this.suspended || this.muted) return;
    this.nextRoot -= dt;
    if (this.nextRoot <= 0) {
      this.nextRoot = 9.6;
      this.root = ROOTS[this.step % ROOTS.length];
      this.step += 1;
      this.tunePad(this.root);
    }
    this.nextNote -= dt;
    if (this.nextNote <= 0) {
      this.nextNote = [0.6, 0.6, 1.2, 0.3, 0.9][Math.floor(Math.random() * 5)] * (Math.random() < 0.2 ? 2 : 1);
      if (this.musicOn) {
        var n = SCALE[Math.floor(Math.random() * SCALE.length)] + this.root + (Math.random() < 0.3 ? 12 : 0);
        this.tone(freq(n), 1.5, 0.11, 'triangle', 0, this.musicIn);
        if (Math.random() < 0.25) this.tone(freq(n + 7), 1.2, 0.05, 'sine', 0.15, this.musicIn);
      }
    }
    this.nextBird -= dt;
    if (this.nextBird <= 0) {
      this.nextBird = 4 + Math.random() * 8;
      var base = 2400 + Math.random() * 1600, count = 2 + Math.floor(Math.random() * 3);
      for (var i = 0; i < count; i += 1) {
        var o = this.tone(base, 0.09, 0.03, 'sine', i * 0.13, this.ambBus);
        if (o) o.frequency.exponentialRampToValueAtTime(base * (1.15 + Math.random() * 0.25), this.ctx.currentTime + i * 0.13 + 0.08);
      }
    }
  };

  AudioEngine.prototype.grunt = function (high) {
    var ctx = this.ctx;
    if (!ctx || this.muted || this.suspended) return;
    var t = ctx.currentTime + 0.01;
    var o = ctx.createOscillator(); o.type = 'sawtooth';
    var f0 = high ? 420 : 95 + Math.random() * 30;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(high ? 620 : f0 * 0.75, t + (high ? 0.16 : 0.3));
    var bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = high ? 1500 : 520; bp.Q.value = 1.2;
    var g = ctx.createGain();
    var v = high ? 0.05 : 0.09;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(v, t + 0.03);
    if (!high) { g.gain.exponentialRampToValueAtTime(v * 0.25, t + 0.13); g.gain.exponentialRampToValueAtTime(v * 0.8, t + 0.18); }
    g.gain.exponentialRampToValueAtTime(0.0001, t + (high ? 0.2 : 0.34));
    o.connect(bp); bp.connect(g); g.connect(this.ambBus);
    o.start(t); o.stop(t + 0.4);
  };

  AudioEngine.prototype.sfx = function (name) {
    if (!this.ctx || this.muted || this.suspended) return;
    var self = this;
    switch (name) {
      case 'click': this.tone(660, 0.07, 0.08, 'triangle'); break;
      case 'pick': this.tone(520, 0.1, 0.09, 'triangle'); this.tone(780, 0.1, 0.06, 'triangle', 0.06); break;
      case 'place': this.tone(160, 0.16, 0.22, 'sine'); this.tone(320, 0.1, 0.07, 'triangle', 0.02); break;
      case 'wrong': this.tone(233, 0.22, 0.1, 'sine'); this.tone(196, 0.3, 0.1, 'sine', 0.12); break;
      case 'good': [0, 4, 7, 12].forEach(function (n, i) { self.tone(freq(n), 0.4, 0.1, 'triangle', i * 0.09); }); break;
      case 'card': [7, 12, 16].forEach(function (n, i) { self.tone(freq(n), 0.7, 0.07, 'sine', i * 0.12); }); break;
      case 'case': this.tone(freq(9), 0.3, 0.07, 'sine'); this.tone(freq(4), 0.4, 0.07, 'sine', 0.16); break;
      case 'finish': [0, 4, 7, 12, 16, 19, 24].forEach(function (n, i) { self.tone(freq(n), 0.8, 0.09, 'triangle', i * 0.11); }); break;
      case 'grunt': this.grunt(false); break;
      case 'squeal': this.grunt(true); break;
    }
  };

  /* ---------- recorded music, loaded late ---------- */
  AudioEngine.prototype.fileVolume = function () { return this.musicLevel * 0.6; };

  AudioEngine.prototype.requestMusic = function () {
    if (this.musicRequested || !this.musicOn) return;
    this.musicRequested = true;
    var self = this;
    window.setTimeout(function () { self.loadMusic(); }, 1800);
  };

  AudioEngine.prototype.loadMusic = function () {
    if (this.musicEl || typeof Audio === 'undefined') return;
    var self = this;
    try {
      var el = new Audio();
      el.preload = 'auto';
      el.loop = true;
      el.volume = 0;
      el.muted = this.muted;
      el.addEventListener('canplay', function () { self.playMusic(); });
      el.src = 'audio/musik.m4a';
      this.musicEl = el;
      var retry = function () { self.playMusic(); };
      window.addEventListener('pointerdown', retry);
      window.addEventListener('keydown', retry);
    } catch (err) { this.musicEl = null; }
  };

  AudioEngine.prototype.playMusic = function () {
    var el = this.musicEl, self = this;
    if (!el || !this.musicOn || this.suspended || el.readyState < 2 || !el.paused) return;
    var started = function () {
      self.filePlaying = true;
      if (self.ctx) self.musicBus.gain.setTargetAtTime(0, self.ctx.currentTime, 0.8);
      self.fadeTo(self.fileVolume());
    };
    try {
      var r = el.play();
      if (r && r.then) r.then(started).catch(function () {});
      else started();
    } catch (err) { /* stays silent until the next input */ }
  };

  AudioEngine.prototype.fadeTo = function (target) {
    var el = this.musicEl, self = this;
    if (!el) return;
    window.clearInterval(this.fadeTimer);
    this.fadeTimer = window.setInterval(function () {
      var next = el.volume + (target - el.volume) * 0.1;
      if (Math.abs(target - next) < 0.004) { next = target; window.clearInterval(self.fadeTimer); }
      try { el.volume = Math.max(0, Math.min(1, next)); } catch (err) { window.clearInterval(self.fadeTimer); }
    }, 60);
  };

  AudioEngine.prototype.setMuted = function (m) {
    this.muted = !!m;
    if (this.musicEl) this.musicEl.muted = this.muted;
    if (this.ctx) this.master.gain.setTargetAtTime(this.muted ? 0 : 0.7, this.ctx.currentTime, 0.05);
  };
  AudioEngine.prototype.setMusic = function (on, level) {
    this.musicOn = !!on;
    if (level != null) this.musicLevel = Math.max(0, Math.min(1, level));
    if (!this.musicOn) {
      window.clearInterval(this.fadeTimer);
      if (this.musicEl) this.musicEl.pause();
      this.filePlaying = false;
    } else if (this.musicEl) {
      if (this.musicEl.paused) this.playMusic(); else this.fadeTo(this.fileVolume());
    } else if (this.ctx) {
      this.requestMusic();
    }
    if (this.ctx) this.musicBus.gain.setTargetAtTime(this.musicGain(), this.ctx.currentTime, 0.15);
  };
  AudioEngine.prototype.pause = function () {
    this.suspended = true;
    if (this.musicEl) this.musicEl.pause();
    if (this.ctx && this.ctx.state === 'running') this.ctx.suspend().catch(function () {});
  };
  AudioEngine.prototype.resume = function () {
    this.suspended = false;
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume().catch(function () {});
    this.playMusic();
  };

  NTK.AudioEngine = AudioEngine;
})();
