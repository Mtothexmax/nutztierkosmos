/* ============================================================
   Der Wohlfühlstall · 3D-Welt
   Ein kleines Diorama: Schweinebucht auf einer Insel, vier
   Schweine mit eigenem Verhalten, verschiebbare Einrichtung.
   ============================================================ */
(function () {
  'use strict';
  var NTK = window.NTK = window.NTK || {};
  var T = window.THREE;
  var D = NTK.DATA;

  var COLS = 9, ROWS = 6, S = 1.5;
  var SLAT_FROM = 7;                       // Spalten 7 und 8 sind Spaltenboden
  var MIN_X = -COLS * S / 2, MAX_X = COLS * S / 2;
  var MIN_Z = -ROWS * S / 2, MAX_Z = ROWS * S / 2;

  /* ---------- helpers ---------- */
  var seed = 12345;
  function rnd() { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; }
  function rr(a, b) { return a + Math.random() * (b - a); }
  function col(hex) { return new T.Color(hex).convertSRGBToLinear(); }
  function mat(hex, opts) {
    var o = { color: col(hex), roughness: 0.9, metalness: 0 };
    if (opts) Object.keys(opts).forEach(function (k) { o[k] = opts[k]; });
    return new T.MeshStandardMaterial(o);
  }
  function mesh(geo, material, x, y, z, cast) {
    var m = new T.Mesh(geo, material);
    m.position.set(x || 0, y || 0, z || 0);
    m.castShadow = cast !== false;
    m.receiveShadow = true;
    return m;
  }
  function box(w, h, d, material, x, y, z, cast) { return mesh(new T.BoxGeometry(w, h, d), material, x, y, z, cast); }
  function cyl(r1, r2, h, material, x, y, z, seg) { return mesh(new T.CylinderGeometry(r1, r2, h, seg || 12), material, x, y, z); }
  function tileX(c) { return (c - COLS / 2 + 0.5) * S; }
  function tileZ(r) { return (r - ROWS / 2 + 0.5) * S; }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function turn(from, to, amount) {
    var d = to - from;
    while (d > Math.PI) d -= Math.PI * 2;
    while (d < -Math.PI) d += Math.PI * 2;
    if (Math.abs(d) <= amount) return to;
    return from + (d > 0 ? amount : -amount);
  }

  var M = {};
  function materials() {
    M.wood = mat(0xa9774a);
    M.woodDark = mat(0x7d5536);
    M.woodLight = mat(0xcfa26c);
    M.metal = mat(0x9aa3a8, { roughness: 0.5, metalness: 0.4 });
    M.straw = mat(0xe6bd55);
    M.strawDark = mat(0xcf9f3c);
    M.soil = mat(0x94704c);
    M.feed = mat(0xdcb968);
    M.water = mat(0x6fb9d6, { roughness: 0.25, transparent: true, opacity: 0.8 });
    M.blue = mat(0x4f8fb0, { roughness: 0.5 });
    M.green = mat(0x6f9a5b);
    M.rope = mat(0xd8c08a);
    M.barn = mat(0xb5553e);
    M.trim = mat(0xf6ecd8);
    M.roof = mat(0x6d4a3c);
    M.eye = mat(0x2b211e, { roughness: 0.4 });
  }

  /* ---------- pig model ---------- */
  function Pig(def, world) {
    this.def = def;
    this.id = def.id;
    this.world = world;
    this.x = 0; this.z = 0; this.heading = rr(0, 6.28);
    this.act = null;
    this.moving = false;
    this.lieK = 0; this.sideK = 0; this.headPitch = 0;
    this.phase = rr(0, 6.28);
    this.emote = null;
    this.pstep = 0;
    this.build();
  }

  Pig.prototype.build = function () {
    var def = this.def;
    var skin = mat(def.color, { roughness: 0.75 });
    var dark = mat(def.dark, { roughness: 0.75 });
    var snoutMat = mat(def.spots ? 0xe6a79c : def.dark, { roughness: 0.7 });
    var g = new T.Group();
    var body = new T.Group();
    g.add(body);

    var torso = mesh(new T.SphereGeometry(0.5, 18, 14), skin, 0, 0.62, 0);
    torso.scale.set(0.8, 0.74, 1.14);
    body.add(torso);
    this.torso = torso;

    if (def.spots) {
      [[0.2, 0.86, 0.12, 0.2], [-0.22, 0.8, -0.25, 0.24], [0.1, 0.84, -0.42, 0.15]].forEach(function (s) {
        var spot = mesh(new T.SphereGeometry(s[3], 10, 8), dark, s[0], s[1], s[2], false);
        spot.scale.y = 0.45;
        body.add(spot);
      });
    }

    var head = new T.Group();
    head.position.set(0, 0.7, 0.42);
    body.add(head);
    this.head = head;
    var skull = mesh(new T.SphereGeometry(0.3, 16, 12), skin, 0, 0.04, 0.22);
    skull.scale.set(1, 0.95, 0.98);
    head.add(skull);
    var snout = mesh(new T.CylinderGeometry(0.125, 0.14, 0.17, 14), snoutMat, 0, -0.02, 0.5);
    snout.rotation.x = Math.PI / 2;
    head.add(snout);
    [-1, 1].forEach(function (s) {
      head.add(mesh(new T.SphereGeometry(0.026, 6, 6), M.eye, s * 0.05, -0.01, 0.587, false));
      head.add(mesh(new T.SphereGeometry(0.037, 8, 8), M.eye, s * 0.145, 0.13, 0.43, false));
      var ear = mesh(new T.ConeGeometry(0.12, 0.22, 4), def.spots ? dark : snoutMat, s * 0.19, 0.3, 0.14);
      ear.rotation.set(0.5, 0, -s * 0.55);
      ear.scale.z = 0.5;
      head.add(ear);
    });

    this.legs = [];
    var self = this;
    [[-0.2, 0.34], [0.2, 0.34], [-0.2, -0.34], [0.2, -0.34]].forEach(function (p) {
      var pivot = new T.Group();
      pivot.position.set(p[0], 0.38, p[1]);
      var leg = mesh(new T.CylinderGeometry(0.085, 0.07, 0.38, 8), skin, 0, -0.19, 0);
      pivot.add(leg);
      pivot.add(mesh(new T.CylinderGeometry(0.075, 0.075, 0.06, 8), dark, 0, -0.36, 0, false));
      body.add(pivot);
      self.legs.push(pivot);
    });

    var tail = mesh(new T.TorusGeometry(0.075, 0.024, 6, 12, Math.PI * 1.7), snoutMat, 0, 0.74, -0.6);
    tail.rotation.y = Math.PI / 2;
    body.add(tail);
    this.tail = tail;

    g.traverse(function (o) { o.userData.pigId = def.id; });
    this.group = g;
    this.body = body;
  };

  Pig.prototype.say = function (text, seconds) {
    this.emote = { text: text, t: seconds || 2 };
  };

  Pig.prototype.setAct = function (a) {
    a.phase = a.phase || 'go';
    a.goTime = 0;
    a.maxGo = a.maxGo || 14;
    a.speed = a.speed || 1.25;
    a.t = a.t == null ? 2 : a.t;
    this.act = a;
  };

  Pig.prototype.step = function (dt, time) {
    var world = this.world;
    if (!this.act) world.choose(this);
    var a = this.act;
    this.moving = false;
    if (a.follow) {
      var o = a.follow;
      a.tx = clamp(o.x - Math.sin(o.heading) * 0.8, MIN_X + 0.5, MAX_X - 0.5);
      a.tz = clamp(o.z - Math.cos(o.heading) * 0.8, MIN_Z + 0.5, MAX_Z - 0.5);
    }
    if (a.phase === 'go') {
      var dx = a.tx - this.x, dz = a.tz - this.z;
      var d = Math.sqrt(dx * dx + dz * dz);
      a.goTime += dt;
      if (d < 0.2 || a.goTime > a.maxGo) {
        a.phase = 'do';
        if (a.onArrive) a.onArrive(this);
      } else {
        this.heading = turn(this.heading, Math.atan2(dx, dz), dt * 5.5);
        var sp = a.speed * (0.45 + 0.55 * Math.min(1, d / 0.7));
        this.x += Math.sin(this.heading) * sp * dt;
        this.z += Math.cos(this.heading) * sp * dt;
        this.moving = true;
      }
    } else {
      if (a.face) this.heading = turn(this.heading, Math.atan2(a.face.x - this.x, a.face.z - this.z), dt * 4);
      if (a.tick) a.tick(this, dt);
      a.t -= dt;
      if (a.t <= 0 && this.act === a) {
        this.act = null;
        if (a.onDone) a.onDone(this);
      }
    }
    if (this.emote) {
      this.emote.t -= dt;
      if (this.emote.t <= 0) this.emote = null;
    }
    this.pose(dt, time);
  };

  Pig.prototype.pose = function (dt, time) {
    var a = this.act;
    var anim = this.moving ? 'walk' : (a && a.phase === 'do' ? a.anim : 'stand');
    var t = time + this.phase;
    var lie = 0, side = 0, pitch = 0.04, yaw = 0, bob = 0, wiggle = 0, pulse = 0, legSwing = 0;
    switch (anim) {
      case 'walk': legSwing = Math.sin(t * 11) * 0.55 * Math.min(1.4, (a && a.speed || 1) / 1.25); bob = Math.abs(Math.sin(t * 11)) * 0.025; break;
      case 'look': pitch = -0.12; yaw = Math.sin(t * 1.3) * 0.25; break;
      case 'sad': pitch = 0.5; break;
      case 'sniff': pitch = 0.5 + Math.sin(t * 5) * 0.05; break;
      case 'eat': case 'drink': pitch = 0.62 + Math.sin(t * 8) * 0.1; break;
      case 'root': pitch = 0.7 + Math.sin(t * 7) * 0.12; yaw = Math.sin(t * 3.1) * 0.3; bob = Math.sin(t * 7) * 0.012; break;
      case 'bite': pitch = 0.05 + Math.sin(t * 15) * 0.1; yaw = Math.sin(t * 7) * 0.12; break;
      case 'play': pitch = -0.3 + Math.sin(t * 9) * 0.2; yaw = Math.sin(t * 4.5) * 0.2; bob = Math.abs(Math.sin(t * 9)) * 0.03; break;
      case 'shower': pitch = -0.32; wiggle = Math.sin(t * 13) * 0.07; break;
      case 'tense': pitch = -0.08; wiggle = Math.sin(t * 30) * 0.012; break;
      case 'lie': lie = 1; pitch = 0.2; break;
      case 'pant': lie = 1; side = 1; pulse = Math.sin(t * 9) * 0.045; break;
      default: yaw = Math.sin(t * 0.7) * 0.12;
    }
    var k = Math.min(1, dt * 5);
    this.lieK += (lie - this.lieK) * k;
    this.sideK += (side - this.sideK) * k;
    this.headPitch += (pitch - this.headPitch) * Math.min(1, dt * 9);
    var breathe = 1 + Math.sin(t * 2.2) * 0.012 + pulse;
    this.torso.scale.set(0.8 * breathe, 0.74 * breathe, 1.14);
    this.body.position.y = bob - 0.27 * this.lieK * (1 - this.sideK) + 0.1 * this.sideK;
    this.body.position.x = 0.55 * this.sideK;
    this.body.rotation.z = 1.22 * this.sideK;
    this.body.rotation.y = wiggle;
    this.head.rotation.x = this.headPitch;
    this.head.rotation.y = yaw;
    var legScale = 1 - 0.72 * this.lieK * (1 - this.sideK);
    for (var i = 0; i < 4; i += 1) {
      var sign = (i === 0 || i === 3) ? 1 : -1;
      this.legs[i].rotation.x = legSwing * sign;
      this.legs[i].scale.y = legScale;
    }
    this.tail.rotation.z = Math.sin(t * 6) * 0.35;
    this.group.position.set(this.x, 0, this.z);
    this.group.rotation.y = this.heading;
  };

  /* ---------- world ---------- */
  function World(canvas) {
    materials();
    this.canvas = canvas;
    this.renderer = new T.WebGLRenderer({ canvas: canvas, antialias: true, alpha: true });
    this.renderer.outputEncoding = T.sRGBEncoding;
    this.renderer.toneMapping = T.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.95;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = T.PCFSoftShadowMap;
    this.renderer.setClearColor(0x000000, 0);
    this.scene = new T.Scene();
    this.camera = new T.PerspectiveCamera(32, 1, 1, 220);
    this.azimuth = 0; this.azimuthTarget = 0;
    this.zoom = 1; this.zoomTarget = 1;
    this.targetX = 0;
    this.time = 0;
    this.items = {};          // id -> { id, def, c, r, group, placed }
    this.pigs = [];
    this.problem = null;      // { pigId, kind }
    this.caseStage = 0;       // how many cases have been solved
    this.directives = {};
    this.placing = null;      // { id, c, r, prev }
    this.onPigClick = null; this.onItemClick = null; this.onPlaced = null; this.onPlacementMove = null;
    this.followCam = new T.PerspectiveCamera(30, 1.6, 0.5, 140);
    this.followPig = null;      // pig id shown in the window camera
    this.followRect = null;     // { x, y, w, h } in CSS pixels
    this.followPos = new T.Vector3();
    this.raycaster = new T.Raycaster();
    this.pointer = { down: false, x: 0, y: 0, moved: 0, id: null };

    this.buildLights();
    this.buildIsland();
    this.buildPen();
    this.buildDecor();
    this.buildPlacementAids();
    this.addItem('feeder', D.fixed.feeder.c, D.fixed.feeder.r);
    this.addItem('drinker', D.fixed.drinker.c, D.fixed.drinker.r);
    this.buildPigs();
    this.bindPointer();
    this.resize();
  }

  World.prototype.buildLights = function () {
    var hemi = new T.HemisphereLight(0xfff3df, 0x8fa870, 0.62);
    this.scene.add(hemi);
    var sun = new T.DirectionalLight(0xfff0d2, 1.4);
    sun.position.set(-10, 18, 9);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    var c = sun.shadow.camera;
    c.left = -15; c.right = 15; c.top = 15; c.bottom = -15; c.near = 1; c.far = 60;
    sun.shadow.bias = -0.0004;
    sun.shadow.normalBias = 0.03;
    this.scene.add(sun);
    this.sun = sun;
  };

  World.prototype.buildIsland = function () {
    var grass = mat(0x76b052);
    var top = mesh(new T.CylinderGeometry(15.5, 15.5, 0.7, 56), grass, 0, -0.37, 0, false);
    this.scene.add(top);
    var earth = mesh(new T.CylinderGeometry(15.5, 9.5, 3.6, 56), mat(0x9a7250), 0, -2.5, 0, false);
    this.scene.add(earth);
    var rock = mesh(new T.CylinderGeometry(9.5, 3, 4.5, 24), mat(0x7f6650, { flatShading: true }), 0, -6.5, 0, false);
    this.scene.add(rock);
    // darker grass patches for a hand-made look
    var patch = mat(0x69a148);
    for (var i = 0; i < 16; i += 1) {
      var a = rnd() * Math.PI * 2, r = 9 + rnd() * 5;
      var p = mesh(new T.CircleGeometry(0.8 + rnd() * 1.4, 14), patch, Math.cos(a) * r, -0.012 + i * 0.0006, Math.sin(a) * r, false);
      p.rotation.x = -Math.PI / 2;
      this.scene.add(p);
    }
  };

  World.prototype.buildPen = function () {
    // floor texture: concrete tiles, slatted strip on the right
    var px = 64;
    var cv = document.createElement('canvas');
    cv.width = COLS * px; cv.height = ROWS * px;
    var ctx = cv.getContext('2d');
    for (var c = 0; c < COLS; c += 1) {
      for (var r = 0; r < ROWS; r += 1) {
        var slat = c >= SLAT_FROM;
        var v = Math.floor(rnd() * 10) - 5;
        var base = slat ? [150 + v, 140 + v, 128 + v] : [203 + v, 187 + v, 162 + v];
        ctx.fillStyle = 'rgb(' + base.join(',') + ')';
        ctx.fillRect(c * px, r * px, px, px);
        if (slat) {
          ctx.fillStyle = 'rgba(70,60,52,0.75)';
          for (var y = 5; y < px; y += 11) ctx.fillRect(c * px + 5, r * px + y, px - 10, 3);
        }
        ctx.strokeStyle = 'rgba(120,100,80,0.28)';
        ctx.lineWidth = 2;
        ctx.strokeRect(c * px + 1, r * px + 1, px - 2, px - 2);
      }
    }
    var tex = new T.CanvasTexture(cv);
    tex.encoding = T.sRGBEncoding;
    tex.anisotropy = 4;
    var floor = mesh(new T.PlaneGeometry(COLS * S, ROWS * S), new T.MeshStandardMaterial({ map: tex, roughness: 0.95 }), 0, 0.02, 0, false);
    floor.rotation.x = -Math.PI / 2;
    this.scene.add(floor);
    this.floor = floor;
    // kerb
    var kerb = mat(0xb9ab96);
    this.scene.add(box(COLS * S + 0.5, 0.12, 0.25, kerb, 0, 0.03, MAX_Z + 0.12, false));
    this.scene.add(box(0.25, 0.12, ROWS * S + 0.25, kerb, MIN_X - 0.12, 0.03, 0.06, false));
    this.scene.add(box(0.25, 0.12, ROWS * S + 0.25, kerb, MAX_X + 0.12, 0.03, 0.06, false));

    // fence: wooden posts, metal bars
    var self = this;
    function post(x, z) { self.scene.add(box(0.16, 1.0, 0.16, M.woodDark, x, 0.5, z)); }
    function bar(x1, z1, x2, z2, y) {
      var len = Math.sqrt((x2 - x1) * (x2 - x1) + (z2 - z1) * (z2 - z1));
      var b = cyl(0.035, 0.035, len, M.metal, (x1 + x2) / 2, y, (z1 + z2) / 2, 8);
      b.rotation.z = Math.PI / 2;
      b.rotation.y = Math.atan2(z1 - z2, x2 - x1);
      self.scene.add(b);
    }
    var fz = MAX_Z + 0.12, fx1 = MIN_X - 0.12, fx2 = MAX_X + 0.12;
    for (var i = 0; i <= COLS; i += 1) post(fx1 + (fx2 - fx1) * i / COLS, fz);
    for (var j = 0; j < ROWS; j += 1) { post(fx1, MIN_Z + j * S); post(fx2, MIN_Z + j * S); }
    [0.3, 0.58, 0.86].forEach(function (y) {
      bar(fx1, fz, fx2, fz, y);
      bar(fx1, MIN_Z, fx1, fz, y);
      bar(fx2, MIN_Z, fx2, fz, y);
    });

    // barn wall at the back
    var wallZ = MIN_Z - 0.2, w = COLS * S + 1.2;
    this.scene.add(box(w, 3.0, 0.3, M.barn, 0, 1.5, wallZ));
    for (var k = 0; k <= 12; k += 1) {
      this.scene.add(box(0.05, 3.0, 0.02, mat(0x9c4633), -w / 2 + w * k / 12, 1.5, wallZ + 0.16, false));
    }
    this.scene.add(box(w + 0.1, 0.16, 0.36, M.trim, 0, 0.08, wallZ, false));
    this.scene.add(box(w + 0.1, 0.14, 0.36, M.trim, 0, 2.95, wallZ, false));
    // window
    this.scene.add(box(1.7, 1.0, 0.1, M.trim, 3.2, 2.0, wallZ + 0.14, false));
    this.scene.add(box(1.5, 0.8, 0.1, mat(0x7fb3c8, { roughness: 0.3 }), 3.2, 2.0, wallZ + 0.16, false));
    this.scene.add(box(0.06, 0.8, 0.1, M.trim, 3.2, 2.0, wallZ + 0.18, false));
    // shed body and roof behind the wall
    this.scene.add(box(w, 3.0, 3.4, M.barn, 0, 1.5, wallZ - 1.85));
    var roofA = box(w + 0.8, 0.22, 2.5, M.roof, 0, 3.55, wallZ - 0.75);
    roofA.rotation.x = 0.5;
    var roofB = box(w + 0.8, 0.22, 2.5, M.roof, 0, 3.55, wallZ - 2.85);
    roofB.rotation.x = -0.5;
    this.scene.add(roofA, roofB);
    var gable = mat(0xa64d38);
    [-1, 1].forEach(function (s) {
      var tri = mesh(new T.CylinderGeometry(0.01, 1.95, 1.1, 3, 1), gable, s * (w / 2 - 0.02), 3.5, wallZ - 1.8, false);
      tri.rotation.y = Math.PI / 2;
      tri.scale.z = 0.02;
      self.scene.add(tri);
    });
  };

  World.prototype.buildDecor = function () {
    var self = this;
    var leaf = [mat(0x5f9a4c, { flatShading: true }), mat(0x74ac55, { flatShading: true }), mat(0x4f8a48, { flatShading: true })];
    function tree(x, z, s) {
      var g = new T.Group();
      g.add(cyl(0.16 * s, 0.24 * s, 1.5 * s, M.woodDark, 0, 0.75 * s, 0, 7));
      [[0, 2.1, 0, 1.05], [0.55, 1.75, 0.2, 0.7], [-0.5, 1.8, -0.2, 0.75], [0.1, 2.75, -0.1, 0.65]].forEach(function (c, i) {
        g.add(mesh(new T.IcosahedronGeometry(c[3] * s, 1), leaf[i % 3], c[0] * s, c[1] * s, c[2] * s));
      });
      g.position.set(x, 0, z);
      g.rotation.y = rnd() * 6;
      self.scene.add(g);
    }
    tree(-11.2, -5.5, 1.25); tree(11.5, -4.2, 1.1); tree(-12.3, 3.2, 0.95); tree(12.4, 4.6, 1.2);
    tree(-9.2, 9.6, 0.9); tree(8.2, 10.4, 1.0); tree(-3.5, -12.6, 1.15); tree(5.5, -12.2, 0.9);
    // bushes and flowers
    for (var i = 0; i < 18; i += 1) {
      var a = rnd() * Math.PI * 2, r = 9.6 + rnd() * 4.6;
      var x = Math.cos(a) * r, z = Math.sin(a) * r;
      if (Math.abs(x) < 8.4 && z < -4 && z > -9) continue;
      var b = mesh(new T.IcosahedronGeometry(0.35 + rnd() * 0.35, 1), leaf[i % 3], x, 0.25, z);
      b.scale.y = 0.75;
      this.scene.add(b);
    }
    var petals = [0xf6d04d, 0xf08a7a, 0xfaf3e4, 0xb99be0];
    var stem = mat(0x5e9447);
    for (var f = 0; f < 46; f += 1) {
      var fa = rnd() * Math.PI * 2, fr = 8.6 + rnd() * 6;
      var fx = Math.cos(fa) * fr, fz = Math.sin(fa) * fr;
      if (Math.abs(fx) < 7.6 && Math.abs(fz) < 5.6) continue;
      if (Math.abs(fx) < 8.4 && fz < -4 && fz > -9) continue;
      this.scene.add(cyl(0.015, 0.015, 0.28, stem, fx, 0.14, fz, 5));
      this.scene.add(mesh(new T.SphereGeometry(0.075, 7, 6), mat(petals[f % 4]), fx, 0.3, fz, false));
    }
    // clouds
    this.clouds = [];
    var cm = new T.MeshStandardMaterial({ color: 0xffffff, roughness: 1, emissive: col(0xdfe9ee), emissiveIntensity: 0.55 });
    for (var k = 0; k < 7; k += 1) {
      var cg = new T.Group();
      for (var n = 0; n < 4; n += 1) {
        var puff = mesh(new T.SphereGeometry(1 + rnd() * 0.9, 10, 8), cm, n * 1.3 - 2, rnd() * 0.5, rnd() * 0.8, false);
        puff.receiveShadow = false;
        puff.scale.y = 0.6;
        cg.add(puff);
      }
      cg.position.set(-34 + k * 11 + rnd() * 4, -2 + rnd() * 9, -20 - rnd() * 14);
      cg.userData.speed = 0.15 + rnd() * 0.2;
      this.scene.add(cg);
      this.clouds.push(cg);
    }
  };

  World.prototype.buildPlacementAids = function () {
    var cv = document.createElement('canvas');
    cv.width = COLS * 32; cv.height = ROWS * 32;
    var ctx = cv.getContext('2d');
    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx.lineWidth = 2;
    for (var c = 0; c < COLS; c += 1) for (var r = 0; r < ROWS; r += 1) ctx.strokeRect(c * 32 + 2, r * 32 + 2, 28, 28);
    var tex = new T.CanvasTexture(cv);
    var grid = new T.Mesh(new T.PlaneGeometry(COLS * S, ROWS * S), new T.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0.55, depthWrite: false }));
    grid.rotation.x = -Math.PI / 2;
    grid.position.y = 0.035;
    grid.visible = false;
    this.scene.add(grid);
    this.grid = grid;
    var fp = new T.Mesh(new T.PlaneGeometry(1, 1), new T.MeshBasicMaterial({ color: 0x66cc66, transparent: true, opacity: 0.5, depthWrite: false }));
    fp.rotation.x = -Math.PI / 2;
    fp.position.y = 0.05;
    fp.visible = false;
    this.scene.add(fp);
    this.footprint = fp;
  };

  function addStraw(g, w, d, y, n) {
    for (var i = 0; i < n; i += 1) {
      var s = box(0.3 + rnd() * 0.3, 0.025, 0.035, i % 3 ? M.straw : M.strawDark, (rnd() - 0.5) * w, y + rnd() * 0.05, (rnd() - 0.5) * d, false);
      s.rotation.set((rnd() - 0.5) * 0.5, rnd() * Math.PI, (rnd() - 0.5) * 0.5);
      g.add(s);
    }
  }

  var BUILD = {
    feeder: function (second) {
      var g = new T.Group();
      g.add(box(1.2, 0.34, 0.62, M.metal, 0, 0.19, 0.08));
      g.add(box(1.06, 0.06, 0.48, M.feed, 0, 0.36, 0.08, false));
      g.add(box(1.1, 1.0, 0.3, second ? M.green : M.woodLight, 0, 0.52, -0.42));
      g.add(box(1.2, 0.08, 0.4, M.woodDark, 0, 1.05, -0.42));
      return g;
    },
    feeder2: function () { return BUILD.feeder(true); },
    drinker: function () {
      var g = new T.Group();
      g.add(cyl(0.06, 0.06, 1.0, M.metal, 0, 0.5, -0.5, 8));
      g.add(cyl(0.28, 0.2, 0.16, M.blue, 0, 0.3, -0.25, 14));
      g.add(cyl(0.23, 0.23, 0.02, M.water, 0, 0.385, -0.25, 14));
      g.add(box(0.06, 0.06, 0.3, M.metal, 0, 0.42, -0.4, false));
      return g;
    },
    rooting: function () {
      var g = new T.Group();
      var w = 2 * S - 0.2;
      g.add(box(w, 0.1, w, M.soil, 0, 0.07, 0, false));
      g.add(box(w + 0.12, 0.2, 0.12, M.wood, 0, 0.11, w / 2));
      g.add(box(w + 0.12, 0.2, 0.12, M.wood, 0, 0.11, -w / 2));
      g.add(box(0.12, 0.2, w, M.wood, w / 2, 0.11, 0));
      g.add(box(0.12, 0.2, w, M.wood, -w / 2, 0.11, 0));
      for (var i = 0; i < 5; i += 1) {
        var m = mesh(new T.SphereGeometry(0.45 + rnd() * 0.25, 10, 8), i % 2 ? M.straw : M.strawDark, (rnd() - 0.5) * 1.8, 0.1, (rnd() - 0.5) * 1.8, false);
        m.scale.y = 0.3;
        g.add(m);
      }
      addStraw(g, w - 0.4, w - 0.4, 0.2, 46);
      return g;
    },
    bed: function () {
      var g = new T.Group();
      var w = 2 * S - 0.25;
      g.add(box(w, 0.2, w, M.straw, 0, 0.12, 0));
      for (var i = 0; i < 6; i += 1) {
        var m = mesh(new T.SphereGeometry(0.5 + rnd() * 0.2, 10, 8), M.straw, (rnd() - 0.5) * 1.7, 0.2, (rnd() - 0.5) * 1.7, false);
        m.scale.y = 0.22;
        g.add(m);
      }
      addStraw(g, w - 0.2, w - 0.2, 0.26, 56);
      g.add(box(w + 0.14, 0.34, 0.12, M.woodLight, 0, 0.18, -w / 2 - 0.02));
      g.add(box(0.12, 0.34, w, M.woodLight, -w / 2 - 0.02, 0.18, 0));
      return g;
    },
    shower: function () {
      var g = new T.Group();
      g.add(cyl(0.05, 0.05, 2.1, M.metal, -0.55, 1.05, -0.55, 8));
      var arm = cyl(0.04, 0.04, 0.8, M.metal, -0.27, 2.08, -0.27, 8);
      arm.rotation.z = Math.PI / 2;
      arm.rotation.y = -Math.PI / 4;
      g.add(arm);
      g.add(cyl(0.2, 0.12, 0.1, M.blue, 0, 2.03, 0, 12));
      var wet = mesh(new T.CircleGeometry(0.66, 20), M.water, 0, 0.045, 0, false);
      wet.rotation.x = -Math.PI / 2;
      g.add(wet);
      var drops = [];
      var dm = new T.MeshBasicMaterial({ color: 0xbfe6f5, transparent: true, opacity: 0.85 });
      for (var i = 0; i < 16; i += 1) {
        var d = new T.Mesh(new T.SphereGeometry(0.025, 5, 4), dm);
        d.userData.a = rnd() * 6.28; d.userData.r = 0.05 + rnd() * 0.42; d.userData.o = rnd();
        g.add(d);
        drops.push(d);
      }
      g.userData.drops = drops;
      return g;
    },
    niche: function () {
      var g = new T.Group();
      var w = 2 * S - 0.12, d = S - 0.12;
      g.add(box(w, 0.86, 0.1, M.wood, 0, 0.43, -d / 2));
      g.add(box(0.1, 0.86, d, M.wood, -w / 2, 0.43, 0));
      g.add(box(0.1, 0.86, d, M.wood, w / 2, 0.43, 0));
      g.add(box(w + 0.1, 0.07, 0.16, M.woodDark, 0, 0.88, -d / 2));
      g.add(box(w - 0.2, 0.06, d - 0.2, M.strawDark, 0, 0.05, 0, false));
      addStraw(g, w - 0.5, d - 0.4, 0.09, 18);
      return g;
    },
    toy: function () {
      var g = new T.Group();
      g.add(box(0.14, 1.8, 0.14, M.woodDark, 0, 0.9, -0.55));
      g.add(box(0.12, 0.12, 0.85, M.woodDark, 0, 1.74, -0.2));
      var swing = new T.Group();
      swing.position.set(0, 1.7, 0.12);
      swing.add(cyl(0.022, 0.022, 0.95, M.rope, 0, -0.475, 0, 6));
      var block = box(0.55, 0.15, 0.15, M.woodLight, 0, -1.0, 0);
      swing.add(block);
      swing.add(cyl(0.03, 0.03, 0.3, M.rope, 0.2, -1.2, 0, 6));
      swing.add(cyl(0.03, 0.03, 0.3, M.rope, -0.2, -1.2, 0, 6));
      g.add(swing);
      g.userData.swing = swing;
      return g;
    }
  };

  World.prototype.addItem = function (id, c, r) {
    var def = D.items[id];
    var it = this.items[id];
    if (!it) {
      it = { id: id, def: def, c: 0, r: 0, placed: false, group: BUILD[id]() };
      it.group.visible = false;
      this.scene.add(it.group);
      this.items[id] = it;
    }
    if (c != null) {
      it.c = c; it.r = r; it.placed = true;
      it.group.visible = true;
      this.seatItem(it, 0);
    }
    return it;
  };

  World.prototype.itemCenter = function (it, c, r) {
    c = c == null ? it.c : c; r = r == null ? it.r : r;
    return { x: (c + it.def.w / 2 - COLS / 2) * S, z: (r + it.def.h / 2 - ROWS / 2) * S };
  };

  World.prototype.seatItem = function (it, lift) {
    var p = this.itemCenter(it);
    it.group.position.set(p.x, lift || 0, p.z);
  };

  World.prototype.removeItems = function () {
    var self = this;
    Object.keys(this.items).forEach(function (id) {
      if (D.items[id].fixed) return;
      self.scene.remove(self.items[id].group);
      delete self.items[id];
    });
  };

  World.prototype.buildPigs = function () {
    var self = this;
    var starts = [[-3, 1.5], [-5, 3], [1, 0.5], [3.5, 2.5]];
    D.pigs.forEach(function (def, i) {
      var p = new Pig(def, self);
      p.x = starts[i][0]; p.z = starts[i][1];
      self.scene.add(p.group);
      self.pigs.push(p);
    });
  };

  World.prototype.pig = function (id) {
    for (var i = 0; i < this.pigs.length; i += 1) if (this.pigs[i].id === id) return this.pigs[i];
    return null;
  };

  World.prototype.reset = function () {
    var starts = [[-3, 1.5], [-5, 3], [1, 0.5], [3.5, 2.5]];
    this.cancelPlacement();
    this.removeItems();
    this.problem = null;
    this.caseStage = 0;
    this.directives = {};
    this.pigs.forEach(function (p, i) {
      p.x = starts[i][0]; p.z = starts[i][1];
      p.act = null; p.emote = null; p.pstep = 0;
    });
    this.azimuthTarget = 0; this.zoomTarget = 1;
  };

  /* ---------- behaviour ---------- */
  World.prototype.randomSpot = function (noSlats) {
    return { x: rr(MIN_X + 0.7, (noSlats ? tileX(SLAT_FROM) - S / 2 : MAX_X) - 0.7), z: rr(MIN_Z + 0.9, MAX_Z - 0.7) };
  };

  World.prototype.usersOf = function (id, except) {
    var n = 0;
    this.pigs.forEach(function (p) { if (p !== except && p.act && p.act.item === id) n += 1; });
    return n;
  };

  // Where a pig stands to use an item, and what it looks at.
  World.prototype.usePoint = function (it, slot) {
    var c = this.itemCenter(it);
    var id = it.id;
    if (id === 'feeder' || id === 'feeder2' || id === 'drinker' || id === 'toy') {
      var front = (it.r + it.def.h) < ROWS;         // free row in front of the item?
      var dz = front ? 0.95 : -0.95;
      if (id === 'toy') dz = front ? 0.75 : 0.2;
      var dx = (id === 'drinker') ? 0 : (slot % 2 ? 0.34 : -0.34);
      return {
        x: clamp(c.x + dx, MIN_X + 0.4, MAX_X - 0.4), z: clamp(c.z + dz, MIN_Z + 0.4, MAX_Z - 0.4),
        face: { x: c.x + dx * 0.5, z: c.z + (id === 'toy' ? 0.1 : 0) }
      };
    }
    if (id === 'shower') return { x: c.x + (slot % 2 ? 0.28 : -0.2), z: c.z + (slot % 2 ? 0.2 : -0.1), face: null };
    var mx = it.def.w * S / 2 - 0.55, mz = it.def.h * S / 2 - 0.5;
    if (id === 'niche') return { x: c.x + rr(-0.3, 0.3), z: c.z + 0.05, face: { x: c.x + rr(-2, 2), z: c.z + 5 } };
    return { x: c.x + rr(-mx, mx), z: c.z + rr(-mz, mz), face: null };
  };

  var USE = {
    feeder: { anim: 'eat', label: 'frisst am Trog', t: [4, 7] },
    feeder2: { anim: 'eat', label: 'frisst am zweiten Trog', t: [4, 7] },
    drinker: { anim: 'drink', label: 'trinkt an der Tränke', t: [2.5, 4] },
    rooting: { anim: 'root', label: 'wühlt im Stroh', t: [5, 9], emote: 'straw' },
    bed: { anim: 'lie', label: 'döst im Strohbett', t: [7, 12], emote: 'zzz' },
    shower: { anim: 'shower', label: 'steht unter der Dusche', t: [4, 7], emote: 'sweat' },
    niche: { anim: 'lie', label: 'ruht in der Nische', t: [6, 10], emote: 'zzz' },
    toy: { anim: 'play', label: 'zieht am Spielbalken', t: [4, 7] }
  };

  World.prototype.useItem = function (pig, id, extra) {
    var it = this.items[id];
    var u = USE[id];
    var up = this.usePoint(it, this.usersOf(id, pig));
    var a = {
      tx: up.x, tz: up.z, face: up.face, item: id, anim: u.anim, label: u.label,
      t: rr(u.t[0], u.t[1]), noSep: id === 'bed',
      onArrive: function (p) { if (u.emote && Math.random() < 0.6) p.say(u.emote, 2.2); }
    };
    if (extra) Object.keys(extra).forEach(function (k) { a[k] = extra[k]; });
    pig.setAct(a);
  };

  World.prototype.wander = function (pig) {
    var s = this.randomSpot();
    pig.setAct({ tx: s.x, tz: s.z, anim: Math.random() < 0.4 ? 'look' : 'stand', label: 'läuft durch die Bucht', t: rr(1, 3), speed: rr(0.9, 1.3) });
  };

  World.prototype.nibble = function (pig) {
    var others = this.pigs.filter(function (p) { return p !== pig; });
    var victim = others[Math.floor(Math.random() * others.length)];
    var world = this;
    pig.setAct({
      follow: victim, tx: victim.x, tz: victim.z, anim: 'bite', label: 'knabbert an {name}', labelVars: { name: victim.def.name }, t: 1.6, speed: 1.5, maxGo: 7, noSep: true,
      onArrive: function () {
        victim.say('alert', 1.4);
        if (world.onSound) world.onSound('squeal');
        var away = world.randomSpot();
        victim.setAct({ tx: away.x, tz: away.z, anim: 'look', label: 'weicht aus', t: 1.5, speed: 2.3 });
      }
    });
  };

  World.prototype.problemAct = function (pig, kind) {
    var world = this, s;
    if (kind === 'barbite') {
      if (Math.random() < 0.55) {
        var x = rr(MIN_X + 1, 2);
        pig.setAct({ tx: x, tz: MAX_Z - 0.42, face: { x: x, z: MAX_Z + 3 }, anim: 'bite', label: 'beißt in die Gitterstange', t: rr(3, 4.5) });
      } else this.nibble(pig);
      return;
    }
    if (kind === 'bored') {
      var rooting = this.items.rooting;
      if (rooting && rooting.placed && Math.random() < 0.4) {
        var c = this.itemCenter(rooting);
        pig.setAct({ tx: c.x + rr(-0.6, 0.6), tz: c.z + rr(-0.6, 0.6), anim: 'sniff', label: 'schnüffelt lustlos am Stroh', t: 1.4, onDone: function (p) { p.say('talk', 1.5); } });
      } else this.nibble(pig);
      return;
    }
    if (kind === 'displaced') {
      var f = this.itemCenter(this.items.feeder);
      if (pig.pstep % 2 === 0) {
        pig.setAct({ tx: f.x + 1.5, tz: f.z + 2.3, face: f, anim: 'look', label: 'traut sich nicht an den Trog', t: 1.6, speed: 0.9 });
      } else {
        pig.setAct({ tx: MAX_X - 3.6, tz: MAX_Z - 0.7, face: { x: MAX_X, z: MAX_Z + 2 }, anim: 'sad', label: 'wartet mit gesenktem Kopf in der Ecke', t: rr(4, 6), speed: 1.5, onArrive: function (p) { p.say('talk', 2); } });
      }
      pig.pstep += 1;
      return;
    }
    if (kind === 'hot') {
      pig.setAct({ tx: tileX(7) + 0.5, tz: tileZ(4) + 0.2, anim: 'pant', label: 'liegt ausgestreckt und atmet schnell', t: 9, speed: 0.8, onArrive: function (p) { p.say('sweat', 2.5); }, tick: function (p) { if (!p.emote && Math.random() < 0.004) p.say('sweat', 2); } });
      return;
    }
    if (kind === 'restless') {
      s = this.randomSpot();
      pig.setAct({ tx: s.x, tz: s.z, anim: 'lie', label: 'sucht einen Liegeplatz', t: rr(2, 3), onDone: function (p) { p.say('talk', 1.3); } });
      return;
    }
    if (kind === 'startle') {
      s = this.randomSpot(true);
      pig.setAct({
        tx: s.x, tz: s.z, anim: 'tense', label: 'steht angespannt da', t: rr(3, 5),
        tick: function (p) {
          for (var i = 0; i < world.pigs.length; i += 1) {
            var o = world.pigs[i];
            if (o === p) continue;
            var dx = o.x - p.x, dz = o.z - p.z;
            if (dx * dx + dz * dz < 2.6) {
              p.say('alert', 1.5);
              if (world.onSound) world.onSound('squeal');
              var fx = o.x > 0 ? MIN_X + 0.9 : tileX(SLAT_FROM) - 1.2;
              var fz = o.z > 0 ? MIN_Z + 1 : MAX_Z - 0.8;
              p.setAct({ tx: fx, tz: fz, anim: 'tense', label: 'flüchtet', t: 2.2, speed: 2.8 });
              return;
            }
          }
        }
      });
    }
  };

  World.prototype.choose = function (pig) {
    var dir = this.directives[pig.id];
    if (dir) {
      delete this.directives[pig.id];
      var world = this;
      this.useItem(pig, dir.item, {
        t: 7, speed: 1.9, maxGo: 9,
        onArrive: function (p) {
          p.say('heart', 3);
          if (dir.cb) world.after(2.2, dir.cb);
        }
      });
      return;
    }
    var problem = this.problem;
    if (problem && problem.pigId === pig.id && Math.random() < 0.88) { this.problemAct(pig, problem.kind); return; }

    var items = this.items, self = this;
    var opts = [{ w: 2.5, fn: function () { self.wander(pig); } }];
    function use(id, w) {
      var it = items[id];
      if (!it || !it.placed || self.usersOf(id, pig) >= it.def.cap) return;
      if (self.placing && self.placing.id === id) return;
      opts.push({ w: w, fn: function () { self.useItem(pig, id); } });
    }
    var crowding = problem && problem.kind === 'displaced';
    if (!(crowding && pig.id === 'bruno')) use('feeder', crowding ? 7 : 1.6);
    use('feeder2', pig.id === 'bruno' ? 3 : 1);
    use('drinker', 0.9);
    use('rooting', pig.id === 'emma' && this.caseStage < 5 ? 5 : 3);
    use('shower', pig.id === 'lotte' ? 3 : 1.3);
    use('toy', pig.id === 'emma' ? 5 : 2.2);
    if (pig.id === 'bruno') use('niche', 3);
    if (items.bed && items.bed.placed) use('bed', pig.id === 'frieda' ? 4 : 2.6);
    else if (!(problem && problem.kind === 'startle')) {
      opts.push({ w: 0.9, fn: function () {
        var s = self.randomSpot();
        pig.setAct({ tx: s.x, tz: s.z, anim: 'lie', label: 'döst auf dem Boden', t: rr(3, 5) });
      } });
    }
    var total = 0, i;
    for (i = 0; i < opts.length; i += 1) total += opts[i].w;
    var pick = Math.random() * total;
    for (i = 0; i < opts.length; i += 1) { pick -= opts[i].w; if (pick <= 0) { opts[i].fn(); return; } }
    opts[0].fn();
  };

  World.prototype.direct = function (pigId, itemId, cb) {
    this.directives[pigId] = { item: itemId, cb: cb };
    var p = this.pig(pigId);
    if (p) p.act = null;
  };

  World.prototype.setProblem = function (problem) {
    this.problem = problem;
    if (problem) {
      var p = this.pig(problem.pigId);
      if (p) { p.act = null; p.pstep = 0; }
    }
  };

  World.prototype.after = function (seconds, fn) {
    this.timers = this.timers || [];
    this.timers.push({ t: seconds, fn: fn });
  };

  // German source text of what a pig is doing (translated by the game), or a key.
  World.prototype.activity = function (pigId) {
    var p = this.pig(pigId);
    if (!p || !p.act) return { key: 'actIdle' };
    if (p.act.phase === 'go' && !p.act.follow) return { key: 'actMoving' };
    if (!p.act.label) return { key: 'actIdle' };
    return { label: p.act.label, vars: p.act.labelVars || null };
  };


  /* ---------- placement ---------- */
  World.prototype.rects = function () {
    var out = {}, items = this.items;
    Object.keys(items).forEach(function (id) {
      var it = items[id];
      if (it.placed) out[id] = { c: it.c, r: it.r, w: it.def.w, h: it.def.h };
    });
    return out;
  };

  World.prototype.canPlace = function (id, c, r) {
    var def = D.items[id];
    if (c < 0 || r < 0 || c + def.w > COLS || r + def.h > ROWS) return false;
    var rects = this.rects();
    for (var k in rects) {
      if (k === id) continue;
      var o = rects[k];
      if (c < o.c + o.w && c + def.w > o.c && r < o.r + o.h && r + def.h > o.r) return false;
    }
    return true;
  };

  World.prototype.beginPlacement = function (id) {
    if (this.placing) this.cancelPlacement();
    var it = this.addItem(id);
    var prev = it.placed ? { c: it.c, r: it.r } : null;
    var c = prev ? prev.c : 3, r = prev ? prev.r : 2;
    it.placed = false;
    it.group.visible = true;
    this.pigs.forEach(function (p) { if (p.act && p.act.item === id) p.act = null; });
    this.placing = { id: id, c: c, r: r, prev: prev };
    if (!prev && !this.canPlace(id, c, r)) {
      outer: for (var rr2 = 0; rr2 < ROWS; rr2 += 1) for (var cc = 0; cc < COLS; cc += 1) {
        if (this.canPlace(id, cc, rr2)) { this.placing.c = cc; this.placing.r = rr2; break outer; }
      }
    }
    this.grid.visible = true;
    this.footprint.visible = true;
    this.refreshPlacement();
  };

  World.prototype.refreshPlacement = function () {
    var pl = this.placing;
    if (!pl) return;
    var it = this.items[pl.id];
    var p = this.itemCenter(it, pl.c, pl.r);
    it.group.position.x = p.x; it.group.position.z = p.z;
    var ok = this.canPlace(pl.id, pl.c, pl.r);
    pl.ok = ok;
    this.footprint.scale.set(it.def.w * S + 0.16, it.def.h * S + 0.16, 1);
    this.footprint.position.set(p.x, 0.05, p.z);
    this.footprint.material.color.set(ok ? 0x58c468 : 0xe0624f);
    if (this.onPlacementMove) this.onPlacementMove(pl);
  };

  World.prototype.nudge = function (dc, dr) {
    var pl = this.placing;
    if (!pl) return;
    var def = D.items[pl.id];
    pl.c = clamp(pl.c + dc, 0, COLS - def.w);
    pl.r = clamp(pl.r + dr, 0, ROWS - def.h);
    this.refreshPlacement();
  };

  World.prototype.confirmPlacement = function () {
    var pl = this.placing;
    if (!pl || !pl.ok) return false;
    var it = this.items[pl.id];
    it.c = pl.c; it.r = pl.r; it.placed = true;
    this.seatItem(it, 0);
    this.endPlacement();
    if (this.onPlaced) this.onPlaced(pl.id, !pl.prev);
    return true;
  };

  World.prototype.cancelPlacement = function () {
    var pl = this.placing;
    if (!pl) return;
    var it = this.items[pl.id];
    if (pl.prev) { it.c = pl.prev.c; it.r = pl.prev.r; it.placed = true; this.seatItem(it, 0); }
    else it.group.visible = false;
    this.endPlacement();
  };

  World.prototype.endPlacement = function () {
    this.placing = null;
    this.grid.visible = false;
    this.footprint.visible = false;
    if (this.onPlacementMove) this.onPlacementMove(null);
  };

  World.prototype.itemAt = function (c, r) {
    var rects = this.rects();
    for (var k in rects) {
      var o = rects[k];
      if (c >= o.c && c < o.c + o.w && r >= o.r && r < o.r + o.h) return k;
    }
    return null;
  };

  /* ---------- pointer ---------- */
  World.prototype.groundPoint = function (clientX, clientY) {
    var rect = this.canvas.getBoundingClientRect();
    var v = new T.Vector2(((clientX - rect.left) / rect.width) * 2 - 1, -((clientY - rect.top) / rect.height) * 2 + 1);
    this.raycaster.setFromCamera(v, this.camera);
    var ray = this.raycaster.ray;
    if (Math.abs(ray.direction.y) < 1e-5) return null;
    var t = -ray.origin.y / ray.direction.y;
    if (t < 0) return null;
    return { x: ray.origin.x + ray.direction.x * t, z: ray.origin.z + ray.direction.z * t };
  };

  World.prototype.pointerToPlacement = function (clientX, clientY) {
    var pl = this.placing;
    var g = this.groundPoint(clientX, clientY);
    if (!pl || !g) return;
    var def = D.items[pl.id];
    var c = Math.round(g.x / S + COLS / 2 - def.w / 2);
    var r = Math.round(g.z / S + ROWS / 2 - def.h / 2);
    c = clamp(c, 0, COLS - def.w); r = clamp(r, 0, ROWS - def.h);
    if (c !== pl.c || r !== pl.r) { pl.c = c; pl.r = r; this.refreshPlacement(); }
  };

  World.prototype.bindPointer = function () {
    var self = this, cv = this.canvas, P = this.pointer;
    cv.addEventListener('pointerdown', function (e) {
      P.down = true; P.x = e.clientX; P.y = e.clientY; P.moved = 0; P.id = e.pointerId;
      try { cv.setPointerCapture(e.pointerId); } catch (err) { /* not critical */ }
      if (self.placing) self.pointerToPlacement(e.clientX, e.clientY);
    });
    cv.addEventListener('pointermove', function (e) {
      if (self.placing) { self.pointerToPlacement(e.clientX, e.clientY); if (P.down) P.moved += Math.abs(e.movementX || 0) + Math.abs(e.movementY || 0); return; }
      if (!P.down) return;
      var dx = e.clientX - P.x;
      P.moved += Math.abs(dx) + Math.abs(e.clientY - P.y);
      P.x = e.clientX; P.y = e.clientY;
      if (P.moved > 6) self.azimuthTarget = clamp(self.azimuthTarget - dx * 0.005, -0.7, 0.7);
    });
    function up(e) {
      if (!P.down) return;
      P.down = false;
      if (self.locked) return;
      if (self.placing) { self.pointerToPlacement(e.clientX, e.clientY); self.confirmPlacement(); return; }
      if (P.moved > 6) return;
      var rect = cv.getBoundingClientRect();
      var v = new T.Vector2(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
      self.raycaster.setFromCamera(v, self.camera);
      var hits = self.raycaster.intersectObjects(self.pigs.map(function (p) { return p.group; }), true);
      if (hits.length && self.onPigClick) { self.onPigClick(hits[0].object.userData.pigId); return; }
      var g = self.groundPoint(e.clientX, e.clientY);
      if (!g) return;
      var id = self.itemAt(Math.floor(g.x / S + COLS / 2), Math.floor(g.z / S + ROWS / 2));
      if (id && self.onItemClick) self.onItemClick(id);
    }
    cv.addEventListener('pointerup', up);
    cv.addEventListener('pointercancel', function () { P.down = false; });
    cv.addEventListener('wheel', function (e) {
      e.preventDefault();
      self.zoomTarget = clamp(self.zoomTarget * (e.deltaY > 0 ? 1.08 : 0.92), 0.5, 1.2);
    }, { passive: false });
  };

  /* ---------- frame ---------- */
  World.prototype.resize = function () {
    var w = this.canvas.clientWidth || window.innerWidth, h = this.canvas.clientHeight || window.innerHeight;
    var ratio = Math.min(window.devicePixelRatio || 1, w < 760 ? 1.5 : 2);
    this.renderer.setPixelRatio(ratio);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    var t = Math.tan(this.camera.fov * Math.PI / 360);
    var wide = w >= 900 && w > h;
    // On wide screens the task panel sits on the left, so the pen moves right.
    this.targetX = wide ? -2.6 : 0;
    var halfW = wide ? 12 : 8.4;
    this.baseDist = Math.max(halfW / (t * this.camera.aspect), 8.2 / t);
    // In portrait the task panel covers the lower half, so the pen moves up.
    this.targetZ = h > w * 1.15 ? this.baseDist * 0.15 : 0.4;
    this.camera.updateProjectionMatrix();
    this.width = w; this.height = h;
  };

  World.prototype.updateCamera = function (dt) {
    var k = Math.min(1, dt * 6);
    this.azimuth += (this.azimuthTarget - this.azimuth) * k;
    this.zoom += (this.zoomTarget - this.zoom) * k;
    var el = 0.74, d = this.baseDist * this.zoom;
    var tx = this.targetX * this.zoom, tz = this.targetZ || 0.4;
    this.camera.position.set(
      tx + Math.sin(this.azimuth) * Math.cos(el) * d,
      0.3 + Math.sin(el) * d,
      tz + Math.cos(this.azimuth) * Math.cos(el) * d
    );
    this.camera.lookAt(tx, 0.3, tz);
  };

  World.prototype.separate = function () {
    var pigs = this.pigs, i, j;
    for (i = 0; i < pigs.length; i += 1) {
      for (j = i + 1; j < pigs.length; j += 1) {
        var a = pigs[i], b = pigs[j];
        if ((a.act && a.act.noSep) || (b.act && b.act.noSep)) continue;
        var dx = b.x - a.x, dz = b.z - a.z, d = Math.sqrt(dx * dx + dz * dz);
        if (d > 0.001 && d < 0.95) {
          var push = (0.95 - d) * 0.5;
          var ma = a.moving ? 1 : 0.15, mb = b.moving ? 1 : 0.15;
          a.x -= dx / d * push * ma; a.z -= dz / d * push * ma;
          b.x += dx / d * push * mb; b.z += dz / d * push * mb;
        }
      }
    }
    var items = this.items;
    for (i = 0; i < pigs.length; i += 1) {
      var p = pigs[i];
      if (p.moving) {
        for (var id in items) {
          var it = items[id];
          if (!it.placed || !it.def.solid) continue;
          var c = this.itemCenter(it);
          var ox = p.x - c.x, oz = p.z - c.z, od = Math.sqrt(ox * ox + oz * oz);
          if (od > 0.001 && od < 0.85) { p.x += ox / od * (0.85 - od); p.z += oz / od * (0.85 - od); }
        }
      }
      p.x = clamp(p.x, MIN_X + 0.42, MAX_X - 0.42);
      p.z = clamp(p.z, MIN_Z + 0.5, MAX_Z - 0.42);
    }
  };

  World.prototype.update = function (dt) {
    this.time += dt;
    var time = this.time, i;
    if (this.timers && this.timers.length) {
      var due = [];
      this.timers = this.timers.filter(function (tm) { tm.t -= dt; if (tm.t <= 0) { due.push(tm.fn); return false; } return true; });
      due.forEach(function (fn) { fn(); });
    }
    for (i = 0; i < this.pigs.length; i += 1) this.pigs[i].step(dt, time);
    this.separate();
    for (i = 0; i < this.pigs.length; i += 1) this.pigs[i].group.position.set(this.pigs[i].x, 0, this.pigs[i].z);

    for (i = 0; i < this.clouds.length; i += 1) {
      var c = this.clouds[i];
      c.position.x += c.userData.speed * dt;
      if (c.position.x > 44) c.position.x = -44;
    }
    var shower = this.items.shower;
    if (shower && shower.group.visible) {
      var drops = shower.group.userData.drops;
      for (i = 0; i < drops.length; i += 1) {
        var d = drops[i], f = (time * 1.4 + d.userData.o) % 1;
        d.position.set(Math.cos(d.userData.a) * d.userData.r * (0.4 + f), 1.95 - f * 1.9, Math.sin(d.userData.a) * d.userData.r * (0.4 + f));
      }
    }
    var toy = this.items.toy;
    if (toy && toy.group.visible) {
      var busy = this.usersOf('toy') > 0 ? 1 : 0.15;
      toy.group.userData.swing.rotation.x = Math.sin(time * 3.2) * 0.22 * busy;
      toy.group.userData.swing.rotation.z = Math.sin(time * 2.1) * 0.12 * busy;
    }
    if (this.placing) {
      var it = this.items[this.placing.id];
      it.group.position.y = 0.3 + Math.sin(time * 4) * 0.06;
      this.footprint.material.opacity = 0.4 + Math.sin(time * 5) * 0.12;
    }
    this.updateCamera(dt);
    this.updateFollow(dt);
  };

  // Close-up camera that stays on one pig (shown inside the pig window).
  World.prototype.updateFollow = function (dt) {
    var p = this.followPig && this.pig(this.followPig);
    if (!p) { this.followLast = null; return; }
    if (this.followLast !== p.id) { this.followPos.set(p.x, 0.5, p.z); this.followLast = p.id; }
    var k = Math.min(1, dt * 4);
    this.followPos.x += (p.x + 0.3 * p.sideK - this.followPos.x) * k;
    this.followPos.z += (p.z - this.followPos.z) * k;
    var el = 0.5, d = 7.2, az = this.azimuth + 0.35;
    this.followCam.position.set(
      this.followPos.x + Math.sin(az) * Math.cos(el) * d,
      0.5 + Math.sin(el) * d,
      this.followPos.z + Math.cos(az) * Math.cos(el) * d
    );
    this.followCam.lookAt(this.followPos.x, 0.5, this.followPos.z);
  };

  World.prototype.render = function () {
    var r = this.renderer, f = this.followRect;
    r.render(this.scene, this.camera);
    if (!f || !this.followPig || f.w < 8 || f.h < 8) return;
    // Second view, drawn straight into the main canvas where the window has its opening.
    var y = this.height - f.y - f.h;
    this.followCam.aspect = f.w / f.h;
    this.followCam.updateProjectionMatrix();
    r.setScissorTest(true);
    r.setScissor(f.x, y, f.w, f.h);
    r.setViewport(f.x, y, f.w, f.h);
    r.setClearColor(0xc4e2ec, 1);
    r.autoClear = false;
    r.clear(true, true, true);
    var grid = this.grid.visible, fp = this.footprint.visible;
    this.grid.visible = false; this.footprint.visible = false;
    r.render(this.scene, this.followCam);
    this.grid.visible = grid; this.footprint.visible = fp;
    r.autoClear = true;
    r.setScissorTest(false);
    r.setViewport(0, 0, this.width, this.height);
    r.setClearColor(0x000000, 0);
  };

  var tmp = new T.Vector3();
  World.prototype.screenPos = function (pig) {
    tmp.set(pig.x + 0.3 * pig.sideK, 1.42 - 0.45 * pig.lieK, pig.z).project(this.camera);
    return { x: (tmp.x + 1) / 2 * this.width, y: (1 - tmp.y) / 2 * this.height };
  };

  NTK.World = World;
  NTK.GRID = { COLS: COLS, ROWS: ROWS, SLAT_FROM: SLAT_FROM };
})();
