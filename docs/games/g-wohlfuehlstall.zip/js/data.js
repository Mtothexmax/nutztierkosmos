/* ============================================================
   Der Wohlfühlstall · Spielstruktur
   Tiere, Einrichtung, Fälle und Regeln ohne Sprache. Alle Texte
   stehen in js/texts.js (Deutsch und Englisch) und werden von
   NTK.localize() in diese Struktur eingesetzt.
   ============================================================ */
(function () {
  'use strict';
  var NTK = window.NTK = window.NTK || {};

  NTK.DATA = {
    maxPoints: 1000,
    points: { first: 80, second: 50, later: 30, build: 40, rule: 56 },

    pigs: [
      { id: 'emma', name: 'Emma', color: 0xee9a8e, dark: 0xd77a72, spots: false, likes: ['rooting', 'toy'] },
      { id: 'bruno', name: 'Bruno', color: 0xecb49c, dark: 0x5e4037, spots: true, likes: ['feeder2', 'niche'] },
      { id: 'lotte', name: 'Lotte', color: 0xf3a9a6, dark: 0xdd8583, spots: false, likes: ['shower', 'bed'] },
      { id: 'frieda', name: 'Frieda', color: 0xdd8a76, dark: 0xc26d5c, spots: false, likes: ['bed', 'rooting'] }
    ],

    /* Einrichtung. w/h = Größe in Feldern. */
    items: {
      feeder:  { w: 1, h: 1, fixed: true, solid: true, cap: 2 },
      drinker: { w: 1, h: 1, fixed: true, solid: true, cap: 1 },
      rooting: { icon: 'straw', w: 2, h: 2, cap: 3 },
      feeder2: { icon: 'bowl', w: 1, h: 1, solid: true, cap: 2 },
      shower:  { icon: 'shower', w: 1, h: 1, cap: 2 },
      bed:     { icon: 'bed', w: 2, h: 2, cap: 4 },
      niche:   { icon: 'door', w: 2, h: 1, cap: 1 },
      toy:     { icon: 'teddy', w: 1, h: 1, cap: 2 }
    },
    toolOrder: ['rooting', 'feeder2', 'shower', 'bed', 'niche', 'toy'],

    /* Start-Einrichtung: Feld (Spalte, Reihe), Reihe 0 liegt an der Stallwand. */
    fixed: { feeder: { c: 1, r: 0 }, drinker: { c: 8, r: 0 } },

    /* Sechs Fälle. options: Bild und ob die Deutung stimmt. */
    cases: [
      { pig: 'emma', behaviour: 'barbite', item: 'rooting',
        observations: [{ icon: 'tooth' }, { icon: 'pig' }, { icon: 'no' }],
        options: [{ icon: 'bowl', ok: false }, { icon: 'straw', ok: true }, { icon: 'devil', ok: false }],
        card: { icon: 'straw' } },
      { pig: 'bruno', behaviour: 'displaced', item: 'feeder2',
        observations: [{ icon: 'turn' }, { icon: 'sad' }, { icon: 'bowl' }],
        options: [{ icon: 'bowl', ok: true }, { icon: 'cross', ok: false }, { icon: 'carrot', ok: false }],
        card: { icon: 'bowl' } },
      { pig: 'lotte', behaviour: 'hot', item: 'shower',
        observations: [{ icon: 'sun' }, { icon: 'dash' }, { icon: 'snow' }],
        options: [{ icon: 'straw', ok: false }, { icon: 'zzz', ok: false }, { icon: 'sweat', ok: true }],
        card: { icon: 'sweat' } },
      { pig: 'frieda', behaviour: 'restless', item: 'bed',
        observations: [{ icon: 'repeat' }, { icon: 'pin' }, { icon: 'drop' }],
        options: [{ icon: 'shoe', ok: false }, { icon: 'bed', ok: true }, { icon: 'moon', ok: false }],
        card: { icon: 'bed' } },
      { pig: 'bruno', behaviour: 'startle', item: 'niche',
        observations: [{ icon: 'alert' }, { icon: 'dash' }, { icon: 'eyes' }],
        options: [{ icon: 'door', ok: true }, { icon: 'hourglass', ok: false }, { icon: 'lock', ok: false }],
        card: { icon: 'door' } },
      { pig: 'emma', behaviour: 'bored', item: 'toy',
        observations: [{ icon: 'straw' }, { icon: 'pig' }, { icon: 'calendar' }],
        options: [{ icon: 'no', ok: false }, { icon: 'cross', ok: false }, { icon: 'teddy', ok: true }],
        card: { icon: 'teddy' } }
    ],

    /* Stall-Check: Regeln für die Anordnung (Prüfung in game.js). */
    rules: [{ id: 'dry' }, { id: 'drain' }, { id: 'feed' }, { id: 'calm' }, { id: 'sleep' }]
  };
})();
